﻿(function ($) {
    var word = pageAboutWord;
    word.iscroller = null;
    word.initPhoto = null;
    word.onPageLoad = function () {
        var id = word.getParam("id");
        if (id > 0) {
            $.ajax({
                type: 'get',
                url: appUrl('detail'),
                data: { id: id },
                success: function (json) {
                    json = eval("(" + json + ")")[0];
                    S('[data-route="navbar-inner"]', R.currPage.ele).t.innerHTML = json.Title;
                    $("#abouttitle").html(json.Title);
                    $("#aboutcontent").html(json.Contents);
                }
            });

            word.initPhoto = app.initPhoto("#preview-about");
            word.iscroller = app.iscroll("#preview-about");
        }

    }


})(jQuery);