(function ($) {
    var IA = pageIndAdd;

    IA.onPageLoad = function () {
        helper.init();
    }
    /*帮助方法*/
    var helper = {
        identity: {
            current: 1
        },//
        isload: function () {
            return !!$('#pageIdentity_idList').html().length;
        },
        init: function () {
           var t = $('#pageIdentity_idList span').first().data('type');
           this.identity.current = t || 1;
           if (!this.isload()) {
               xzbTool.bind.bindID("#pageIdentity_idList");
               xzbTool.bind.bindIdSelect("#pageIdentitySelect", "#pageIdentity_idList");
               showSelect(IA, "#pageIdentitySelect");
               selectIdentity(IA, "#pageIdentitySelect");
           }
           data.identityId = parseInt(R.getPara('id', 'id'));//接收修改参数
           data.loadDetail();//加载详细内容（修改的时候用）
        }
       
    };
    /*数据*/
    var data = {
        identityId: 0,
        selected: {
            student: { flag: 0, value: 0 },
            schoolfriend: { flag: 0, value: 0 },
            teacher: {
                xi: { flag: 0, value: 0 },
                zn: { flag: 0, value: 0 }
            },
            worker: {
                zhiwu: '',
                company: { flag: 0, value: 0 }
            }
        },
        //根据flag和classid获取相应的内容
        getSelectedClass: function () {

        },
        getPosition: function () {

        },
        loadDetail: function (id) {
            var dataId = id || data.identityId;
            if (!dataId) { return; }
            ajaxTool.ajaxGet(appUrl('user/iddetail'), { id: dataId, cvNumber: getCurrentCV() }, function (result) {
                if (result.result == 10000) {
                    data.resetIdentity(result.data);
                } else {
                    log("加载身份详细信息失败");
                }
            });
        },
        resetIdentity: function (data) {
            //重置选中项目
            //先选中大菜单
            reset.resetIdentity('#pageIdentitySelect', data);
        },
        getDetailByFlag: function (data, f) {
            var d = $.grep(data, function (item, i) {
                return item.flag == f;
            });
            if (d.length) {
                return d[0];
            }
            return [];
        }
    };
    IA.on(".ShenFen span", "touchend", function (e, ev) {
        window.switchIdentity(e, "#pageIdentitySelect");
        helper.identity.current = $(ev.self).data('type');
        log(helper.identity.current);
    })
    IA.on('#pageIdentity_save', 'touchend', function (e, ev) {
        var parameters = createParam({ regid: helper.identity.current, cvNumber: getCurrentCV() }, "#pageIdentitySelect");
        if (!parameters.isLegalData) { return false; }
        parameters.identityId = data.identityId || 0;//要修改的Id


        var src1 = '/' + R.info.global.platform + '/wx/getauth?platUrl=' + R.info.global.platform;
        R._ajax(src1, 'POST', JSON.stringify({ "url": location.href }), true, function (t) { });

        ajaxTool.ajaxPost(appUrl('user/adduserid'), parameters, function (result) {
            if (result.result == 10000) {
                //保存成功，需要重置用户信息
                appUser.set({ cvnumber: getCurrentCV(), pid: 0 }, function (result) {
                    //重新设置用户身份信息
                    ExperLocData();
                    R.to('pageIndentity?code=ok', 10);//返回身份页面
                });
            } else {
                app.alert('保存失败，请重试');
            }
        });
    })

	//关闭选择
    IA.on(".modal-over-back", "touchend", function (e, ev) {
        $("#pageindentityAdd .selecter-in").removeClass("selecter-in");
        $(ev.self).removeClass("modal-overlay-visible");
	});
	

	var reset = {
	    resetIdentity: function (selectId, d) {
	        var identity = data.getDetailByFlag(d, 9);
	        var tagIndex = identity.joinid;
	        var that = $('#pageIdentity_idList').find('span[data-type="' + tagIndex + '"]');
	        var template = xzbTool.data.alltemplateType();
	        var topSelectId = $(selectId).find("#tag" + tagIndex);
	        if (!that.hasClass("shenfen-curent")) {
	            that.addClass("shenfen-curent").siblings("span").removeClass("shenfen-curent");
	            topSelectId.addClass('show').show().siblings().removeClass('show').hide();
	        }
	        //单条加载
	        var t = parseInt(tagIndex);
	        helper.identity.current = t;
	        var bj = data.getDetailByFlag(d, 5);
	        var year = data.getDetailByFlag(d, 8);
	        var eid = data.getDetailByFlag(d, 1);
	        var xi = data.getDetailByFlag(d, 3);//系
	        var zn = data.getDetailByFlag(d, 2);//职能
	        switch (t) {
	            case 1://学生
	                if (bj) {
	                    $('#tag1>ul>li').first().find('span').text(bj.identity_name);
	                    $('#list5>ul>li').removeClass('current');
	                    $('#list5>ul').find('li[data-joinid="' + year.joinid + '"]').addClass('current');
	                    $('.selecter-right-title').find('span').removeClass('current');
	                    $('.selecter-right-title').find('span[data-joinid="' + eid.joinid + '"]').addClass('current');
	                    xzbTool.bind.bindClass('#tag1 #banji', { year: year.joinid, eid: eid.joinid });
	                    $('#banji>li').find('span[data-joinid="' + bj.joinid + '"]').addClass('on');
	                }
	                break;
	            case 2://校友
	                if (bj) {
	                    log(bj);
	                    $('#tag2>ul>li').first().find('span').text(bj.identity_name);
	                    $('#list5>ul>li').removeClass('current');
	                    $('#list5>ul').find('li[data-joinid="' + year.joinid + '"]').addClass('current');
	                    $('.selecter-right-title').find('span').removeClass('current');
	                    $('.selecter-right-title').find('span[data-joinid="' + eid.joinid + '"]').addClass('current');
	                    xzbTool.bind.bindClass('#tag2 #banji', { year: year.joinid, eid: eid.joinid });
	                    $('#banji>li').find('span[data-joinid="' + bj.joinid + '"]').addClass('on');
	                }
	                break;
	            case 3://教师
	                $('#tag3>ul').first().find('li').find('span').text(xi.identity_name);
	                $('#tag3>ul').eq(1).find('li').find('span').text(zn.identity_name);
	                 this.resetSingle('list3', xi.joinid);
	                 this.resetSingle('list2', zn.joinid);
	                break;
	            case 4://职工
	                log(xi);
	                $('#tag4').find('input[type="text"]').val(xi.title);
	                $('#tag4>ul>li').first().find('span').text(xi.identity_name);
	                this.resetSingle('list3', xi.joinid);
	                break;
	        }
	    },
	    resetSingle: function (parent, id) {
	        $('#' + parent + '>ul>li>span').removeClass('on');
	        $('#' + parent + '>ul>li').find('span[data-joinid="' + id + '"]').addClass('on');
	    },
	    resetTitle: function () {

	    },
	    resetBj: function (bj) { },
	};
})(jQuery);
