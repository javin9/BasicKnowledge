﻿(function () {
    pageBackPwd2.on(".icon-eye", "touchend", function (e, ev) {
        var that = $(ev.self),
			val = that.prev("input").val(),
			h = that.hasClass("ico-active");
        if (h) {
            that.prev("input").attr("type", "password").val(val);
            that.removeClass("ico-active");
        } else {
            that.prev("input").attr("type", "text").val(val);
            that.addClass("ico-active");
        }
    });
    /*初始化init*/
    pageBackPwd2.init = function () {
        var footerData = xzbTool.data.plat()[0];
        if (!isNull(footerData.foot_left_title)) {
            $("#pwd2leftStr").text(footerData.foot_left_title);
        }
        if (!isNull(footerData.foot_right_title)) {
            $("#pwd2rightStr").text(footerData.foot_right_title);
        }
        pageBackPwd2.isSendCode = {
            flag: false,
            mobile: ''
        }
    };

    pageBackPwd2.onPageLoad = function () {
        pageBackPwd2.currentmobile = envObj.GetLocals("getpwd_mobile");//当前的手机号
        console.log("pageBackPwd2.currentmobile=" + pageBackPwd2.currentmobile);
        /*
          作用：触发开始倒计时
          */
        var prePageName = R.prePage.name;
        if (prePageName != "pageBackPwd1") {
            if (prePageName != "") {
                R.to(prePageName);
            }
        } else {
            if (pageBackPwd2.isSendCode.mobile != pageBackPwd2.currentmobile) {
                console.log('倒计时开始');
                reg_countdownFunc(pageBackPwd2.currentmobile);
            }
        }

    };
    //点击倒计时
    pageBackPwd2.on("#pwd_timecount", "touchend", function (e, ev) {
        console.log('点击倒计时');
        resendClick({
            btnId: '#pwd_timecount',//验证码外层元素的id
            callback: function () {
                SendCode({//发送验证码
                    mobile: pageBackPwd2.currentmobile
                });
            }
        });
    });
    //修改密码
    pageBackPwd2.on("#getpwdsave", "touchend", function (e, eo) {
        var that = $(e.target);
        var code = $("#getpwdcode").val().trim();
        var isValid = regex_data.IsPostCode.test(code);

        if (!isValid) {
            myApp.alert('校验码不正确，请重新输入');
            return false;
        }

        isValid = regex_data.IsValidByte.test($("#getpwdvalue").val());
        if (!isValid) {
            myApp.alert('密码长度:6-10位');
            return false;
        }

        if (isValid) {
            if (!that.hasClass('noClick')) {
                CheckCode({
                    mobile: envObj.GetLocals("getpwd_mobile"),
                    code: code,
                    callback: checkCodeCallback,
                    bsFunc: disablePwdbtn,
                    id: '#getpwdsave',
                    className: 'btn-disabled'
                });
            }
        }
    });

    /*------------------------------------------------------------------------------------------------------------*/
    //倒计时
    function reg_countdownFunc(mobile) {
        resendClick({
            btnId: '#pwd_timecount',//验证码外层元素的id
            callback: function () {
                SendCode({//发送验证码
                    mobile: mobile,
                    bsFunc: function () {
                        console.log("发送验证码before");
                        console.log(pageBackPwd2.isSendCode.mobile);
                        pageBackPwd2.isSendCode.flag = true;
                        pageBackPwd2.isSendCode.mobile = mobile;
                    }
                });
            }
        });
    };
    //检验验证码callback
    function checkCodeCallback(json) {
        if (json.result == 10000) {
            console.log('验证码正确');
            getPwd();
        } else {
            console.log('验证码错误');
            app.alert(json.msg);
            ablePwdbtn();//自定义注册第二步按钮
        }
    };

    //重置密码callback
    function getPwd() {
        var mobile = envObj.GetLocals("getpwd_mobile");
        $.ajax({
            type: 'post',
            url: appUrl('resetpwd'),
            data: { mobile: mobile, pwd: $("#getpwdvalue").val().trim() },
            success: function (json) {
                console.log("重置密码成功");
                if (json.result == 10000) {
                    app.alert(json.msg);
                    R.to('login?mobile=' + mobile);
                    envObj.RemoveLocals('getpwd_mobile');
                } else {
                    app.alert(json.msg);
                }
                ablePwdbtn();
            }
        });
    }

    //启用按钮
    function ablePwdbtn() {
        $("#getpwdsave").removeClass('btn-disabled').text('保存');
    }
    //禁用按钮
    function disablePwdbtn() {
        $("#getpwdsave").addClass('btn-disabled').text('保存...');
    }
})(jQuery);