﻿(function ($) {
    pageFeed.init = function () {

    };

    pageFeed.onPageLoad = function () {
        $("#feedcontent").val("");
    }

    pageFeed.on("#addfeed", "touchend", function (e, ev) {
        var content = $("#feedcontent").val().trim(),
            that = $(e.target),
            cvNumber = getCurrentCV();
        if (/^\s*$/.test(content)) {
            app.alert("请填写一下您的宝贵意见");
            return false;
        }
        if (!that.hasClass('btn-disabled')) {
            $.ajax({
                type: 'post',
                url: appUrl('feed'),
                beforeSend: function () {
                    that.addClass('btn-disabled').text('保  存');
                },
                data: { cvNumber: cvNumber, content: EmojiBM(content) },
                success: function (json) {
                    if (json.result == 10000) {
                        app.alert('成功');
                        $("#feedcontent").val('');
                        R.to('pageAbout');
                    } else {
                        app.alert('失败');
                    }
                    that.removeClass('btn-disabled').text('添  加');
                }
            });

        }
    });

})(jQuery);