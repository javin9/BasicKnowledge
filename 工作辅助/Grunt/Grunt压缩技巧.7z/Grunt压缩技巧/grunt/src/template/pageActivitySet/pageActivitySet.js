(function($){
    var activitySets = pageActivitySet;
    var articleId = 0, code = "", privacy = 1, isopen=true;
    activitySets.onPageLoadInit = function () {
        app.iscroll("#page-activitySet");
        isopen = $.getCookie("activ_open");
        isopen != "false" ? $(".switch").removeClass("off").addClass("on") : $(".switch").removeClass("on").addClass("off");
    }
    activitySets.onPageLoad = function () {
        articleId = activitySets.getParam('articleId');
        code = activitySets.getParam('code');
        privacy = activitySets.getParam("privacy");
        if (code == "ok") {
            privacy = 3;
        } 
        $('.security .table-view-cell').eq(privacy - 1).addClass("setting-active").siblings().removeClass("setting-active");
    }
	//权限
	activitySets.on(".security .table-view-cell","touchend",function(e,ev){
		var self = ev.self;
		if($(self).hasClass("setting-active") || $(self).index()==2)return false;
		$(self).addClass("setting-active").siblings().removeClass("setting-active");
	})
    //经历部分可见
	activitySets.on("#page_partSee", "touchend", function () {
	    R.to("pageSelecter?id=" + articleId + "&articleType=2", "", "");
	});

    //完成   getCurrentCV()
	activitySets.on(".pull-right", "touchend", function (e, ev) {
	    var privacy = $(".security li[class*='setting-active']").index() + 1;
	    var isOpen = $("#kg_open").val()=="on" ? 1 : 0;
	    ajaxTool.ajaxPost(appUrl("updateprivacy"), { articleId: articleId, articleType: 2, cvNumber: getCurrentCV(), privacy: privacy, isOpen: isOpen }, function (result) {
	        console.log(result);
	        if (result.result == 10000) {
	            ThingLocData();
	            R.to("pageThing", "", "");
	            //alert("保存成功");
	        }
	    });
	});
    //返回
	activitySets.on("#ActivityBack", "touchend", function () {
	    R.to("pageActivityEditor?Id=" + articleId);
	});
	//开关
	activitySets.on(".switch","touchend",function(e,ev){
		var that = ev.self;
		if ($(that).hasClass("disabled")) return false;
	    if ($(that).hasClass("off")) {
	        $(that).removeClass("off").addClass("on");
	        $(that).find("input").val("on");
	    } else {
	        $(that).removeClass("on").addClass("off");
	        $(that).find("input").val("off");
	    }
	})
})(jQuery);