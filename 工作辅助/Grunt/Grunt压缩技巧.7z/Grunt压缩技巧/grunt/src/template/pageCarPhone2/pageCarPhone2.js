﻿; (function ($) {
    pageCarPhone2.onPageLoad = function () {
        pageCardHelper.getphone(function (result) {
            pageCarPhone2.phone = result.mobile;
        })
    }
    pageCarPhone2.on('.pull-right', 'touchend', function (e, ev) {
        var phone = $.trim($('#pageCarPhone2_mobile').val());
        if (!phone) {
            app.alert('请输入手机号');
            return;
        }
        if (phone === pageCarPhone2.phone) {
            app.alert('手机号没有改变');
            return;
        } else {
            //要发送的验证码
            pageCarPhone2.oldPhone = pageCarPhone2.phone;//旧手机号
            pageCarPhone2.phone = phone;//新手机号
            R.to('pageCarPhone3');
        }
    });
    pageCarPhone2.onPageLoadInit = function () {
        log(pageCarPhone2);

    }
})(jQuery);