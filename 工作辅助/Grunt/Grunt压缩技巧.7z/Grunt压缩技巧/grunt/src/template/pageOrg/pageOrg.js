(function ($) {
    var org = pageOrg;
    org.MyDB = {
        dbName: "pageOrg",
        tabNames: [{ name: 'pageOrg', id: 'cvnumber' }],
        db: null,
        url: 'experlist/myorglist',
        cvnumber: getCurrentCV(),
        load: function (data, callback) {
            var url = appUrl(this.url);
            IndexDB.LoadData(this.dbName, url, data, false, callback, org.MyDB.db);
        },
        update: function (name, data, success) {
            if (org.MyDB.db != null) {
                IndexDB.update(name, data, this.cvnumber, success, 0, this.db);
            } else {
                IndexDB.openDB(org.MyDB.dbName, org.MyDB.tabNames, function () {
                    org.MyDB.db = IndexDB._pageDB.db;
                    IndexDB.update(name, data, org.MyDB.cvnumber, success, 0, org.MyDB.db);
                }, 1);
            }
        }
    }
    org.iscroller = null;
    org.loadingMore = false;
    org.isRefresh = false;
    org.swiper = null;
    org.loadNew = true;
    org.init = function () {
        if (org.iscroller) return false;
        org.iscroller = app.iscroll("#page-org");
        appUser.get(org.MyDB.cvnumber, function (result) {
            org.getdata(org.bindNew, org.MyDB.cvnumber);
        }, function (msg) {
            log(msg);
        });
    }

    //ÿ�μ�������
    org.onPageLoad = function () {
        org.LoadM();
    }

    //�����б����� �ȴӱ���ȡ û�� ȥ���� �ٴӱ���ȡ��
    org.getdata = function (success, cvnumber) {
        if (org.MyDB.db != null) {
            //��ȡ���� 
            IndexDB.Select(org.MyDB.dbName, cvnumber, function (result) {
                if (typeof result != 'object') {
                    result = eval("(" + result + ")");
                }
                if (result != undefined) {
                    success(result);
                } else {
                    org.MyDB.load({ startcv: 0, cvnumber: cvnumber, pid: 0 }, function () {
                        org.loadNew = false;
                        org.getdata(success, cvnumber);
                    })
                }
            }, org.MyDB.db);
        } else {
            IndexDB.openDB(org.MyDB.dbName, org.MyDB.tabNames, function () {
                org.MyDB.db = IndexDB._pageDB.db;
                //��ȡ���� 
                IndexDB.Select(org.MyDB.dbName, cvnumber, function (result) {
                    if (typeof result != 'object') {
                        result = eval("(" + result + ")");
                    }
                    if (result != undefined) {
                        success(result);
                    } else {
                        org.MyDB.load({ startcv: 0, cvnumber: cvnumber, pid: 0 }, function () {
                            org.loadNew = false;
                            org.getdata(success, cvnumber);
                        })
                    }
                });
            }, 2);
        }
    }

    //�����б��� ����һЩ����
    org.bindNew = function (data) {
        if (typeof data != 'object') {
            data = eval("(" + data + ")");
        }
        if (data.list.length > 0) {
            $("#orgList").html($("#orgListTemp").render(data));
        } else {
            $("#orgList").html('<div class="noData">��ʱ��û����Ŷ���Ͻ���Ϊ��һ����...</div>');
        }
    };

    //���������б����߻�ȡ���������б�����
    org.LoadM = function () {
        var url = appUrl(org.MyDB.url);
        $.ajax({
            url: url,
            data: { cvnumber: org.MyDB.cvnumber, pid: 0 },
            type: "Get",
            dataType: 'json',
            success: function (result) {
                var json = result
                if (json.result == 10000) {
                    org.MyDB.update(org.MyDB.dbName, json.data, org.bindNew);
                }
            },
            error: function (er) {
                console.log("��������ȡʧ��");
            }
        });
    };

    //����ҵ��ղ�
    org.on("#orgList li", "touchend", function (e, eo) {
        console.log();
        var data = xzbTool.data.plat()[0], $that = $(eo.self), id = $that.attr("data-plid"), url = $that.attr("data-plurl");
        if (data.pfid == id) {
            return false;
        } else {
            window.location.href = R.getUrl().preUrl + url + "/index";
        }
    });

    //ʱ���ʽת��
    $.views.helpers({
        isbenPl: function (id) {
            var pfid = xzbTool.data.plat()[0].pfid;
            if (pfid == id) {
                return true;
            } else {
                return false;
            }
        }
    });

})(jQuery)
