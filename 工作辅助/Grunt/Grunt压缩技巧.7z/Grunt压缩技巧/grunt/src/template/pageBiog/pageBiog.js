﻿(function () {
    var biog = {};
    biog.page = pageBiog;
    biog.scroller = null;
    biog.page.prePageName = "";
    biog.page.onPageLoadInit = function () {
    }
    biog.page.init = function () {
        var cvNumber = getCurrentCV();
        if (cvNumber > 0) {
            appUser.get(cvNumber, function (result) {
                $("#bioUserHeader").attr("src", result.headphoto || '../../img/userImg.jpg');
            });
        }
    }
    //biog.page.on('#bioUserHeader', "touchend", function (e, ev) {
    //    var cvNumber = getCurrentCV();
    //    if (cvNumber > 0) {
    //        R.to("pageSpace?cv=" + cvNumber);
    //    }
    //});
    //左滑删除
    biog.page.on(".sortable-list", "slide", function (e, ev) {
        var that = ev.self;
        $(".swipe-left").removeClass("swipe-left");
        $(that).addClass("swipe-left");
    }, { direc: "left" });
    // 
    biog.page.on("#tosumedit", "touchend", function (e, ev) {
        var that = $(ev.self),
            id = that.attr('data-id');
        R.to("pageBiogSumEditor?id=" + id);
    });
    /*删除页面*/
    biog.page.on(".swipe-del .del", "touchend", function (e, ev) {
        var that = $(ev.self),
            id = that.attr('data-id');
        var cvNumber = getCurrentCV();
        if (cvNumber > 0) {
            if (id > 0) {
                app.alert("确定删除吗？", [{
                    title: "确定", fn: function () {
                        if (!that.hasClass('not')) {
                            $.ajax({
                                type: 'post',
                                url: appUrl('delcharpter'),
                                beforeSend: function () {
                                    that.addClass('not');
                                },
                                data: { id: id, cvNumber: cvNumber },
                                success: function (json) {
                                    console.log(json);
                                    if (json.Result == 10000) {
                                        var $li = that.parents('li.table-view-cell');
                                        $li.remove();
                                    } else {
                                        app.alert('失败');
                                    }
                                    app.hideAlert();
                                }, error: function () {
                                    app.hideAlert();
                                }
                            });
                        }
                    }
                }, {
                    title: "取消", fn: function () {
                        app.hideAlert();
                    }
                }], "退出提示");
            }
        }
    });
    biog.page.on(".pageScroll", "touchstart", function (e, ev) {
        //if ($(ev.self).isChildAndSelfOf(".swipe-left") == false) {
        //    $(".swipe-left").removeClass("swipe-left");
        //}
        $(".swipe-left").removeClass("swipe-left");
    });
    //biog.page.on(".sortable-list", "slide", function (e, ev) {
    //    $(".swipe-left").removeClass("swipe-left");
    //}, { direc: "right" });

    function showSave() {
        $("#sortableBtn").show();
    }

    /*-----------------------------------------------------------------------------------------*/
    /*页面进入*/
    biog.page.onPageLoad = function () {
        biog.page.prePageName = R.prePage.name;
        biog.bioIndex();
    };
    biog.bioIndex = function () {
        var cvNumber = getCurrentCV();
        if (cvNumber > 0) {
            $.ajax({
                type: 'post',
                url: appUrl('bioindex'),
                beforeSend: function () {
                },
                data: { cvNumber: cvNumber },
                success: function (json) {
                    if (json.Result == 10000) {
                        var charpterJson = json.Data.BiographyChapterList,
                            figureJson = json.Data.BiographyFigure;
                        /*人物概述*/
                        if (figureJson.Id > 0) {
                            $("#tosumedit").attr("data-id", 1);
                            $("#figurecontent").html(EmojiJM(figureJson.FigureSummary).replace(/<[^>]+>/g, ""));
                        } else {
                            $("#tosumedit").attr("data-id", 0);
                            $("#figurecontent").text('您还没有填写人物概述');
                        }
                        /*章节列表*/
                        if (charpterJson.length > 0) {
                            $("#bio_list").html($("#bioListTemplate").render(charpterJson));
                        }
                        biog.scroller = app.iscroll("#page-biog");
                        biog.sortable = app.sortable('sortable', 800, showSave, true, biog.scroller);
                    } else {
                        app.alert('加载数据失败');
                    }
                }, error: function () {
                    alert('error!');
                }
            });
        } else {
            R.to('login');
        }

    };
   
    /*排序$("#sortableBtn")*/
    biog.page.on("#sortableBtn", "touchend", function (e, ev) {
        var that = $(ev.self);

        var cvNumber = getCurrentCV();
        if (cvNumber > 0) {
            if (!that.hasClass('not')) {
                var arr = [], $that = $("#bio_list").find("li"), len = $that.length;
                if (len > 0) {
                    var template = '{"charpterId":"{0}","sort":"{1}"}';
                    $that.each(function (i) {
                        arr.push(template.format([$(this).attr("data-id"), (len - i)]));
                    });
                    var list = '{"key":[' + arr + ']}';

                    $.ajax({
                        type: 'post',
                        url: appUrl('sortcharpter'),
                        beforeSend: function () {
                            that.addClass('not');
                        },
                        data: { cvNumber: cvNumber, list: list },
                        success: function (json) {
                            console.log(json);
                            if (json.Result == 10000) {
                                app.alert('成功');
                                that.hide();
                            } else {
                                app.alert('失败');
                            }
                            that.removeClass('not');
                        }, error: function () {

                        }
                    });

                }
            }
        }

    });
    biog.page.on("#changpubulic", "touchend", function (e, ev) {
        var that = $(ev.self);
        var cvNumber = getCurrentCV();
        var id = that.attr("data-id");
        var author = that.hasClass('biogLocked') ? true : false;
        if (cvNumber > 0) {
            if (!that.hasClass('not')) {
                $.ajax({
                    type: 'post',
                    url: appUrl('modifyauthor'),
                    beforeSend: function () {
                        that.addClass('not');
                    },
                    data: { cvNumber: cvNumber, id: id, author: author },
                    success: function (json) {
                        if (json.Result == 10000) {
                            var msg = author ? '已改为公开' : '已改为私藏';
                            app.alert(msg);
                            if (that.hasClass('biogLocked')) {
                                that.removeClass('biogLocked');
                            } else {
                                that.addClass('biogLocked');
                            }
                        } else {
                            app.alert("失败");
                        }
                        that.removeClass('not');
                    }
                });
            }
        }
    });
    biog.page.on("#topageOur", "touchend", function (e, ev) {
        console.log($("#sortableBtn").css("display"));
        if ($("#sortableBtn").css("display") == 'none') {
            if (biog.page.prePageName == "pageCarList") {
                R.to('pageCarList', '10', '');
            } else {
                R.to('pageOur', '10', '');
            }
        } else {
            app.alert("您的章节排序已改变但未保存，是否要离开？？", [{
                title: "确定", fn: function () {
                    if (biog.page.prePageName == "pageCarList") {
                        R.to('pageCarList', '10', '');
                    } else {
                        R.to('pageOur', '10', '');
                    }
                   
                    app.hideAlert();
                }
            }, {
                title: "取消", fn: function () {
                    app.hideAlert();
                }
            }], "退出提示");
        }
    });
})(jQuery);
