﻿; (function ($) {
    pageCarName.onPageLoad = function () {
        log('pageCarName');
        pageCardHelper.setinfo('pageCar_name', 'name');
    }
    //保存
    pageCarName.on('.pull-right', 'touchend', function (e, ev) {
        pageCardHelper.updateinfo('pageCar_name', 'name');
    });
})(jQuery);