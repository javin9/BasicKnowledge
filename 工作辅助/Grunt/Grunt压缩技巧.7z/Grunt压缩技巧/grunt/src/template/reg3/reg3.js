(function ($) {
    reg3.init = function () {
        console.log("reg3_init");
        /*底部文字*/
        var footerData = xzbTool.data.plat()[0];
        if (!isNull(footerData.foot_left_title)) {
            $("#reg3leftStr").text(footerData.foot_left_title);
        }
        if (!isNull(footerData.foot_right_title)) {
            $("#reg3rightStr").text(footerData.foot_right_title);
        }
        /*身份类型*/
        xzbTool.bind.bindID("#regIdentity", 0, reg_title);

        /*身份类型对应的选择*/
        xzbTool.bind.bindIdSelect("#regIdentitySelect", "#regIdentity");
        showSelect(reg3, "#regIdentitySelect");
        selectIdentity(reg3, "#regIdentitySelect");
    };
    reg3.para = '';
    /*userdata*/
    reg3.onPageLoad = function () {
        var prePageName = R.prePage.name;
        console.log(isNull(prePageName));
        var userdata = eval("(" + envObj.GetLocals('userdata') + ")");
        reg3.userdata = userdata;
        reg3.para = R.getUrl().para;
        var isFinish = parseInt($.getCookie("Regstate" + R.info.global.platform) || 0);
        if (prePageName == 'reg2' || prePageName == 'login' || (isFinish == 0)) {
            console.log(xzbTool.data.allIDSelected());
            console.log(xzbTool.data.allI());

            userdata.hasname == 1 ? $("#regnameDiv").hide() : $("#regnameDiv").show();
            var identityIDLen = xzbTool.data.allI().length;
            var listLen = xzbTool.data.allIDSelected();

            if (identityIDLen <= 1 && userdata.hasname == 1 && listLen.length == 0) {
                //直接跳过
                console.log("直接跳过");
                regFinish();
            }
        }
        else {
            R.to(isNull(prePageName) ? 'login' : prePageName);
        }
    };

    //切换身份
    reg3.on(".ShenFen span", "touchend", function (e, ev) {
        window.switchIdentity(e, "#regIdentitySelect");
    });
    //关闭选择
    reg3.on(".modal-over-back", "touchend", function (e, ev) {
        $("#reg3Page .selecter-in").removeClass("selecter-in");
        $(ev.self).removeClass("modal-overlay-visible");
    })

    /*完成注册*/
    reg3.on("#finishreg", "touchend", function (e, ev) {
        regFinish(e, ev);
    });

    //注册完成
    function regFinish(e, ev) {
        var that =$("#finishreg"),
    page = $("#selectContent"),
    name = $("#regname").val().trim(),
    hasName = parseInt(reg3.userdata.hasname),
    cvNumber = reg3.userdata.cvNumber,
    identityType = $("#regIdentity").find('span.shenfen-curent').attr('data-type');//身份类型
        if (hasName == 0 && /^\s*$/.test(name)) {
            app.alert('请填写姓名');
            return false;
        }//18800000747

        var parameters = createParam(
            {
                name: name,
                hasName: hasName,
                regid: identityType,
                cvNumber: cvNumber
            },
            "#regIdentitySelect"
            );

        if (!parameters.isLegalData) { return false; }

        if (!that.hasClass('btn-disabled')) {
            $.ajax({
                type: 'post',
                url: appUrl('finish'),
                beforeSend: function () {
                    that.addClass("btn-disabled");
                },
                data: parameters,
                success: function (json) {
                    if (json.result == 10000) {
                        console.log("跳转到名片");
                        envObj.RemoveLocals("userdata");
                        envObj.RemoveLocals("regmobile");
                        if (!isNull(reg3.para)) {
                            console.log("reg3");
                            console.log("login?" + reg3.para);
                            R.to("login?" + reg3.para);
                        } else {
                            R.to("login");
                        }
                    } else {
                        app.alert('失败');
                    }
                    that.removeClass('btn-disabled');
                }, error: function () {
                    that.removeClass('btn-disabled');
                }
            });
        }
    }

})(jQuery);
