﻿(function ($) {
    var liuyan = pageLiuyan;
    liuyan.scroller = null;

    liuyan.onPageLoad = function () {
        l.getLevelOne(function () {
            app.autoArea("#liuyan");
            log(liuyan.scroller);
            if (!liuyan.scroller) {
                liuyan.scroller = app.iscroll("#page-liuyan");
            }
            log('refresh');
            log(liuyan.scroller);
            liuyan.scroller.refresh();
        })
    }

    var l = {
        params: {
            currentCvNumber: getCurrentCV(),
            receiveCvNumber:parseInt(R.getPara('cv', 'cv')) || getCurrentCV(),
            spaceCvNumber: parseInt(R.getPara('cv', 'cv')) || getCurrentCV(),
            topid: 0,
            parentid:0
        },
        bindOne:function(data){
          var html =  jsRenderBinding({
                page: "pageSpace.pageSpace_template_messageList",
                json: data
          });
          $('#pageSpace_messageList').html(html);
        },
        bindTwo: function (data, topId) {
            var html = jsRenderBinding({
                page: "pageSpace.pageSpace_template_messageDetail",
                json: data
            });
            $('#pageSpace_levelOne_' + topId).html(html);
            liuyan.scroller.refresh();
        },
        getLevelOne: function (callback, topid) {
            var msgType = 1;
            var topId = 0;
            if (topid) {
                msgType = 2;
                topId = topid
            }
            var data = {
                toCvNumber: this.params.spaceCvNumber,
                currentCvNumber: this.params.currentCvNumber,
                msgType: msgType,
                pid: 0,
                topId: topId
            };
            ajaxTool.ajaxGet(appUrl('user/msg1'), data, function (result) {
                if (result.result == 10000) {
                    if (result.data.length) {
                        if (msgType == 1) {
                            l.bindOne(result.data);
                        } else {
                            l.bindTwo(result.data, topId);
                        }
                        callback(true);
                    } else {
                        callback(false);
                    }
                    
                }
            });
        },
        addMsg: function (topid,parentid) {
            var msg = {
                ToCvNumber: this.params.receiveCvNumber,
                SendCvNumber: this.params.currentCvNumber,
                TopId: topid || this.params.topid,
                ParentId: parentid || this.params.parentid,
                MsgContent: this.getInputMsg(),
                IsSecret: $('#pageLiuyan_isSecret').hasClass('lock')
            };
            if (!msg.MsgContent) {
                app.alert('说点什么吧');
                return false;
            } else {
                msg.MsgContent = EmojiBM(msg.MsgContent);//如果带表情，需要编码
            }
            ajaxTool.ajaxPost(appUrl('user/addmsg'), msg, function (result) {
                if (l.params.parentid == 0) {
                    var html = jsRenderBinding({
                        page: 'pageSpace.pageSpace_template_messageList',
                        json: result.msg
                    });
                    $('#pageSpace_messageList').prepend(html);
                    liuyan.scroller.refresh();
                } else {
                    var $top = $('#pageLiuyan_liuyanCount_' + l.params.topid);
                    var t = $top.text();
                    t = t.substr(1, t.length - 2);
                    $top.text('(' + (parseInt(t) + 1).toString() + ')');
                    //添加第二级数据
                    var levelTwo = $('#pageSpace_levelOne_' + l.params.topid);
                    if (levelTwo.data('load') == '1') {
                        //已经加载过，直接添加，否则，不添加
                        var html = jsRenderBinding({
                            page: "pageSpace.pageSpace_template_messageDetail",
                            json: result.msg
                        });
                        levelTwo.append(html);
                        liuyan.scroller.refresh();
                    }
                    //最后处理添加完后的流程
                    $("#liuyan textarea").attr('placeholder', '公开留言');
                    $('#pageLiuyan_isSecret').removeClass("hidden");
                    $('#pageLiuyan_isSecret').removeClass("lock");
                    l.params.topid = 0;
                    l.params.parentid = 0;
                }
                //收藏
                $('#space-like').addClass("liked-space");
                $('#space-biog-like').addClass("liked-space");
            });
        },
        delmsg:function(id,level,callback){
            ajaxTool.ajaxPost(appUrl('user/delmsg'), { cvnumber: l.params.currentCvNumber, msgId: id,level:level }, function (result) {
                if (result.result == 10000) {
                    callback(result.data);
                }
            });
        },
        getInputMsg: function () {
            var m = $('#pageLiuyan_messageBox').val();
            m = htmlEncode(m);
            return m;
        }
    }
    //发送
    //清空
    liuyan.on("#pageLiuyan_send", "touchend", function () {
        l.addMsg(0, 0);
        $("#liuyan textarea").val("").trigger("change");

    });
    //恢复
    liuyan.on('#pageLiuyan_leaveMsg', 'touchend', function (e, ev) {
        l.params.topid = 0;
        l.params.parentid = 0;
        $("#liuyan textarea").attr('placeholder', '公开留言');
        $('#pageLiuyan_isSecret').removeClass("hidden");
        l.params.receiveCvNumber = l.params.spaceCvNumber;//当前空间的人
    });
    //回复谁
    liuyan.on('.cmtNum', 'touchend', function (e,ev) {
        var $this = $(ev.self);
        var name = $this.data('name');
        $("#liuyan textarea").attr('placeholder', "回复:" + name);
        $('#pageLiuyan_isSecret').addClass("hidden");
        l.params.topid = $this.data('topid');
        l.params.parentid = $this.data('topid');
        l.params.receiveCvNumber = $this.data('cvnumber');
        $("#liuyan textarea").focus();
    });
    //删除留言
    liuyan.on('.liuyan-tool .del', 'touchend', function (e, ev) {
        var $this = $(ev.self);
        var id = $this.data('id');
        var level = $this.data('level');
        var topid = 0;
        if (level == 1) {
            topid = $this.data('topid');
        }
        app.alert("确认删除此条留言？", [
            {
                title: "确定", fn: function () {
                    l.delmsg(id,level, function (data) {
                        if (data == 10000) {
                            app.hideAlert();
                            $('#pageSpace_msg_' + id).remove();
                            //如果二级留言
                            if (level == 1) {
                                //留言条数内容减一
                                var $top = $('#pageLiuyan_liuyanCount_' + topid);
                                var t = $top.text();
                                t = t.substr(1, t.length - 2);
                                $top.text('(' + (parseInt(t) - 1).toString() + ')');
                            }
                            liuyan.scroller.refresh();
                        } else {
                            
                        }
                    });
                }
            }, { title: "取消", fn: function () { app.hideAlert(); } }]);
    });
    //公开私密
    liuyan.on(".icon-camera", "touchend", function (e, ev) {
        if ($(ev.self).hasClass("lock")) {
            $(ev.self).removeClass("lock");
            $('#pageLiuyan_messageBox').attr("placeholder", "公开留言");
        } else {
            $(ev.self).addClass("lock");
            $('#pageLiuyan_messageBox').attr("placeholder", "私密留言");
        }
    })
    //展开收起
    liuyan.on(".liuyan-text, .liuyan-name", "touchend", function (e, ev) {
        var self = $(ev.self).parents(".table-view-cell");
        var $this = $(ev.self);
        var topId = $this.data('id');
        var loadData = $this.data('load');
        if (loadData == '0') {//没加载就加载，否则不加载
            l.getLevelOne(function (hasData) {
                if (hasData) {
                    $(self).hasClass("open") ? $(self).removeClass("open") : $(self).addClass("open");
                }
                $this.data('load', 1);
                $('#pageSpace_levelOne_'+topId).data('load',1);
                liuyan.scroller.refresh();
            }, topId);
           
        } else {
            if ($('#pageSpace_levelOne_' + topId).find('li').length) {
                $(self).hasClass("open") ? $(self).removeClass("open") : $(self).addClass("open");
            }
        }
        liuyan.scroller.refresh();
    });
    $.views.helpers({
        transDate: function (date) {
            return GetDateDiff(date);
        }
    });
})(jQuery)