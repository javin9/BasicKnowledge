(function($){
	var tagSet = pageThingTagSet;
	tagSet.iscroller = null;
	var articleId = tagSet.getParam('id'), privacy = tagSet.getParam("privacy");
	tagSet.onPageLoadInit = function(){
		tagSet.iscroller = app.iscroll(".thingTagList");
	}
	tagSet.on(".thingTagList li","touchend",function(e,ev){
		var val = $(ev.self).text();
		$(ev.self).addClass("checked");
		$("#thing-tag-input").val(val).focus();
	})
    //updatelabel
	tagSet.on(".pull-right", "touchend", function () {
	    var label = $("#thing-tag-input").val(), labelType = $(".thingTagList li[class*='checked']").data("id");
	    if (!!label) {
	        ajaxTool.ajaxPost(appUrl("updatelabel"), { articleId: articleId, label: label, labelType: labelType }, function (result) {
	            console.log(result);
	            if (result.result == 10000) {
	                R.to("pageThingSet?articleId=" + articleId + "&privacy=" + privacy, "", "");
	            }
	        });
	    } else {
	        app.alert("�����ñ�ǩ");
	    }
	});
})(jQuery);
