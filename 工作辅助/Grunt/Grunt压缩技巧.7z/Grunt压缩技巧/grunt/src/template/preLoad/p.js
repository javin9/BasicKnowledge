﻿/*
*p.js
*基础数据帮助js
*创建：fyp
*修改时间：2015-12-7
*/
(function ($) {
    //临时缓存
    var xzbCache = {
        cacheP: null,//职能缓存
        cacheE: null,//教育阶段缓存
        cacheX: null,//系缓存
        cacheZ: null,//专业缓存
        cacheB: null,//班级缓存
        cacheI: null //身份信息
    };
    var _cache = xzbCache;

    /*flag和数据库字段对应，一般不做修改*/
    var flag = {
        x: 3,//系
        z: 4,//专业
        b: 5,//班级
        e: 1,//阶段
        p: 2,//职能
        y: 8,//年份
        i: 9 //身份
    };
    /*获取数据*/
    var xzb = {
        cache: null,
        getXZB: function () {
            return appBase;//这里是预加载的
        }
    };

    var defaultOptions = {
        t: 'e',//类型 x z b
        year: 2008,
        eid: 0,
        parentid: 0,
        topid: 0
    };

    function handleI(json) {
        var arr = [];
        $.each(json, function (i, item) {
            arr.push({
                id: item.id,
                flag: item.flag,
                name: item.name
            });
        });
        return arr;
    }

    var xzbTools = {
        data: {
            //domain信息
            domain: function () {
                return xzbTools.getDomain();
            },
            /*平台信息*/
            plat: function () {
                return xzbTools.getPlat();
            },
            allIDSelected: function () {
                return xzbTools.getIdSelect();
            },
            /*模板类型*/
            alltemplateType: function () {
                return xzbTools.getTemplateType();
            },
            /*年份*/
            allYear: function (eid) {
                var year = xzbTools.getMinYear(eid);
                var d = new Date();
                var nowYear = d.getFullYear();
                var arr = [];
                for (var i = nowYear; i >= year; i--) {
                    arr.push({
                        id: i,
                        flag: flag.y,
                        text: i + '级'
                    });
                }
                return arr;
            },
            /*所有身份*/
            allI: function () {
                if (!_cache.cacheI) {
                    var j = handleI(xzbTools.getAll(flag.i));
                    _cache.cacheI = j;
                }
                return _cache.cacheI;
            },
            /*所有阶段*/
            allE: function () {
                if (!_cache.cacheE) {
                    _cache.cacheE = xzbTools.getAll(flag.e);
                }
                return _cache.cacheE;
            },
            /*所有职能*/
            allP: function () {
                if (!_cache.cacheP) {
                    _cache.cacheP = xzbTools.getAll(flag.p);
                }
                return _cache.cacheP;
            },
            /*所有系*/
            allX: function () {
                if (!_cache.cacheX) {
                    _cache.cacheX = xzbTools.getAll(flag.x);
                }
                return _cache.cacheX;
            },
            /*所有专业*/
            allZ: function () {
                if (!_cache.cacheZ) {
                    _cache.cacheZ = xzbTools.getAll(flag.z);
                }
                return _cache.cacheZ;
            },
            /*所有班级*/
            allB: function () {
                if (!_cache.cacheB) {
                    _cache.cacheB = xzbTools.getAll(flag.b);
                }
                return _cache.cacheB;
            },
            /*过滤阶段*/
            filterE: function (year) {
                return this.filter({
                    t: 'e', year: year
                });
            },
            /*过滤系*/
            filterX: function () {
                return this.filter({
                    t: 'x'
                });
            },
            /*过滤专业*/
            filterZ: function (xid, eid) {
                xid = xid || 0;
                eid = eid || 0;
                return this.filter({
                    t: 'z',
                    parentid: xid,
                    eid: eid
                });
            },
            /*过滤班级*/
            filterB: function (year, eid) {
                year = parseInt(year);
                eid = parseInt(eid);
                return this.filter({
                    t: 'b',
                    eid: eid,
                    year: year
                });
            },
            /*总过滤器*/
            filter: function (options) {
                $.extend(defaultOptions, options);

                var filterYear = parseInt(options.year) > 0;
                var filterParentId = parseInt(options.parentid) > 0;
                var filterTopId = parseInt(options.topid) > 0;
                var filterEid = options.eid > 0;
                var arr = [];
                switch (options.t) {
                    case 'e':
                        arr = this.allE();
                        //根据年份筛选
                        if (filterYear) {
                            return $.grep(arr, function (item, i) {
                                if (item.endtime > 0) {
                                    return item.starttime <= options.year && item.endtime >= options.year;
                                }
                                return item.starttime <= options.year;
                            });
                        }
                        return arr;
                        break;
                    case 'x':
                        arr = this.allX();
                        //根据年份查询
                        if (filterYear) {
                            arr = $.grep(arr, function (item, i) {
                                if (item.endtime > 0) {
                                    return item.starttime <= options.year && item.endtime >= options.year;
                                }
                                return item.starttime <= options.year;
                            });
                        }
                        if (filterEid) {
                            arr = $.grep(arr, function (item, i) {
                                return item.phaseid == options.eid;
                            });
                        }
                        break;
                    case 'z':
                        arr = this.allZ();
                        //根据年份查询
                        if (filterYear) {
                            arr = $.grep(arr, function (item, i) {
                                if (item.endtime > 0) {
                                    return item.starttime <= options.year && item.endtime >= options.year;
                                }
                                return item.starttime <= options.year;
                            });
                        }
                        if (filterEid) {
                            arr = $.grep(arr, function (item, i) {
                                return item.phaseid == options.eid;
                            });
                        }
                        if (filterParentId) {
                            arr = $.grep(arr, function (item, i) {
                                return item.parentid == options.parentid;
                            });
                        }
                        break;
                    case 'b':
                        //班级单独处理
                        arr = this.allB();
                        //根据年份查询
                        if (!filterYear) {
                            filterYear = true;
                            var d = new Date();
                            var nowYear = d.getFullYear();
                            options.year = nowYear;
                        }
                        arr = $.grep(arr, function (item, i) {
                            if (item.endtime > 0) {
                                return item.starttime <= options.year && item.endtime >= options.year;
                            }
                            return item.starttime <= options.year;
                        });
                        //根据阶段
                        if (!filterEid) {
                            var e = this.allE();
                            options.eid = e.length ? e[0].id : 0;
                        }
                        if (options.eid) {
                            filterEid = true;
                            arr = $.grep(arr, function (item, i) {
                                return item.phaseid == options.eid;
                            });
                        }
                        //根据顶级ID
                        if (filterTopId) {
                            arr = $.grep(arr, function (item, i) {
                                return item.topid == options.topid;
                            });
                        }
                        //根据父级ID
                        if (filterParentId) {
                            arr = $.grep(arr, function (item, i) {
                                return item.parentid == options.parentid;
                            });
                        }
                        //处理班级数据
                        var x = this.allX();
                        var z = this.allZ();
                        for (var i = 0; i < arr.length; i++) {
                            var top, parent;
                            parent = $.grep(z, function (item, m) {
                                return item.id == arr[i].parentid;
                            });
                            if (!parent.length) {
                                parent = $.grep(x, function (item, m) {
                                    return item.id == arr[i].parentid;
                                });
                            }
                            top = $.grep(x, function (item, m) {
                                return item.id == arr[i].topid;
                            });
                            if (!top.length) {
                                top = $.grep(z, function (item, m) {
                                    return item.id == arr[i].topid;
                                });
                            }
                            if (top.length) {
                                arr[i].topflag = top[0].flag;
                            } else {
                                arr[i].topflag = 0;
                            }
                            if (parent.length) {
                                arr[i].parentflag = parent[0].flag;
                            } else {
                                arr[i].parentflag = 0;
                            }
                            if (filterYear) { arr[i].year = options.year; arr[i].yearflag = flag.y; }
                            if (filterEid) { arr[i].eid = options.eid; arr[i].eflag = flag.e; }
                        }
                        break;
                    default:
                        return [];
                        break;
                }
                if (!arr.length) {
                    return [];
                }
                return arr;
            }
        },
        /*console.log*/
        log: function (msg) {
            //console.log(msg);
        },
        /*获取xzb每个的最多条数，不加过滤*/
        getAll: function (flag) {
            if (!flag) { return []; }
            var p = xzb.getXZB();
            var data = p.info;
            var x = $.grep(data, function (item, i) {
                return item.flag == flag;
            });
            var arr = [];
            $.each(x, function (i, item) {
                var newItem = {
                    unionId: item.unionId,
                    id: item.id,
                    name: item.xzbname,
                    flagname: item.flagName,
                    topid: item.topid,
                    parentid: item.parentid,
                    phaseid: item.phaseid,
                    flag: item.flag,
                    starttime: item.starttime,
                    endtime: item.endtime
                };
                if (newItem.id > 0) {
                    if (!xzbTools.isExist(newItem, arr)) {
                        arr.push(newItem);
                    }
                }
            });
            return arr;
        },
        /*获取最小年份*/
        getMinYear: function (eid) {
            var p = xzb.getXZB();
            var data = p.info;
            var year = 0;
            if (eid) {
                var arr = $.grep(data, function (item, i) {
                    return item.flag == flag.e && item.id == eid;
                });
                if (arr.length) {
                    year = arr[0].starttime;
                }
            } else {
                $.each(data, function (i, item) {
                    if ((year == 0) || (item.starttime != 0 && item.starttime < year)) {
                        year = item.starttime;
                    }
                });
            }
            return year;
        },
        /*获取平台基础信息*/
        getPlat: function () {
            var p = xzb.getXZB();
            return p.plat;
        },
        /*获取domain信息*/
        getDomain: function () {
            var p = xzb.getXZB();
            return p.domain;
        },
        /*获取身份选择的项目*/
        getIdSelect: function () {
            var p = xzb.getXZB();
            return p.id_select;
        },
        /*获取模板类型*/
        getTemplateType: function (flagid) {
            var p = xzb.getXZB(), result = '';
            if (isNaN(flagid)) {
                result = p.templateType;
            } else {
                var list = p.templateType;
                (function () {
                    for (var i = 0, len = list.length; i < len; i++) {
                        if (list[i].DataId == flagid) {
                            result = list[i].Name;
                            break;
                        }
                    }
                })();
            }
            return result;
        },
        /*根据id判断是否存在*/
        isExist: function (obj, arr) {
            for (var i = 0; i < arr.length; i++) {
                if (arr[i].unionId === obj.unionId) {
                    return true;
                }
            }
            return false;
        }
    };

    /*数据绑定，跟页面业务挂钩*/
    /*
    ele：外层div
    selected：选中的身份id
    titleID:选择身份标题

    修改人：Cupid
    事件：“2016-1-25 12:00:00
   内容：添加了titleID参数，用于注册第三步，判断div是否显示

    */
    var bind = {
        //绑定身份ID
        bindID: function (ele, selected, titleID) {
            var data = xzbTool.data.allI();
            console.log(data.length);
            console.log(ele);

            if ( data.length == 1) {
                $(titleID).hide()//注册第三步用
                $(ele).hide(); //身份栏目
            } else {
                $(titleID).show()//注册第三步用
                $(ele).show();//身份栏目
            }

            var selected = selected || 0;
            var html = '';
            $.each(data, function (i, item) {
                var c = '',
                    id = item.id;
                if (selected == 0) {
                    if (i == 0) { c = 'class="shenfen-curent"'; }
                } else {
                    if (id == selected) { c = 'class="shenfen-curent"'; }
                }

                html += ' <span data-type = "' + item.id + '" ' + c + '>' + item.name + '</span>';
            });
            $(ele).html(html);
        },
        //依赖jsrender
        bindYear: function (ele, eid) {
            var template = '<li class="table-view-cell" data-flag="{{:flag}}" data-value="{{:id}}">{{:text}}</li>';
            var year = xzbTools.data.allYear(eid);
            var html = this.render(template, year);
            $(ele).html(html);
        },
        //绑定阶段
        bindJD: function (ele) {
            var template = '<span class="selecter-right-title-cell" data-flag="{{:flag}}" data-value="{{:id}}">{{:name}}</span>';
            var jd = xzbTools.data.allE();
            var html = this.render(template, jd);
            $(ele).html(html);
        },
        //左侧阶段
        bindLeftJD: function (ele) {
            var template = '<li class="table-view-cell" data-flag="{{:flag}}" data-value="{{:id}}">{{:name}}</li>';
            var edu = xzbTools.data.allE();
            var html = this.render(template, edu);
            $(ele).html(html);
        },
        //左侧系
        bindLeftXi: function (ele) {
            var template = '<li class="table-view-cell" data-flag="{{:flag}}" data-value="{{:id}}">{{:name}}</li>';
            var x = xzbTools.data.allX();
            var html = this.render(template, x);
            $(ele).html(html);
        },
        //右侧专业
        bindRightZY: function (ele, x) {
            var template = '<li data-flag="{{:flag}}" data-value="{{:id}}" class="table-view-cell"><span class="btn-checkbox" data-flag="{{:flag}}"  data-value="{{:id}}">{{:name}}</span><input type="hidden" value="off" /></li>';
            var zy = xzbTools.data.filterZ(x, 0);
            var html = this.render(template, zy);
            $(ele).html(html);
        },
        //右侧年份
        bindRightYear: function (ele, eid) {
            var template = '<li class="table-view-cell" data-flagid="{{:flag}}" data-joinid="{{:id}}" ><span data-flagid="{{:flag}}" data-joinid="{{:id}}" class="btn-checkbox">{{:text}}</span><input type="hidden" value="off" /></li>';
            var year = xzbTools.data.allYear(eid);
            var html = this.render(template, year);
            $(ele).html(html);
        },
        //绑定班级
        bindClass: function (ele, r) {
            var template = '<li class="table-view-cell" data-flagid="{{:flag}}" data-joinid="{{:id}}" ><span data-flagid="{{:flag}}" data-joinid="{{:id}}" class="btn-checkbox">{{:name}}</span><input type="hidden" value="off" /><i class="zy" data-flagid="{{:parentflag}}" data-joinid="{{:parentid}}" ></i><i class="xs" data-flagid="{{:topflag}}" data-joinid="{{:topid}}" ></i></li>';
            var year, eid;
            if (r) {
                year = r.year;
                eid = r.eid;
            }
            var nj = xzbTools.data.filterB(year, eid);
            var html = this.render(template, nj);
            $(ele).html(html);
        },
        //绑定系
        bindXi: function (ele) {
            var template = '<li data-flag="{{:flag}}" data-value="{{:id}}" class="table-view-cell"><span class="btn-checkbox" data-flag="{{:flag}}"  data-value="{{:id}}">{{:name}}</span><input type="hidden" value="off" /></li>';
            var x = xzbTools.data.allX();
            var html = this.render(template, x);
            $(ele).html(html);
        },
        //绑定职能
        bindZn: function (ele) {
            var template = '<li data-flag="{{:flag}}" data-value="{{:id}}" class="table-view-cell"><span class="btn-checkbox" data-flag="{{:flag}}"  data-value="{{:id}}">{{:name}}</span><input type="hidden" value="off" /></li>';
            var zn = xzbTools.data.allP();
            var html = this.render(template, zn);
            $(ele).html(html);
        },

        /*
        作用:绑定身份选择项目
        参数说明: 1.selectId 身份选项卡对应的内容
                         2.identityId 身份选项卡
        */
       
        bindIdSelect: function (selectId, identityId) {
            var list = xzbTools.data.allIDSelected(),
                nowRegid = 0,
                 tagName = "",
                 str1 = '',
                   showId = $(identityId).find("span.shenfen-curent").attr("data-type"),
                   that = this;
            console.log(list);
            console.log('············');
            (function () {

                for (var i = 0, len = list.length; i < len; i++) {
                    var $this = list[i],
                        dataId = $this.DataId,
                    regId = $this.RegId,
                            isShow = regId == showId ? "show" : "";
                    if (i == 0) {
                        tagName = "tag" + regId;
                        str1 += '<div data-tag="' + regId + '" class="indAdd-tag ' + isShow + '"  id="' + tagName + '" >';
                    } else if (regId != nowRegid) {
                        tagName = "tag" + regId;
                        str1 += '</div><div data-tag="' + regId + '" class="indAdd-tag"  id="' + tagName + '" >';
                    }

                    if (parseInt($this.Operation) !== 0) {
                        str1 += '<ul class="table-view top15  selectobj"> <li class="table-view-cell indAdd"><span class="navigate-right"   data-selectId=' + dataId + '>' + $this.Name + '</span></li></ul>';
                        //生成对应的选择的div内容
                        var selectHtml = that.showDiv($this.Operation, dataId);
                        str1 += selectHtml;
                    } else {
                        str1 += '<div class="input-row top15"> <input type="text"  class="customtxt"  data-columnId="' + $this.ColumnId + '"   data-name="' + $this.Name + '"  placeholder="' + $this.Name + '" /></div>';
                    }
                    nowRegid = regId;

                    if (i + 1 == len) {
                        str1 += '</div>';

                    }
                }
            })();

            $(selectId).html(str1);
            var tagIndex = $(identityId).find("span.shenfen-curent").attr("data-type");
            $(selectId).find("#tag" + tagIndex).show();
        },
        /*单向选择*/
        _singleSelect: function (dataid) {
            var name = xzbTools.getTemplateType(dataid);
            var template = '<div class="selecter" data-template="1" data-typeid="' + dataid + '"  data-typeName="' + name + '"><div class="selecter-right"><div class="selecter-right-list"  id="list' + dataid + '"><ul class="table-view">{{for data}}<li  class="table-view-cell"><span class="btn-checkbox" data-flagid="{{:flag}}" data-joinid="{{:id}}" >{{:name}}</span><input type="hidden" value="off" /></li>{{/for}}</ul></div></div></div>';
            var data = { data: xzbTools.getAll(dataid) };
            var html = this.render(template, data);
            return html;
        },
        /*班级数据*/
        _thrSelect: function () {
            var jd_year = {
                jd: xzbTools.data.allE(),
                year: xzbTools.data.allYear()
            },
             name = xzbTools.getTemplateType(5),
            template = '<!--选择班级 start--><div class="selecter"  data-type="5"  data-template="3" data-typeName="' + name + '"><div class="selecter-left"><h3 class="selecter-all">班级</h3><div class="selecter-left-list" id="list5"><ul class="table-view table-selecter">{{for year}}<li class="{{:#index==0?\'table-view-cell current\':\'table-view-cell\'}}" data-flagid="{{:flag}}" data-joinid="{{:id}}" >{{:text}}</li> {{/for}}</ul></div></div><div class="selecter-right"><div class="selecter-right-title">{{for  jd}}<span class="{{:#index==0?\'selecter-right-title-cell current\':\'selecter-right-title-cell\'}}" data-flagid="{{:flag}}" data-joinid="{{:id}}" >{{:name}}</span>{{/for}}</div><div class="selecter-right-list" id="class-name-list"><ul class="table-view" id="banji">{0}</ul></div></div></div><!--选择班级 end-->';
            var html = this.render(template, jd_year);
            //年级
            var bj = xzbTools.data.filterB(0, 0),
                  banjiTemplate = '<li class="table-view-cell" ><span data-flagid="{{:flag}}" data-joinid="{{:id}}"  class="btn-checkbox">{{:name}}</span><input type="hidden" value="off" /><i class="zy" data-flagid="{{:parentflag}}" data-joinid="{{:parentid}}" ></i><i class="xs" data-flagid="{{:topflag}}" data-joinid="{{:topid}}" ></i></li>';
            var bjhtml = this.render(banjiTemplate, bj);
            //返回班级数据
            return html.format([bjhtml]);;
        },
        showDiv: function (operation, dataid) {
            var result = '';
            //Operation
            switch (parseInt(operation)) {
                case 1:
                    result = this._singleSelect(dataid);
                    break;
                case 3:
                    result = this._thrSelect(dataid);
                    break;
            }
            return result;
        },
        /*字符串模板绑定*/
        render: function (template, json) {
            var t = $.templates(template);
            var html = t.render(json);
            return html;
        }
    };

    //对象赋值
    xzbTools.bind = bind;
    //window
    window.xzbTool = xzbTools;


})(jQuery)
//公共domain
var domain = xzbTool.data.domain();

$(function () {
    var plat = xzbTool.data.plat();
    $('#main_menutitle').text((plat[0].menu_title || '记忆'));
});

