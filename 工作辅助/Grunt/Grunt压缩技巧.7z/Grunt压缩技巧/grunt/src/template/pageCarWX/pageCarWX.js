﻿; (function ($) {
    pageCarWX.onPageLoad = function () {
        pageCardHelper.setinfo('pageCar_weixin', 'weixin');
    }
    //保存
    pageCarWX.on('.pull-right', 'touchend', function (e, ev) {
        pageCardHelper.updateinfo('pageCar_weixin', 'weixin');
    });
})(jQuery);