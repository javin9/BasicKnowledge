﻿(function ($) {
    /*初始化reg1*/
    reg1.init = function () {
        console.log("reg1");
        var footerData = xzbTool.data.plat()[0];
        if (!isNull(footerData.foot_left_title)) {
            $("#reg1leftStr").text(footerData.foot_left_title);
        }
        if (!isNull(footerData.foot_right_title)) {
            $("#reg1rightStr").text(footerData.foot_right_title);
        }
    };
    reg1.onPageLoad = function () {
        $("#redirectto").hide();
        $("#telInput").val(reg1.getParam().mobile);
    };
    reg1.on("#reg_next", "touchend", function (e, ev) {
        var that = $(e.target),
            mobile = $("#telInput").val(),
            isValid = regex_data.IsPhone.test(mobile);

        if (!isValid) {
            app.alert('请输入有效的手机号');
            return false;
        }

        if (isValid) {
            if (!that.hasClass('btn-disabled')) {
                CheckMobileIsExist({
                    id: "#reg1_page  #reg_next",
                    mobile: mobile,
                    callback: checkMobileExistcallback,
                    bsFunc: checkExistbsFunc
                });
            }
        }
    });
    reg1.on("#regtopwd", "touchend", function () {
        console.log($("#telInput").val());
        R.to("pageBackPwd1", '9', { mobile: $("#telInput").val() });
    });
    reg1.on("#regtologin", "touchend", function () {
        console.log($("#telInput").val());
        R.to("login", '9', { mobile: $("#telInput").val() });
    });
    //检验手机号是否存在beforeSend
    function checkMobileExistcallback(mobile) {
        disableReg_1();
        //envObj.SaveLocals("mobile_cupid", mobile)
    }

    /*检验手机号是否存在回调*/
    function checkMobileExistcallback(json) {
        console.log(json);
        if (json.result == 10000) {
            console.log(json.data);
            var data = json.data;
            envObj.SaveLocals("regmobile", data.phone || $("#telInput").val());

            R.to('reg2');
            ableReg_1();//启用按钮
        } else if (json.result == 14017) {
            app.alert(json.msg);
            $("#redirectto").show();
            ableReg_1();
        } else {
            app.alert(json.msg);
            ableReg_1();//启用按钮
        }
    }
    //检验手机号是否存在beforeSend
    function checkExistbsFunc(mobile) {
        disableReg_1();
    }
    //启用注册第yi步按钮
    function ableReg_1() {
        $("#reg_next").removeClass('btn-disabled').text('下一步');
    }
    //禁用注册第yi步按钮
    function disableReg_1() {
        $("#reg_next").addClass('btn-disabled').text('发送验证码···');
    }
})(jQuery);
