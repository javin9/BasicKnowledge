(function($){
	var mesCont = pageMesCont;
	mesCont.iscroller = null;
	mesCont.loadingMore = false;
	mesCont.onPageLoadInit = function(){
		mesCont.iscroller = app.iscroll("#page-mesCont");
		
		//下拉刷新和加载更多-------------前端使用
		mesCont.iscroller.on("scroll",function(){
			if(this.y>=40 && !mesCont.loadingMore){
				$("#mesCont-downPull span").html("松开加载更多");
				this.minScrollY = 40;	
				$("#mesCont-downPull").addClass("now");
			}else if(this.y>0&&this.y<40 && !mesCont.loadingMore){
				$("#mesCont-downPull span").html("下拉加载更多");
				this.minScrollY = 0;	
				$("#mesCont-downPull").removeClass("now");
			}
		});
		//下拉刷新和加载更多预备调用
		mesCont.iscroller.on("scrollEnd",function(){
			if(!mesCont.loadingMore){
				if($("#mesCont-downPull").hasClass("now")){
					$("#mesCont-downPull span").addClass("preloader");
					mesCont.loadingMore = true;
					//调用加载更多函数
				}else{
					$("#mesCont-downPull span").removeClass("preloader").html('&nbsp;');
				}
			}
			
		});
		setTimeout(function(){
			mesCont.iscroller.scrollTo(0,mesCont.iscroller.maxScrollY,0)
		},100)
		
	}
	

    //范月盘
	mesCont.onPageLoad = function () {
	    msg.init();
	}

    //getmynotice
	var msg = {
	    params: {
	        sendcv: 0,
            receivecv:0
	    },
	    init: function () {
	        this.params.sendcv = R.getPara('cv', 'cv');
	        this.params.receivecv = getCurrentCV();
	        this.data.notice();
	    },
	    data: {
	        notice: function (callback) {
	            ajaxTool.ajaxGet(appUrl('/user/getmynotice'), { sendcv:msg.params.sendcv, receivecv:msg.params.receivecv }, function (result) {
	                if (result.result == 10000) {
	                    msg.bind.list(result.data);
	                    $('#pageMessageContent_title').text(result.data.length ? result.data[0].send_name : '');
	                } else {
	                    app.alert('消息加载失败！');
	                }
	            });
	        }
	    },
	    bind: {
	        list: function (json) {
	            var html = jsRenderBinding({
	                page: 'pageMessageContent.pageMessageContent_template_msgList',
	                json: json
	            });
	            $('#pageMessageContent_msgList').html(html);
	            //绑定基础信息
	        }
	    }
	};

	$.views.helpers({
	    transDate: function (date) {
	        return GetDateDiff(date);
	    }
	});
})(jQuery)