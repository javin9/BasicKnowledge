(function ($) {
    var see = pageExperSee;
    see.iscroller = null;
    see.initPhoto = null;
    see.loadingMore = false;
    see.com = true;
    see.like = false;
    see.with = false;
    see.name = '';
    see.cvnumber = 0;
    see.rcvnumber = 0;
    see.topid = 0;
    see.parentid = 0;
    see.pageindex = 1;
    see.pagecount = 1;
    see.contents = "";
    see.isLoading = false;
    var editor, articleId = 0;

    see.onPageLoadInit = function () {
        see.iscroller = app.iscroll("#page-exper-see");

        app.autoArea("#exper-message");

        //加载更多评论
        see.iscroller.on("scrolling", function () {
            var tag = $("#exper-preview-tag").offset().top,
				navbar = $("#exper-preview-tag").parents(".page").find(".headerBar").eq(0).height();
            if (tag - navbar < 0) {
                $("#exper-preview-fixed-tag").addClass("visible");
            } else {
                $("#exper-preview-fixed-tag").removeClass("visible");
            }
        })
        //加载更多预备调用
        see.iscroller.on("scrollEnd", function () {
            if (this.y == this.maxScrollY && !see.loadingMore && see.com && see.pageindex <= see.pagecount) {
                $("#exper-com-more span").addClass("preloader");
                see.loadingMore = true;
                //调用加载更多评论函数
                see.getCommentPraise(articleId, 1, 0, (see.pageindex + 1));

            } else if (this.y == this.maxScrollY && !see.loadingMore && see.like && see.pageindex <= see.pagecount) {
                $("#exper-like-more span").addClass("preloader");
                see.loadingMore = true;
                //调用加载更多喜欢函数
                see.getCommentPraise(articleId, 2, 0, (see.pageindex + 1));
            } else if (this.y == this.maxScrollY && !see.loadingMore && see.with && see.pageindex <= see.pagecount) {
                $("#exper-with-more span").addClass("preloader");
                see.loadingMore = true;
                //调用加载更多同行函数
                see.getCommentPraise(articleId, 3, 0, (see.pageindex + 1));
            }

        });

     
    }
    see.onPageLoad = function () {
        articleId = see.getParam('id');
        if (R.prePage.name == "pageExperWither") {  $(".page-see-content,#pagecomment,#pagelike,#pagewith").html(""); see.getContents(); };
            $(".page-see-content,#pagecomment,#pagelike,#pagewith").html("");
            see.getContents();
            see.addBrowse();
        
    };
    //编辑
    see.on("#btnedit", "touchend", function () {
        R.to("pageExperEditor?Id=" + articleId, "", "");
    })
    //删除del
    see.on(".del", "touchend", function () {
        app.alert("确定删除吗？", [{
            title: "确定", fn: function () {
                app.hideAlert();
                see.DelArtilce();
               
            }
        },
        { title: "取消", fn: function () { app.hideAlert(); } }], "删除提示");
    })
    //内容模板
    var contenthtml = '<div class="create-name" data-cv="{4}"><div class="create-name-mox" data-route-to="{3}"><span>{0}</span><span>{1}</span> </div></div><div class="app-editor-content" data-cv="{4}">{2}</div>';
    //头部模板
    var titlehtml = '{0}<div class="preview-header"><span class="preview-time">{1}</span><span class="preview-title">{2}</span> </div><em class="preview-info"><span data-route-to="">{3}</span>始发于{4}&nbsp;&nbsp;{5}人参与记忆&nbsp;&nbsp;{6}人查看</em>';
    //头部背景
    var backhtml = '<div class="preview-background" id="preview-back-exper"><img src="{0}"  class="" data-src="{0}"  data-size="{1}" /></div>';
    //加载主体内容和补充内容
    see.getContents = function () {
        ajaxTool.ajaxPost(appUrl("getarticlebyid"), { articleId: articleId, type: 1, cvnumber: getCurrentCV(), articleType:1 }, function (result) {
            console.log(result);
            if (result.result == 10000) {
                if (!!result.data) {
                    var data = result.data, html;
                    if (data.id > 0) {
                        var firstTime = data.start_time, firstForamt = data.start_type, lastTime = data.end_time, lastForamt = data.end_type;
                        var time = TimeTrans.toText(firstTime, firstForamt, lastTime, lastForamt);
                        html = titlehtml.format1(!!data.back_img ? backhtml.format1(domain.imgUrl + data.back_img, (data.width + "*" + data.height)) : "", time.main + '<em>' + time.more + '</em>', EmojiJM(data.title), data.name, DateTime(data.add_time, 1), data.partake, data.browse_show == 0 ? 1 : data.browse_show);
                        $(".page-see-content").append(html);
                        $("#witherid").val(data.witherid);
                        var fb_cvnumber = data.cv_number;
                        if (fb_cvnumber == getCurrentCV()) {//自己进来
                            $("#exper-share").show();
                            $("#exper-with").hide();
                            $("#page_zj").show();
                            $("#page_br").hide();
                        } else {
                            $("#exper-share").hide();
                            $("#exper-with").show();
                            $("#page_zj").hide();
                            $("#page_br").show();
                        }
                        var commentHtml = "";
                       // commentHtml += contenthtml.format1(data.name, DateTime(data.add_time, 1), EmojiJM(data.contents), "", data.cv_number);
                        if (!!data.listContent) {
                            for (var i = 0; i < data.listContent.length; i++) {
                                commentHtml += contenthtml.format1(data.listContent[i].uname, DateTime(data.listContent[i].addTime, 1), EmojiJM(data.listContent[i].contents), "", data.listContent[i].cvnumber);
                            }
                        }
                       
                        $(".preview-info").after(commentHtml);
                        //if (data.contents.length ==0) {
                        //    $(".create-name[data-cv=" + fb_cvnumber + "]").hide();
                        //    $(".app-editor-content[data-cv=" + fb_cvnumber + "]").hide();
                        //} 
                        var drophtmlContent = dropHtml(data.contents);
                       
                        wxShare.init({
                            page: 'pageExperSee',
                            title: EmojiJM(data.title),
                            desc: "发布者:" + data.name + "\n" + (drophtmlContent.length > 20 ? drophtmlContent.substring(0, 20) : drophtmlContent),
                            imgUrl: !!data.back_img ? data.back_img : data.head_photo
                        });
                        setTimeout(function () {
                            see.iscroller.refresh();
                        },500);
                        see.initPhoto = app.initPhoto("#page-exper-see .page-see-content");
                        see.getCommentPraise(articleId, 1, 1, 1);
                        if (!!data.back_img) ArticleBackPic(SS("#preview-back-exper"));
                    } else {
                        app.alert("你访问的经历不存在！");

                    }
                }
            }
        });
    };
    //获取 下的数字  评论  点赞  同行
    see.getCommentPraise = function (id, type, numtype, pageindex) {
        ajaxTool.ajaxPost(appUrl("getcomment"), { id: id, type: type, numtype: numtype, cvnumber: getCurrentCV(), pageIndex: pageindex },
            function (result) {
                console.log(result);
                if (result.result = 10000) {
                    if (numtype == 1) {
                        if (!!result.data.numlist) {
                            var praise = result.data.numlist.praise;
                            var comm = result.data.numlist.comm;
                            var colle = result.data.numlist.colle;
                            $("#exper-header-like i").html("(" + praise + ")");
                            $("#exper-header-like").attr("data-like", praise);
                            $("#exper-header-com i").html("(" + comm + ")");
                            $("#exper-header-com").attr("data-com", comm);
                            $("#exper-preview-fixed-tag,#exper-preview-tag").html($("#template_tag").render(result.data.numlist));
                           
                            $('#exper-preview-tag span').eq(type - 1).addClass("preview-list-tag-active").siblings().removeClass("preview-list-tag-active");
                            $("#exper-preview-fixed-tag span").eq(type - 1).addClass("preview-list-tag-active").siblings().removeClass("preview-list-tag-active");
                            $("#tongxing i").html(colle);
                        }
                    }
                    if (!!result.data.pageing) {
                        see.pageindex = result.data.pageing.pageindex;
                        see.pagecount = result.data.pageing.pagecount;
                        if (see.pageindex == 1) {
                            $("#pagecomment,#pagelike,#pagewith").html("");
                        }
                    }
                    if (type == 1) { //评论模板
                        if (result.data.comm != null && result.data.comm.length > 0) {
                            $("#pagecomment").append($("#template_coment").render(result.data));
                        }
                    } else if (type == 2) {
                        if (result.data.praisecom != null && result.data.praisecom.length > 0) {
                            $("#pagelike").append($("#template_like").render(result.data));
                            if (result.data.opernum > 0) { //自己已赞
                                $("#exper-like").addClass("liked").attr("data-id", result.data.id);
                            } else {
                                $("#exper-like").removeClass("liked").attr("data-id", 0);
                            }
                        }
                    } else if (type == 3) {
                        if (result.data.praisecom != null && result.data.praisecom.length > 0) {
                            $("#pagewith").append($("#template_like").render(result.data));
                        }
                    }

                   
                    see.loadingMore = false;
                    if (type == 1) {
                        $("#exper-com-more span").removeClass("preloader").html("&nbsp;");
                        $("#exper-com-more").removeClass("now");
                    } else if (type == 2) {
                        $("#exper-like-more span").removeClass("preloader").html("&nbsp;");
                        $("#exper-like-more").removeClass("now");
                    } else if (type == 3) {
                        $("#exper-with-more span").removeClass("preloader").html("&nbsp;");
                        $("#exper-with-more").removeClass("now");
                    }
                    //刷新滚动条
                    see.iscroller.refresh();
                }
            });
    }
    //删除
    see.DelArtilce = function () {
        ajaxTool.ajaxPost(appUrl("delarticle"), { id: articleId, type: 1 }, function (result) {
            console.log(result);
            if (result.result == 10000) {
                ExperLocData();
                app.alert("删除成功！");
                R.to(-1);
            }
        });
    }
    //喜欢点赞
    see.PraiseAdd = function (articleId, cvnumber, flag) {
        ajaxTool.ajaxPost(appUrl("addpraise"), { articleId: articleId, cvnumber: cvnumber, flag: flag, articleType: 1 }, function (result) {
            console.log(result);
            if (result.result == 10000) {
                if (!!result.data) {
                    var resdata = $.parseJSON(result.data);

                    var praisehtml = ' <li class="table-view-cell" data-id="{3}">'
                     + '<img src="{0}" />'
                     + '<span class="liuyan-name" data-route-to="{4}">{1}</span>'
                     + '<span class="liuyan-text">{2}</span>'
                     + '</li>';
                    if (flag == 0) {
                        appUser.get(getCurrentCV(), function (result) {
                            $("#pagelike").prepend(praisehtml.format1(result.headphoto, result.name, !!result.identity_title ? result.identity_title : "", resdata[0].id, "pageSpace?cv=" + result.cvnumber));
                        });
                    } else {
                        $("#pagelike li[data-id=" + resdata[0].id + "]").remove();
                    }
                    ExperLocData();
                }
            }
        });
    }
    //add评论
    see.addComment = function (articleId, contents, cvnumber, rcvnumber, topId, parentId) {
        ajaxTool.ajaxPost(appUrl("addcommnet"), { articleId: articleId, contents: contents, cvnumber: cvnumber, rcvnumber: rcvnumber, topId: topId, parentId: parentId, articleType: 1 },
            function (result) {
                console.log(result);
                if (result.result == 10000) {
                    if (!!result.data) {
                        var resdata = $.parseJSON(result.data);
                        var id = resdata[0].Id;
                        var title = resdata[0].title;
                        var model = {};
                        appUser.get(getCurrentCV(), function (result) {
                            model.headphoto = result.headphoto;
                            model.name = result.name;
                            model.cvnumber = result.cvnumber;
                            model.contents = EmojiJM(contents);
                            model.addtime = DateTime(new Date(), 4);
                            model.topid = id;
                            model.id = id;
                            model.title = title;
                            var tt = ' <li class="table-view-cell"  >'
                        + '<img src="{0}" data-route-to="" />'
         + '<span class="liuyan-name" data-name="{1}" data-topid="{2}" data-commid="{3}"  data-cvnumber="{4}"  data-route-to={8}"">{5}</span>'
         + '<span class="liuyan-time">{6}</span>'
         + '<span class="liuyan-text">{7}</span>'
         + '</li>';
                            $("#pagecomment").prepend(tt.format1(model.headphoto, model.name, model.topid, model.id, model.cvnumber, model.title, model.addtime, model.contents, "pageSpace?cv=" + model.cvnumber));
                        });

                        var comm = $("#exper-header-com").attr("data-com");
                        comm++;
                        $("#exper-header-com i").html("(" + comm + ")");
                        $("#exper-header-com").attr("data-com", comm);
                        $(".exper-com-tag i").html(comm);
                        //清空
                        $("#exper-message textarea").val("").trigger("change");
                        see.rcvnumber = 0;
                        see.parentid = 0;
                        $("#exper-message textarea").attr("placeholder", "评论");
                        see.iscroller.refresh();
                        ExperLocData();
                        $("#exper-with, #exper-share").removeClass("out");
                        $("#exper-message").addClass("footerBar-overlay");
                        $(".modal-over-white").removeClass("modal-overlay-visible");
                        $("#exper-message textarea").blur();
                    }
                }
            });
    }
    //浏览
    see.addBrowse = function () {
        ajaxTool.ajaxPost(appUrl("addbrowse"), { articleId: articleId, articleType: 1, cvnumber: getCurrentCV() },
          function (result) {
          });
    }

    ///同行插入
    see.addArtilceExper = function () {
        ajaxTool.ajaxPost(appUrl("addinsertexper"), { articleId: articleId, cvnumber: getCurrentCV() },
           function (result) {
               console.log(result);
               if (result.result == 10000) {
                   if (!!result.data) {
                       var resdata = $.parseJSON(result.data);
                       $("#tongxing i").html(parseInt($("#tongxing i").text()) + 1);
                       ExperLocData();
                       R.to("pageExperWither?supid="+resdata[0].experid+"&id=" + articleId + "&experid=0" , "", "");
                   }
               }
           });
    }
    //取消同行
    see.delExper = function () {
        ajaxTool.ajaxPost(appUrl("delexper"), { id: $("#witherid").val(), cvnumber: getCurrentCV() },
          function (result) {
              console.log(result);
              if (result.result == 10000) {
                  app.actionsClose();
                  $(".modal-over-back").removeClass("modal-overlay-visible");
                  ExperLocData();
              }
          });
    }

    ////发送
    see.on("#exper-message-send", "touchend", function () {
        var comm_content = $("#comm_content").val();
        if (comm_content.length > 0) {
            see.addComment(articleId, EmojiBM(comm_content.replace(/\n/g, '<br/>')), see.cvnumber, see.rcvnumber, see.topid, see.parentid);
        }
    })

    //一级评论
    see.on("#exper-header-com, #exper-com", "touchend", function () {
        $(".experBtn").addClass("out");
        $("#exper-message").removeClass("footerBar-overlay");
        $(".modal-over-white").addClass("modal-overlay-visible");
        setTimeout(function () {
            $("#exper-message textarea").focus();
        }, 400);
        see.cvnumber = getCurrentCV();

    })


    //取消评论
    see.on(".modal-over-white", "touchend", function () {
        $(".experBtn").removeClass("out");
        $("#exper-message").addClass("footerBar-overlay");
        $(".modal-over-white").removeClass("modal-overlay-visible");
        $("#exper-message textarea").blur();
        see.name = '';
        $("#exper-message textarea").attr("placeholder", "评论");
    })

    //切换
    see.on("#exper-preview-tag span, #exper-preview-fixed-tag span", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("preview-list-tag-active")) return false;
        var index = $(self).index();
        $("#exper-preview-tag span").eq(index).addClass("preview-list-tag-active").siblings().removeClass("preview-list-tag-active");
        $("#exper-preview-fixed-tag span").eq(index).addClass("preview-list-tag-active").siblings().removeClass("preview-list-tag-active");
        $("#exper-preview .preview-item").eq(index).addClass("preview-active").siblings().removeClass("preview-active");
        see.iscroller.refresh();//加载完对应的数据后记得重新初始化滚动条
        see.pageindex = 1;
        $("#pagecomment,#pagelike,#pagewith").html("");
        if ($(self).hasClass("exper-com-tag")) {
            see.com = true;
            see.like = false;
            see.with = false;
            see.getCommentPraise(articleId, 1, 0, see.pageindex);
        } else if ($(self).hasClass("exper-like-tag")) {
            see.com = false;
            see.like = true;
            see.with = false;
            see.getCommentPraise(articleId, 2, 0, see.pageindex);
        } else if ($(self).hasClass("exper-with-tag")) {
            see.com = false;
            see.like = false;
            see.with = true;
            see.getCommentPraise(articleId, 3, 0, see.pageindex);
        }
    })

    //喜欢
    see.on("#exper-header-like, #exper-like", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("liked")) {
            $("#exper-header-like, #exper-like").removeClass("liked");
            var like = $("#exper-header-like").attr("data-like");
            like--;
            $("#exper-header-like i").html("(" + like + ")");
            $("#exper-header-like").attr("data-like", like)
            $(".exper-like-tag i").html(like)
            //执行去掉喜欢函数
            see.PraiseAdd(articleId, getCurrentCV(), 1);
        } else {
            $("#exper-header-like, #exper-like").addClass("liked");
            var like = $("#exper-header-like").attr("data-like");
            like++;
            $("#exper-header-like i").html("(" + like + ")");
            $("#exper-header-like").attr("data-like", like);
            $(".exper-like-tag i").html(like);
            //执行添加喜欢函数
            see.PraiseAdd(articleId, getCurrentCV(), 0);
        }
    })

    //回复XXX
    see.on(".preview-item-content .liuyan-name", "longtouch", function (e, ev) {
        var self = ev.self;
        if (typeof ($(self).attr("data-name")) == "undefined") return false;
        var name = $(self).attr("data-name");
        see.name = name;
        see.topid = $(self).attr("data-topid");
        see.parentid = $(self).attr("data-commid");
        see.cvnumber = $(self).attr("data-cvnumber");
        see.rcvnumber = getCurrentCV();

        $("#exper-message textarea").attr("placeholder", "回复" + name);
        $(".experBtn").addClass("out");
        $("#exper-message").removeClass("footerBar-overlay");
        $(".modal-over-white").addClass("modal-overlay-visible");
        setTimeout(function () {
            $("#exper-message textarea").focus();
        }, 400)
    })
    $.views.helpers({
        DateTime: function (id, type) {
            return DateTime(id, type);
        },
        jmContent: function (contents) {
            return EmojiJM(contents);
        }
    });
    //同行

    see.on("#exper-with", "touchend", function (e, ev) {
        $(ev.self).addClass("out");
        $(".modal-over-back").addClass("modal-overlay-visible");

        var witherid = $("#witherid").val();
        var button1 = [];
        if (witherid > 0) {
            button1.push({
                html: '编辑参与经历',
                onClick: function () {
                    R.to("pageExperWither?supid=" + witherid + "&id=" + articleId + "&experid=0");
                    $(".modal-over-back").removeClass("modal-overlay-visible");
                    $("#exper-with").removeClass("out");
                    app.actionsClose();
                }
            },
			{
			    html: '取消参与经历',
			    onClick: function () {
			        see.delExper();
			        R.to("pageExperSee?id="+articleId);
			        $(".modal-over-back").removeClass("modal-overlay-visible");
			        $("#exper-with").removeClass("out");
			    }
			});
        } else {
            button1.push({
                html: '我参与了此经历',
                onClick: function () {
                    see.addArtilceExper();
                    app.actionsClose();
                    $(".modal-over-back").removeClass("modal-overlay-visible");
                    $("#exper-with").removeClass("out");
                }
            })
        }
        var button2 = [
			{
			    html: '取消',
			    color: 'red',
			    onClick: function () {
			        app.actionsClose();
			        $(".modal-over-back").removeClass("modal-overlay-visible");
			        $("#exper-with").removeClass("out");
			    }
			}
        ];
        var groups = [button1, button2];
        app.actions(groups);
    })
})(jQuery)
