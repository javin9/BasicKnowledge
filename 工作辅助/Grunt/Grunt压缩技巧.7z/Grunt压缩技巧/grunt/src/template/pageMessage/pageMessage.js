(function($){
	var mes = pageMessage;
	mes.iscroller = null;
	mes.loadingMore = false;
	mes.isRefresh = false;
	mes.onPageLoadInit = function(){
		mes.iscroller = app.iscroll("#page-mes");
		
		//下拉刷新和加载更多-------------前端使用
		mes.iscroller.on("scroll",function(){
			if(this.y>=40 && !mes.isRefresh){
				$("#mes-downPull span").html("松开刷新");
				this.minScrollY = 40;	
				$("#mes-downPull").addClass("now");
			}else if(this.y>0&&this.y<40 && !mes.isRefresh){
				$("#mes-downPull span").html("下拉刷新");
				this.minScrollY = 0;	
				$("#mes-downPull").removeClass("now");
			}
		});
		//下拉刷新和加载更多预备调用
		mes.iscroller.on("scrollEnd",function(){
			if(!mes.isRefresh){
				if($("#mes-downPull").hasClass("now")){
					$("#mes-downPull span").addClass("preloader");
					mes.isRefresh = true;
				    //调用刷新函数
					msg.init();
				}else{
					$("#mes-downPull span").removeClass("preloader").html('&nbsp;');
				}
			}
			if(this.y==this.maxScrollY && !mes.loadingMore){
				$("#mes-more span").addClass("preloader");
				mes.loadingMore = true;
				//调用加载更多函数
				
			}
			
		});
		
	}
	//左滑菜单
	mes.on(".mes-view-list .table-view-cell","slide",function(e,ev){
		var that = ev.self;
		$(".item-tool-opened").removeClass("item-tool-opened");	
		$(that).addClass("item-tool-opened");
	},{direc:"left"});
	mes.on(".pageScroll","touchstart",function(e,ev){
		$(".item-tool-opened").removeClass("item-tool-opened");	
	})
	
	//删除
	mes.on(".mes-item-tool .mes-item-delete","touchend",function(e,ev){
	    var li = $(ev.self).parents(".table-view-cell");
	    var cv = $(ev.self).data('cv');
	    msg.data.hasread(cv, msg.params.deleted, function () {
	        li.remove();
	        mes.iscroller.refresh();
	    });
		
	})
	//标记已读
	mes.on(".mes-item-tool .mes-item-readed","touchend",function(e,ev){
	    var li = $(ev.self).parents(".table-view-cell");
	    var $sp = li.find(".new-mes-icon");
	    var cv = $(ev.self).data('cv');
	    msg.data.hasread(cv,msg.params.setread,function () {
	        $sp.remove();
	    });
		
	})

    //范月盘
	mes.onPageLoad = function () {
	    msg.init();
	}
	var msg = {
	    params: {
	        setread:1,
            deleted:2,
	        cvnumber:0
	    },
	    init:function(){
	        this.params.cvnumber = getCurrentCV();
	        this.data.notice();
	    },
	    data: {
	        notice: function (callback) {
	            ajaxTool.ajaxGet(appUrl('/user/getnotice'), { cvnumber: msg.params.cvnumber }, function (result) {
	                if (result.result == 10000) {
	                    msg.bind.list(result.data);
	                } else {
	                    app.alert('消息加载失败！');
	                }
	            });
	        },
            //标记为已读
	        hasread: function (scv,operate,callback) {
	            ajaxTool.ajaxPost(appUrl('/user/updateunread'), { scv: scv, rcv: msg.params.cvnumber, operate:operate }, function (result) {
	                if (result.result == 10000) {
	                    callback();
	                } else {
	                    app.alert('操作失败！');
	                }
	            });
	        }
	    },
	    bind: {
	        list: function (json) {
	            var html = jsRenderBinding({
	                page: 'pageMessage.pageMessage_template_msgList',
	                json: json
	            });
	            $('#pageMessage_msgList').html(html);
	            mes.isRefresh = false;
	            $("#mes-downPull span").html("下拉刷新");
	            $("#mes-downPull").removeClass("now");
	            $("#mes-downPull span").removeClass("preloader");
	            //绑定基础信息
	        }
	    }
	};

	$.views.helpers({
	    transDate: function (date) {
	        return GetDateDiff(date);
	    }
	});
})(jQuery)