﻿(function ($) {
    var space = pageSpace;
    space.iscroller = null;
    space.loadingMore = false;
    space.init = function () {
    }
    space.onPageLoad = function () {
        if (helper.needLoad()) {
            helper.load();
            space.iscroller = app.iscroll("#page-space");
        }
    }

    var helper = {
        params: {
            cvNumber: 0,
            currentCvNumber:getCurrentCV()
        },
        setCvNumber: function () {
            this.params.cvNumber = parseInt(R.getPara('cv', 'cv')) || getCurrentCV();
        },
        needLoad: function () {
            var $space = $('#page-space');
            this.setCvNumber();
            if ($space.length) {
                if (parseInt($space.data('current')) != this.params.cvNumber) {
                    return true;
                } else { return false;}
            }
            return true;
        },
        load: function () {
            $('#page-space').data('current', helper.params.cvNumber);
            //加载数据
            appUser.get(helper.params.cvNumber, function (user) {
                appUserIdentity.get(helper.params.cvNumber, function (data) {
                    helper.bindUser(user,data);
                });
            });
            //检测是否收藏过
            pubFigure.iscollect(helper.params.currentCvNumber, helper.params.cvNumber, function (iscollect) {
                if (iscollect) {
                    $('#space-like').addClass("liked-space");
                    $('#space-biog-like').addClass("liked-space");
                } else {
                    $('#space-like').removeClass("liked-space");
                    $('#space-biog-like').removeClass("liked-space");
                }
                $('#pageSpace_liuyan').attr('data-route-to', 'pageLiuyan?cv=' + helper.params.cvNumber + '&c=' + (iscollect ? 1 : 0));
            });
            //绑定列表信息
        },
        isSelf: function () {
            return this.params.cvNumber==this.params.currentCvNumber
        },
        bindUser: function (user,ids) {

            var html = jsRenderBinding({
                page: 'pageSpaceBio.pageSpace_template_userContact',
                json: user
            });
            $('#pageSpace_userContact').html(html);
            //绑定基础信息
            var baseJson = {
                headphoto: user.headphoto,
                name: user.name,
                titles: []
            };
            if (user.school_friend) {
                baseJson.titles.push({
                    title: (user.company||'') + ' ' + (user.job||'')
                });
            }
            for (var i = 0; i < ids.length; i++) {
                var titles = ids[i].titles;
                for (var j = 0; j < titles.length; j++) {
                    baseJson.titles.push({ title: titles[j].titles });
                }
            }
            var base = jsRenderBinding({
                page: 'pageSpace.pageSpace_template_userInfo',
                json: baseJson
            });
            $('#pageSpace_userInfo').html(base);
           
            //绑定用户基本信息
            //绑定标签
            var isself = this.isSelf();
            var tagJson = {
                isself: isself,
                achieve_tag: user.achieve_tag || '请填写',
                ability_tag: user.ability_tag || '请填写',
                zjname: '暂无传记',
                zjcontents: ''
            };
            var tags = jsRenderBinding({
                page: 'pageSpace.pageSpace_template_userTags',
                json: tagJson
            });
            $('#pageSpace_userTags').html(tags);
            $('#pageSpace_userTags').show();
            $('#pageSpace_zhuanji').attr('data-route-to', 'pageSpaceBiog?cv=' + helper.params.cvNumber);
            //绑定二维码
            var model = {
                cvnumber: user.cvnumber,
                name: user.name,
                title: user.identity_title,
                organization: user.company,
                mobile: user.mobile,
                email: user.email,
            }
            $.ajax({
                url: domain.getQrCode,
                type: "POST",
                data: model,
                success: function (result) {
                    if (result.result == 10000) {
                        document.getElementById('pageSpace_qrCode').src = result.data.src;
                    }
                }
            });

            this.bindList(user.name, user.headphoto);
           
        },
        bindList: function (name,photo) {
            ajaxTool.ajaxGet(appUrl('user/articles'), { cvNumber: helper.params.cvNumber }, function (result) {
                if (result.result == 10000) {
                    var desc = "";
                    if (result.data.summary.length) {
                        $('#pageSpace_zjName').text(EmojiJM(result.data.summary[0].title));
                        desc = dropHtml(result.data.summary[0].contents);
                        $('#pageSpace_zjContents').html(EmojiJM(desc));
                    } else {
                        $('#pageSpace_zjName').text('暂无传记');
                        $('#pageSpace_zjContents').html('该用户很懒，没有留下任何内容...');
                    }
                    if (result.data.count == 0) {
                        $('#pageSpace_listCount').html(name + '还没有添加任何记忆哦');
                    } else {
                        $('#pageSpace_listCount').html(name + '一共发表了' + result.data.count + '篇记忆');
                    }

                    //处理列表数据，绑定
                    var list = result.data.list;
                    var newd = new Array();
                    for (var i in list) {
                        newd.push({ year: i, data: list[i] });
                    }
                   result.data.list = newd.reverse();

                    var html = jsRenderBinding({
                        page: 'pageSpace.pageSpace_YearList',
                        json:result.data
                    });
                    $('#pageSpace_memoryList').html(html);
                    space.iscroller.refresh();//刷新滚动条
                    //初始化微信分享
                    wxShare.init({
                        page: 'pageSpace',
                        title: name + '的个人空间',
                        desc:  desc,
                        imgUrl: photo
                    });
                }
            });
        }
    };


    //收藏
    space.on("#space-like", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("liked-space")) {
            pubFigure.collect(helper.params.currentCvNumber, helper.params.cvNumber, false, function () {
                $(self).removeClass("liked-space");
                $('#space-biog-like').removeClass("liked-space");
            });
           
            //取消收藏函数
        } else {
            //收藏函数
            pubFigure.collect(helper.params.currentCvNumber, helper.params.cvNumber, true, function () {
                $(self).addClass("liked-space");
                $('#space-biog-like').addClass("liked-space");
            });
        }
    })

    //查看联系方式
    space.on("#space-phone", "touchend", function (e, ev) {
        $(".modal-over-back").addClass("modal-overlay-visible");
        $(".space-contact").addClass("in");
    })

    //关闭联系方式
    space.on(".space-contact-btn", "touchend", function (e, ev) {
        $(".modal-over-back").removeClass("modal-overlay-visible");
        $(".space-contact").removeClass("in");
    })
    
    //分享
    space.on('.share-space', 'touchend', function (e, ev) {
        app.share_weixin();
    });


    //时间格式转换
    $.views.helpers({
        DateTimeHtml: function (statrTstirng, sType, endTstring, endType, type) {
            var tim = TimeTrans.toText2(statrTstirng, sType, endTstring, endType);
            switch (type) {
                case 1:
                    return tim.listUp;
                    break;
                case 2:
                    return tim.listDown;
                    break;
                case 3:
                    return tim.more;
                    break;
            }
        },
        isNowY: function (year) {
            var myDate = new Date();
            var newy = myDate.getFullYear().toString();
            if (year == newy) {
                return false;
            } else {
                return true;
            }
        },
        hasImg: function (cont) {
            return !!cont;
        },
        contentsHtml: function (cont) {
            var result = "";
            var yourString = cont;
            var str = yourString.split(",");
            for (var i = 0; i < str.length; i++) {
                result += "<img src='" + str[i] + "' />";
            }
            return result;
        }
    });

})(jQuery)
