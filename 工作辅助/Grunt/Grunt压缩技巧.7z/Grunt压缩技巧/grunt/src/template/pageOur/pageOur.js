(function ($) {
    var our = pageOur, o;
    our.MyDB = {
        dbName: "pageOur",
        tabNames: [{ name: 'pageOur', id: 'cvnumber' }],
        db: null,
        url: 'experlist/mylist',
        cvnumber: getCurrentCV(),
        load: function (data, callback) {
            var url = appUrl(this.url);
            IndexDB.LoadData(this.dbName, url, data, false, callback, our.MyDB.db);
        },
        update: function (name, data, success) {
            delete SS('#ourlistid').dataset.SLIDEMenu;
            appUser.get(our.MyDB.cvnumber, function (result) {
                $("#our_userinfo").html($("#pageOur_template_userInfo").render(result));
            }, function (msg) {
                log(msg);
            });
            if (our.MyDB.db != null) {
                IndexDB.update(name, data, this.cvnumber, success, 0, this.db);
            } else {
                IndexDB.openDB(our.MyDB.dbName, our.MyDB.tabNames, function () {
                    our.MyDB.db = IndexDB._pageDB.db;
                    IndexDB.update(name, data, our.MyDB.cvnumber, success, 0, our.MyDB.db);
                }, 1);
            }
        }
    }
    our.iscroller = null;
    our.loadingMore = false;
    our.isRefresh = false;
    our.swiper = null;
    our.key = 'experischange_our'
    our.loadNew = true;
    our.init = function () {
        our.iscroller = app.iscroll("#our-space");
        //下拉刷新和加载更多-------------前端使用
        our.iscroller.on("scroll", function () {
            if (this.y >= 40 && !our.isRefresh) {
                $("#our-downPull span").html("松开刷新");
                this.minScrollY = 40;
                $("#our-downPull").addClass("now");
            } else if (this.y > 0 && this.y < 40 && !our.isRefresh) {
                $("#our-downPull span").html("下拉刷新");
                this.minScrollY = 0;
                $("#our-downPull").removeClass("now");
            }
        });
        //下拉刷新和加载更多预备调用
        our.iscroller.on("scrollEnd", function () {
            if (!our.isRefresh) {
                if ($("#our-downPull").hasClass("now")) {
                    $("#our-downPull span").addClass("preloader");
                    our.isRefresh = true;
                    //调用刷新函数
                    our.LoadM(0, our.MyDB.cvnumber);
                } else {
                    $("#our-downPull span").removeClass("preloader").html('&nbsp;');
                }
            }

            if (this.y == this.maxScrollY && !our.loadingMore) {
                $("#our-more span").addClass("preloader");
                our.loadingMore = true;
                //调用加载更多函数
                var $that = $("#ourlistid .exper-content-list-li:last");
                var startid = $that.attr("data-id"), cv = $that.attr("data-cv");
                if (startid) {
                    our.LoadM(startid, cv);
                } else {
                    our.loadingMore = false;
                    $("#our-more span").removeClass("preloader").html("&nbsp;");
                    $("#our-more").removeClass("now");
                }
                //console.log("我的页面加载更多");
            }
        });

        o = {
            //自己发的
            0: [
                 {
                     title: '删除',
                     css: 'del',
                     fn: function (selEle, slideObj, eo) {
                         var id = $(S(selEle).t).attr("data-id");
                         //删除经历
                         ajaxTool.ajaxPost(appUrl("delarticle"), { id: id, type: 1 }, function (result) {
                             if (result.result == 10000) {
                                 //做标记 表示数据有变化
                                 localStorage.setItem(our.key, "have");
                                 var tParent;
                                 if (S(selEle).parent().parent().child().t.length === 1) {
                                     tParent = S(selEle).parent().parent().t;
                                     if (S(tParent).preEle().t.className == 'exper-item-year') S(tParent).preEle().removeEle();
                                     S(tParent).removeEle();
                                 } else {
                                     S(selEle).parent().removeEle();
                                 }
                             }
                         });

                     } //参数： selectorEle, SLIDEMenu对象，eo对象（注意是菜单点击的EO对象，不是slide的)
                 }
                 , {
                     title: '设置隐私',
                     fn: function (selEle) {
                         var id = $(S(selEle).t).attr("data-id"), privacy = $(S(selEle).t).attr("data-privacy");
                         //进入设置
                         R.to("pageExperSet?articleId=" + id + "&privacy=" + privacy);
                     }
                 }
            ],
            //同行的
            1: [
              //取消同行
               {
                   title: '取消同行',
                   css: 'del',
                   fn: function (selEle, slideObj, eo) {
                       //取消同行
                       var id = $(S(selEle).t).attr("data-id");
                       ajaxTool.ajaxPost(appUrl("experlist/cancel"), { id: id, cvnumber: our.MyDB.cvnumber }, function (result) {
                           if (result.result == 10000) {
                               //做标记 表示数据有变化
                               localStorage.setItem(our.key, "have");
                               var tParent;
                               if (S(selEle).parent().parent().child().t.length === 1) {
                                   tParent = S(selEle).parent().parent().t;
                                   if (S(tParent).preEle().t.className == 'exper-item-year') S(tParent).preEle().removeEle();
                                   S(tParent).removeEle();
                               } else {
                                   S(selEle).parent().removeEle();
                               }
                           }
                       });

                   } //参数： selectorEle, SLIDEMenu对象，eo对象（注意是菜单点击的EO对象，不是slide的)
               }
            ]

        };
        //新消息
        our.getNews(our.MyDB.cvnumber);

        appUser.get(our.MyDB.cvnumber, function (result) {
            $("#our_userinfo").html($("#pageOur_template_userInfo").render(result));
            our.getdata(our.bindNew, our.MyDB.cvnumber);
        }, function (msg) {
            log(msg);
        });

    }

    our.getNews = function (cvnumber) {
        var url = appUrl("experlist/getnews");
        $.ajax({
            url: url,
            data: { cvnumber: cvnumber, pid: 0 },
            type: "Get",
            dataType: 'json',
            success: function (result) {
                var json = result
                if (json.result == 10000) {
                    if (json.data.sum[0].unread > 0) {
                        $("#our_msgid").addClass("new-message")
                    } else {
                        $("#our_msgid").removeClass("new-message");
                    }
                }
            },
            error: function (er) {
                console.log("服务器获取失败");
            }
        });
    }
    //经历 添加 编辑 修改 评论 同行 只要是操作数据了 操作完成后 调用 
    //localStorage.setItem("experischange_our", "have");
    our.onPageLoad = function () {
        var isc = localStorage.getItem(our.key);
        if (isc == "have") {//有变化
            our.MyDB.cvnumber = getCurrentCV();
            appUser.get(our.MyDB.cvnumber, function (result) {
                $("#our_userinfo").html($("#pageOur_template_userInfo").render(result));
                our.LoadM(0, our.MyDB.cvnumber);
            }, function (msg) {
                log(msg);
            });
        }
    }
    //保证第一次进来是最新数据
    our.onPageLoadInit = function () {
        if (our.loadNew) {
            our.LoadM(0, our.MyDB.cvnumber);
            our.loadNew = false;
        }
    }
    //加载列表数据 先从本地取 没有 去加载 再从本地取出
    our.getdata = function (success, cvnumber) {
        if (our.MyDB.db != null) {
            //获取数据 
            IndexDB.Select(our.MyDB.dbName, cvnumber, function (result) {
                if (typeof result != 'object') {
                    result = eval("(" + result + ")");
                }
                if (result != undefined) {
                    success(result);
                } else {
                    our.MyDB.load({ startid: 0, cvnumber: cvnumber, pid: 0 }, function () {
                        our.loadNew = false;
                        our.getdata(success, cvnumber);
                    })
                }
            }, our.MyDB.db);
        } else {
            IndexDB.openDB(our.MyDB.dbName, our.MyDB.tabNames, function () {
                our.MyDB.db = IndexDB._pageDB.db;
                //获取数据 
                IndexDB.Select(our.MyDB.dbName, cvnumber, function (result) {
                    if (typeof result != 'object') {
                        result = eval("(" + result + ")");
                    }
                    if (result != undefined) {
                        success(result);
                    } else {
                        our.MyDB.load({ startid: 0, cvnumber: cvnumber, pid: 0 }, function () {
                            our.loadNew = false;
                            our.getdata(success, cvnumber);
                        })
                    }
                });
            }, 1);
        }
    }

    //绑定数据
    our.bindNew = function (data) {
        if (typeof data != 'object') {
            data = eval("(" + data + ")");
        }
        if (data.sum.length > 0) {
            $("#our_sumall").show();
            //您一共拥有了33篇记忆<br>参与贡献学院XX记忆，贡献率X
            $("#our_sumall").html("您一共累积了" + data.sum[0].mysum + "篇记忆<br>为本组织贡献" + data.sum[0].mysum1 + "篇(" + Percentage(data.sum[0].mysum1, data.sum[0].sum) + ")");
        }
        var list = data.list;
        var newd = new Array();
        for (var i in list) {
            newd.push({ year: i, data: list[i] });
        }
        data.list = newd.reverse();
        if (data.list.length > 0 && data.list[0].data.length > 0) {
            $("#ourlistid").html($("#our_ListTemplate").render(data));
        } else {
            $("#ourlistid").html('<div class="noData">这个人很懒,什么都没有</div>');
        }
        our.iscroller.refresh();
        our.isRefresh = false;
        $("#our-downPull span").html("下拉刷新");
        $("#our-downPull").removeClass("now");
        var fnMenu = new SLIDEMenu(SS('#ourlistid'), '.exper-item-content', o);
        //绑定完之后 要改变 状态 （数据是否有变化的状态）
        localStorage.setItem(our.key, "no");
    };

    //跟新列表/获取更多
    our.LoadM = function (startid, cvnumber) {
        var url = appUrl(our.MyDB.url);
        $.ajax({
            url: url,
            data: { startid: startid, cvnumber: cvnumber, pid: 0 },
            type: "Get",
            dataType: 'json',
            success: function (result) {
                //console.log(result);
                var json = result
                if (json.result == 10000) {
                    if (startid == 0) {
                        our.MyDB.update(our.MyDB.dbName, json.data, our.bindNew);
                    } else {
                        var list = json.data.list;
                        var newd = new Array();
                        for (var i in list) {
                            //判断页面是否已经有 改年的ul 
                            if ($("#" + i).length) {//有 则加到这个ul 下面 
                                $("#" + i).append($("#our_liTemplate").render(list[i]));
                                our.iscroller.refresh();
                                our.loadingMore = false;
                                $("#our-more span").removeClass("preloader").html("&nbsp;");
                                $("#our-more").removeClass("now");
                            } else {//没有 正常加
                                newd.push({ year: i, data: list[i] });
                                json.data.list = newd.reverse();
                                if (json.data.list.length > 0 && json.data.list[0].data.length > 0) {
                                    $("#ourlistid").append($("#our_ListTemplate").render(json.data));
                                    our.iscroller.refresh();
                                    our.loadingMore = false;
                                    $("#our-more span").removeClass("preloader").html("&nbsp;");
                                    $("#our-more").removeClass("now");
                                } else {
                                    //our.loadingMore = false;
                                    $("#our-more span").removeClass("preloader").html("&nbsp;");
                                    $("#our-more").removeClass("now");
                                }
                            }

                        }
                    }
                }
            },
            error: function (er) {
                console.log("服务器获取失败");
            }
        });
    };

    //时间格式转换
    $.views.helpers({
        DateTimeHtml: function (statrTstirng, sType, endTstring, endType, type) {
            var tim = TimeTrans.toText2(statrTstirng, sType, endTstring, endType);
            switch (type) {
                case 1:
                    return tim.listUp;
                    break;
                case 2:
                    return tim.listDown;
                    break;
                case 3:
                    return tim.more;
                    break;
            }
        },
        isNowY: function (year, index) {
            var myDate = new Date();
            var newy = myDate.getFullYear().toString();
            if (year == newy && index == 0) { //是今年 并且 是第一个
                return false;
            } else {
                return true;
            }
        },
        contentsHtml: function (cont) {
            var result = "";
            var yourString = cont;
            var str = yourString.split(",");
            for (var i = 0; i < str.length; i++) {
                result += "<img src='" + str[i] + "' />";
            }
            return result;
        }, replaceE: function (str) {
            if (str != null) {
                return EmojiJM(str);
            } else {
                return '';
            }
        }
    });

})(jQuery)
