﻿; (function ($) {
    pageCarCom.onPageLoad = function () {
        pageCardHelper.setinfo('pageCar_company', 'company');
    }
    //保存
    pageCarCom.on('.pull-right', 'touchend', function (e, ev) {
        pageCardHelper.updateinfo('pageCar_company', 'company');
    });
})(jQuery);