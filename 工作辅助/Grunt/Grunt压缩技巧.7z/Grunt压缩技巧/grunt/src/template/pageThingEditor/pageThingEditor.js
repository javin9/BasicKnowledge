(function($){
	var thing = pageThingEditor;
	thing.iscroller = null;
	thing.initPhoto = null;
	var editor, articleId = 0, privacy=1;
	thing.onPageLoadInit = function(){
		
	}
	thing.onPageLoad = function () {
	    articleId = thing.getParam('Id');
	    if (articleId > 0) {
	        thing.GetArticleById(articleId);
	    } else {
	        editor = new EditMobileClass(document.getElementById("editStage"));
	        editor.init();
	    }
	}
    //详情页
	thing.GetArticleById = function (articleId) {
	    ajaxTool.ajaxPost(appUrl("getarticlebyid"), { articleId: articleId, type: 0, articleType: 3 }, function (result) {
	        console.log(result);
	        if (result.result == 10000) {
	            if (!!result.data) {
	                //var resdata = $.parseJSON(result.data);
	                var data = result.data;
	                editor = new EditMobileClass(document.getElementById("editStage"), EmojiJM(data.contents));
	                editor.init();
	                $("#title").text(EmojiJM(data.title));
	                privacy = data.privacy>0?data.privacy:1;
	                $(".preview-info").html('<span data-route-to="">{0}</span>始发于{1}&nbsp;&nbsp;{2}人回应&nbsp;&nbsp;{3}人查看'.format1(data.name, DateTime(data.add_time, 1), data.browse_show, data.partake));
	                if (!!data.contents) $(".create-name").html('<div class="create-name-mox" data-route-to=""><span>{0}</span><span>{1}</span></div>'.format1(data.name, DateTime(data.add_time, 1)));

	               
	            }
	        }
	    });
	}
    //保存
	thing.on(".experSave", "touchend", function (e, ev) {
	    var self = ev.self;
	    var title = EmojiBM($("#title").val());
	    var content = EmojiBM(editor.getHtml());
	    var cvNumber = getCurrentCV();
	    if (!$('.experSave').hasClass("not")) {
	        if (!!title) {
	            if (editor.isAjaxEnd()) {
	                $('.experSave').addClass("not");
	                var imgArr = bioInsertImgArr($("#editStage img"));
	                var videoArr = bioInsertVideoArr($("#editStage video"));
	                ajaxTool.ajaxPost(appUrl("savething"), { id: articleId, title: title, contents: content, cvNumber: cvNumber,imgStr: '{"key":[' + imgArr.toString() + ']}', videoStr: '{"key":[' + videoArr.toString() + ']}'  }, function (result) {
	                    $('.experSave').removeClass("not");
	                    if (result.result == 10000) {
	                        if (!!result.data) {
	                            var resdata = $.parseJSON(result.data);
	                            ThingLocData();
	                            R.to("pageThingSet?articleId=" + resdata[0].Id + "&privacy=" + privacy, "", "");
	                        }
	                    }
	                });
	            } else {
	                app.alert("您的照片/视频还未上传完成，请稍等..");
	            }
	        } else {
	            app.alert("请填写标题");
	        }
	    }
	});
    //返回
	thing.on("#pageThing", "touchend", function () {
	    if (!editor.isAjaxEnd()) {
	        app.alert("您的照片/视频还未上传完成，请稍等..,确定返回吗？", [{
	            title: "确定", fn: function () {
	                app.hideAlert();
	                R.to(-1);
	                editor.abortAjax();//中断ajax请求
	            }
	        },
           { title: "取消", fn: function () { app.hideAlert(); } }], "返回提示");
	    } else {
	        R.to(-1);
	    }
	});
    /*Des:获取所有图片，生成数组, $this_content:当前对象 */
	function bioInsertImgArr($this_content) {
	    var spanArr = $this_content,
             imgArr = [],
             template = '{"RowId":"{0}","A_Id":"R_Id","BigURL":"{1}","Url":"{2}","ArticleType":"3","Type":"1","Width":"{3}","Height":"{4}","PlatFormId":"PFID"}';
	    $.each(spanArr, function (i, item) {
	        var $this = $(item);
	        imgArr.push(template.format([(i + 1), $this.attr("data-src").replace(domain.imgUrl, ""), $this.attr("src").replace(domain.imgUrl, ""), $this.attr("data-width"), $this.attr("data-height")]));
	    });
	    return imgArr;
	}
    //视频
	function bioInsertVideoArr($this_content) {
	    var spanArr = $this_content,
             imgArr = [],
             template = '{"RowId":"{0}","A_Id":"R_Id","BigURL":"{1}","Url":"{2}","ArticleType":"3","Type":"2","Width":"{3}","Height":"{4}","PlatFormId":"PFID"}';
	    $.each(spanArr, function (i, item) {
	        var $this = $(item);
	        var url = $this.attr("data-url").replace(domain.imgUrl, "");
	        imgArr.push(template.format([(i + 1), url, url, 0, 0]));
	    });
	    return imgArr;
	}
	//预览
	thing.on("#preview","touchend",function(e,ev){
		var self = ev.self;
		if($(self).hasClass("header-tag-active"))return false;
		$(self).addClass("header-tag-active").siblings("span").removeClass("header-tag-active");
		$(".exper-content").hide();
		$(".preview-editor").show();
		if (!thing.iscroller) thing.iscroller = app.iscroll(".preview-editor");
		$(".preview-title").html($("#title").val());
		var gethtml = editor.getHtml();
		$(".preview-editor .app-editor-content").html(gethtml);
		appUser.get(getCurrentCV(), function (result) {
		    var name = result.name;
		    var time = new Date();
		    $(".preview-info").html('<span data-route-to="">{0}</span>始发于{1}&nbsp;&nbsp;{2}人回应 &nbsp;&nbsp;{3}人查看'.format1(name, DateTime(time, 1), 0, 0));
		    if (!!gethtml) { $(".create-name").html('<div class="create-name-mox" data-route-to=""><span>{0}</span><span>{1}</span></div>'.format1(name, DateTime(time, 1))); }

		});
		thing.initPhoto = app.initPhoto(".preview-editor");
		
		setTimeout(function () {
		    thing.iscroller.refresh();
		}, 500);
	})
	
	//编辑
	thing.on("#editor","touchend",function(e,ev){
		var self = ev.self;
		if($(self).hasClass("header-tag-active"))return false;
		$(self).addClass("header-tag-active").siblings("span").removeClass("header-tag-active");
		$(".exper-content").show();
		$(".preview-editor").hide();
		thing.iscroller = null;
	})
	
})(jQuery);
