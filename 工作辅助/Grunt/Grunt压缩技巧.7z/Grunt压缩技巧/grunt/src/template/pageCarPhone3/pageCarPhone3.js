﻿; (function ($) {
    var cvnumber;
    pageCarPhone3.onPageLoad = function () {
        $('#pageCarPhone3_code').val('');
        cvnumber = getCurrentCV();
        resendClick({
            btnId: '#pageCarPhone3_resend',//验证码外层元素的id
            callback: function () {
                SendCode({//发送验证码
                    mobile: pageCarPhone2.phone
                });
            }
        });
    }
    //点击倒计时
    pageCarPhone3.on("#pageCarPhone3_resend", "touchend", function (e, ev) {
        console.log('点击倒计时');

        resendClick({
            btnId: '#pageCarPhone3_resend',//验证码外层元素的id
            callback: function () {
                SendCode({//发送验证码
                    mobile: pageCarPhone2.phone
                });
            }
        });
    });
    //下一步
    pageCarPhone3.on('.pull-right', 'touchend', function (e, ev) {
        //验证验证码
        var code = $.trim($('#pageCarPhone3_code').val());
        CheckCode({//默认参数对象
            mobile: pageCarPhone2.phone,
            code: code,
            callback: function (result) {
                if (result.result == 10000) {
                    //验证码成功，修改手机
                    //pageCardHelper.updateinfo('pageCar_address', 'mobile');
                    appUser.update(cvnumber, 'mobile', pageCarPhone2.phone, function () {
                        var html = $('#pageCar_list_mobile').html();
                        html = html.replace(pageCarPhone2.oldPhone, pageCarPhone2.phone);
                        $('#pageCar_list_mobile').html(html);
                        app.alert('新手机号修改成功');
                        R.to('pageCarList', 10);
                    });

                } else {
                    app.alert(result.msg);
                }
            }
        });
    });
})(jQuery);