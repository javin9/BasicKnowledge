(function ($) {
    var thing = pageThing;
    thing.MyDB = {
        dbName: "pageThing",
        tabNames: [{ name: "pageThing_1", id: "cvnumber" }, { name: "pageThing_2", id: "cvnumber" }, { name: "pageThing_3", id: "cvnumber" }],
        db: null,
        url: "thing/list",
        cvnumber: getCurrentCV(),
        load: function (data, type, callback) {
            var url = appUrl(this.url);
            IndexDB.LoadData(this.dbName + "_" + type, url, data, false, callback, thing.MyDB.db);
        },
        update: function (name, type, data, success) {
            if (thing.MyDB.db != null) {
                IndexDB.update(name, data, this.cvnumber, success, type, thing.MyDB.db);
            } else {
                IndexDB.openDB(thing.MyDB.dbName + "_" + type, thing.MyDB.tabNames, function () {
                    thing.MyDB.db = IndexDB._pageDB.db;
                    //获取数据 
                    IndexDB.update(name, data, thing.MyDB.cvnumber, success, type, thing.MyDB.db);
                }, 2);

            }
        }

    }

    thing.iscroller = null;
    thing.loadingMore = false;
    thing.isRefresh = false;
    thing.swiper = null;
    thing.loadNew = true;
    thing.key = "thingchange_";

    thing.onPageLoad = function () {
        $(".modal-over-back").removeClass("modal-overlay-visible");
        $("#popover-thing").removeClass("active");

        var type = $("#thing_kt .header-tag-active").attr("data-type");
        var key = thing.key + type;
        var isc = localStorage.getItem(key);
        if (isc == "have") {//有变化
            thing.LoadM(0, parseInt(type));
        }

    }

    thing.init = function () {
        //初始化搜索框
        app.searchInit("#thing-search");
        thing.iscroller = app.iscroll("#page-thing");
        //下拉刷新和加载更多-------------前端使用
        thing.iscroller.on("scroll", function () {
            if (this.y >= 40 && !thing.isRefresh) {
                $("#thing-downPull span").html("松开刷新");
                this.minScrollY = 40;
                $("#thing-downPull").addClass("now");
            } else if (this.y > 0 && this.y < 40 && !thing.isRefresh) {
                $("#thing-downPull span").html("下拉刷新");
                this.minScrollY = 0;
                $("#thing-downPull").removeClass("now");
            }
        });
        //下拉刷新和加载更多预备调用
        thing.iscroller.on("scrollEnd", function () {
            if (!thing.isRefresh) {
                if ($("#thing-downPull").hasClass("now")) {
                    $("#thing-downPull span").addClass("preloader");
                    thing.isRefresh = true;
                    //调用刷新函数
                    var type = $("#thing_kt .header-tag-active").attr("data-type");
                    thing.LoadM(0, parseInt(type));
                } else {
                    $("#thing-downPull span").removeClass("preloader").html('&nbsp;');
                }
            }
            if (this.y == this.maxScrollY && !thing.loadingMore) {
                $("#thing-more span").addClass("preloader");
                thing.loadingMore = true;
                //调用加载更多函数
                var type = $("#thing_kt .header-tag-active").attr("data-type"), startId = $("#thingList .thing-item:last-child").attr("data-Id");
                if (startId) {
                    thing.LoadM(startId, parseInt(type));
                } else {
                    thing.loadingMore = false;
                    $("#thing-more span").removeClass("preloader").html("&nbsp;");
                    $("#thing-more").removeClass("now");
                }
                //console.log("人物页面加载更多");
            }

        });
        var type = 1;
        appUser.get(thing.MyDB.cvnumber, function (result) {
            thing.getdata(thing.bindNew, thing.MyDB.cvnumber, type);
        }, function (msg) {
            log(msg);
        });

    }

    thing.onPageLoadInit = function () {
        if (thing.loadNew) {
            thing.LoadM(0, 1);
            thing.loadNew = false;
            //localStorage.setItem("thingchange_1", "have");
            localStorage.setItem("thingchange_2", "have");
            localStorage.setItem("thingchange_3", "have");
        }
    }

    //加载列表数据 先从本地取 没有 去加载 再从本地取出
    thing.getdata = function (success, cvnumber, type) {
        if (thing.MyDB.db != null) {
            //获取数据 
            IndexDB.Select(thing.MyDB.dbName + "_" + type, cvnumber, function (result) {
                if (typeof result != "object") {
                    result = eval("(" + result + ")");
                }
                if (result != undefined) {
                    success(result, type);
                } else {
                    thing.MyDB.load({ startId: 0, type: type, cvnumber: cvnumber, pid: 0 }, type, function () {
                        thing.loadNew = false;
                        thing.getdata(success, cvnumber, type);
                    })
                }
            }, thing.MyDB.db);
        } else {
            IndexDB.openDB(thing.MyDB.dbName + "_" + type, thing.MyDB.tabNames, function () {
                thing.MyDB.db = IndexDB._pageDB.db;
                //获取数据 
                IndexDB.Select(thing.MyDB.dbName + "_" + type, cvnumber, function (result) {
                    if (typeof result != "object") {
                        result = eval("(" + result + ")");
                    }
                    if (result != undefined) {
                        success(result, type);
                    } else {
                        thing.MyDB.load({ startId: 0, cvnumber: cvnumber, pid: 0, type: type }, type, function () {
                            thing.loadNew = false;
                            thing.getdata(success, cvnumber, type);
                        })
                    }
                }, thing.MyDB.db);
            }, 2);
        }
    }

    //加载完后view
    thing.bindNew = function (data, type) {
        if (typeof data != 'object') {
            data = eval("(" + data + ")");
        }
        if (type == 1) {
            if (data.view.length > 0) {
                $("#thing-banner").show();
                $("#thing-banner .swiper-wrapper").html($("#thing_viewTemplate").render(data));
                //轮播图thing_banner
                if (thing.swiper) { thing.swiper.destroy() }
                thing.swiper = new Swiper('#thing-banner', {
                    lazyLoading: true,
                    pagination: '#thing-banner .swiper-pagination',
                    paginationClickable: true,
                    autoplay: 2500,
                    loop: true
                });
            }
        } else {
            $("#thing-banner").hide();
        }
        if (data.list.length > 0) {
            $("#thingList").html($("#thingListTemplate").render(data));
        } else {
            if (type == 1) {
                $("#thingList").html('<div class="noData">还没有事哦。赶快发布第一个吧...</div>');
            }
            if (type == 2) {//我发布的
                $("#thingList").html('<div class="noData">你还没有发布过呢。赶快发布第一个吧...</div>');
            }
            if (type == 3) {//我收藏的
                $("#thingList").html('<div class="noData">你还没有收藏过呢。赶快去收藏吧...</div>');
            }
        }
        thing.iscroller.refresh();
        thing.isRefresh = false;
        $("#thing-downPull span").html("下拉刷新");
        $("#thing-downPull").removeClass("now");
        localStorage.setItem(thing.key + type, "no");
    }
    //刷新
    thing.LoadM = function (startId, type) {
        var url = appUrl(thing.MyDB.url);
        $.ajax({
            url: url,
            data: { startId: startId, type: type, cvnumber: thing.MyDB.cvnumber, pid: 0 },
            type: "Get",
            dataType: 'json',
            success: function (result) {
                var json = result
                if (json.result == 10000) {
                    if (startId == 0) {//下拉刷新 //更新裤 重新绑
                        thing.MyDB.update(thing.MyDB.dbName + "_" + type, type, json.data, thing.bindNew);
                    } else {//滚动到底部 加载更多
                        if (json.data.list.length > 0) {
                            //console.log("加载更多");
                            $("#thingList").append($("#thingListTemplate").render(json.data));
                            thing.iscroller.refresh();
                            thing.loadingMore = false;
                            $("#thing-more span").removeClass("preloader").html("&nbsp;");
                            $("#thing-more").removeClass("now");
                        } else {
                            thing.loadingMore = false;
                            $("#thing-more span").removeClass("preloader").html("&nbsp;");
                            $("#thing-more").removeClass("now");
                        }
                    }
                }
            },
            error: function (er) {
                console.log("服务器获取失败");
            }
        });
    }
    //发布事情
    thing.on("#create-thing", "touchend", function () {
        $(".modal-over-back").addClass("modal-overlay-visible");
        $("#popover-thing").addClass("active");
    })
    //取消发布
    thing.on(".modal-overlay-visible", "touchend", function () {
        $(".modal-over-back").removeClass("modal-overlay-visible");
        $("#popover-thing").removeClass("active");
    })
    //点击选项卡
    thing.on("#thing_kt span", "touchend", function (e) {
        //清理所有的 转圈
        thing.isRefresh = false;
        $("#thing-downPull span").html("下拉刷新");
        $("#thing-downPull").removeClass("now");

        thing.loadingMore = false;
        $("#thing-more span").removeClass("preloader").html("&nbsp;");
        $("#thing-more").removeClass("now");

        $(e.target).addClass("header-tag-active").siblings().removeClass("header-tag-active");
        var type = $(e.target).attr("data-type");
        var isc = localStorage.getItem(thing.key + type);
        if (isc == "have") {
            $("#thingList").html('<div class="noData">努力加载中,请稍后。。</div>');
            thing.LoadM(0, parseInt(type));
        } else {
            thing.getdata(thing.bindNew, thing.MyDB.cvnumber, type);
        }

    })
    //时间格式转换
    $.views.helpers({
        DateTime: function (id, type) {
            return DateTime(id, type);
        }, chtml: function (str) {
            if (str != null) {
                var newstr = str.replace(/<[^>]+>/g, "");
                return EmojiJM(newstr);
            } else {
                return '';
            }
        }, DateTimeHtmlThing: function (statrTstirng, sType, endTstring, endType, type) {
            var tim = TimeTrans.toText(statrTstirng, sType, endTstring, endType);
            switch (type) {
                case 1:
                    return tim.main;
                    break;
                case 2:
                    return tim.more;
                    break;
            }
        }, replaceT: function (str) {
            if (str != null) {
                return EmojiJM(str);
            } else {
                return '';
            }
        }, dateSEFuncThing: function (stype, stime, etype, etime) {
            return dateSEFunc(stype, stime, etype, etime);
        }

    });
})(jQuery);