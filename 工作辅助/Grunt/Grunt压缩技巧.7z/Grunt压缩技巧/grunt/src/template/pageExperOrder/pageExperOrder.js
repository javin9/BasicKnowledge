(function ($) {
    var order = pageExperOrder;
    order.MyDB = {
        dbName: "pageExper",
        tabNames: [{ name: 'pageExper', id: 'cvnumber' }],
        db: null,
        url: '/experlist/list',
        cvnumber: getCurrentCV(),
        load: function (data, callback) {
            var url = appUrl(this.url);
            IndexDB.LoadData(this.dbName, url, data, false, callback, order.MyDB.db);
        },
        update: function (name, data, success) {
            if (order.MyDB.db != null) {
                IndexDB.update(name, data, this.cvnumber, success, 0, this.db);
            } else {
                IndexDB.openDB(order.MyDB.dbName, order.MyDB.tabNames, function () {
                    order.MyDB.db = IndexDB._pageDB.db;
                    IndexDB.update(name, data, order.MyDB.cvnumber, success, 0, order.MyDB.db);
                }, 2);
            }
        },
        edited: function (name, success, upfun) {
            if (order.MyDB.db != null) {
                IndexDB.editData(name, this.cvnumber, null, upfun, success, this.db);
            } else {
                IndexDB.openDB(order.MyDB.dbName, order.MyDB.tabNames, function () {
                    order.MyDB.db = IndexDB._pageDB.db;
                    IndexDB.editData(name, order.MyDB.cvnumber, null, upfun, success, order.MyDB.db);
                }, 2);
            }
        }
    }
    order.iscroller = null;
    order.loadingMore = false;
    order.isRefresh = false;
    order.pageIndex = 1;
    order.issearch = false;
    order.PageCount = 0;
    order.key = "experischange_jy";
    order.loadNew = true;
    order.init = function () {
        //初始化搜索框
        app.searchInit("#order-search");
        order.iscroller = app.iscroll("#page-order");

        //下拉刷新和加载更多-------------前端使用
        order.iscroller.on("scroll", function () {
            if (this.y >= 40 && !order.isRefresh && !order.issearch) {
                $("#order-downPull span").html("松开刷新");
                this.minScrollY = 40;
                $("#order-downPull").addClass("now");
            } else if (this.y > 0 && this.y < 40 && !order.isRefresh && !order.issearch) {
                $("#order-downPull span").html("下拉刷新");
                this.minScrollY = 0;
                $("#order-downPull").removeClass("now");
            }
        });
        //下拉刷新和加载更多预备调用
        order.iscroller.on("scrollEnd", function () {
            if (!order.isRefresh) {
                if ($("#order-downPull").hasClass("now")) {
                    $("#order-downPull span").addClass("preloader");
                    order.isRefresh = true;
                    //调用刷新函数
                    order.LoadM(0, order.MyDB.cvnumber);
                } else {
                    $("#order-downPull span").removeClass("preloader").html('&nbsp;');
                }
            }
            if (this.y == this.maxScrollY && !order.loadingMore) {
                $("#order-more span").addClass("preloader");
                order.loadingMore = true;
                //调用加载更多函数
                if (!order.issearch) {//列表加载更多
                    var $that = $("#orderlistid ul:last-child");
                    var startid = $that.attr("data-id"), cv = $that.attr("data-cv");
                    if (startid) {
                        order.LoadM(startid, cv);
                    } else {
                        order.loadingMore = false;
                        $("#order-more span").removeClass("preloader").html("&nbsp;");
                        $("#order-more").removeClass("now");
                    }
                    // console.log("记忆页面加载更多");
                } else {//搜索加载更多
                    if (order.pageIndex < order.PageCount) {
                        order.pageIndex++;
                        var $that = $("#order-search"), searchval = $("#order_search").val();
                        if ($that.hasClass("search-active") && !$that.find(".icon-clear").hasClass("hidden")) {
                            order.search(searchval, order.pageIndex, order.searchM);
                        } else {
                            $("#order-more span").removeClass("preloader").html("&nbsp;");
                            $("#order-more").removeClass("now");
                        }
                    } else {
                        $("#orderlistid").append('<div class="noData">没有更多数据了...</div>');
                        //order.loadingMore = false;
                        $("#order-more span").removeClass("preloader").html("&nbsp;");
                        $("#order-more").removeClass("now");
                    }

                }
            }

        });


        //搜索
        $("#order-search-form").submit(function () {
            order.pageIndex = 1;
            order.PageCount = 0;
            order.issearch = true;
            var $that = $("#order-search"), searchval = $("#order_search").val();
            if ($that.hasClass("search-active") && !$that.find(".icon-clear").hasClass("hidden")) {
                //console.log(searchval);
                order.search(searchval, order.pageIndex, order.searchM);
            }
            return false;
        });

        appUser.get(order.MyDB.cvnumber, function (result) {
            order.getdata(order.bindNew, order.MyDB.cvnumber);
        }, function (msg) {
            log(msg);
        });
    }



    //修改一个本地数据库的值
    order.onPageLoad = function () {
        var isc = localStorage.getItem(order.key);
        if (isc == "have") {//有变化
            order.LoadM(0, order.MyDB.cvnumber);
        }

        order.MyDB.edited(order.MyDB.dbName, function () {
        }, function (data) {
            if (typeof data != 'object') {
                data = eval("(" + data + ")");
            }
            data.ishaveNew = 0;
            return {
                ajaxParam: "",//ajax参数 list  
                dbParam: data//保存到本地数据库的内容
            };
        })
    }

    //第一次进入时候 去刷新
    order.onPageLoadInit = function () {
        if (order.loadNew) {
            order.LoadM(0, order.MyDB.cvnumber);
            order.loadNew = false;
        }
    }

    //加载列表数据 先从本地取 没有 去加载 再从本地取出
    order.getdata = function (success, cvnumber) {
        if (order.MyDB.db != null) {
            //获取数据 
            IndexDB.Select(order.MyDB.dbName, cvnumber, function (result) {
                if (typeof result != 'object') {
                    result = eval("(" + result + ")");
                }
                if (result != undefined) {
                    success(result);
                } else {
                    order.MyDB.load({ startid: 0, cvnumber: cvnumber, pid: 0, newTime: 0 }, function () {
                        order.loadNew = false;
                        order.getdata(success, cvnumber);
                    })
                }
            }, order.MyDB.db);
        } else {
            IndexDB.openDB(order.MyDB.dbName, order.MyDB.tabNames, function () {
                order.MyDB.db = IndexDB._pageDB.db;
                //获取数据 
                IndexDB.Select(order.MyDB.dbName, cvnumber, function (result) {
                    if (typeof result != 'object') {
                        result = eval("(" + result + ")");
                    }
                    if (result != undefined) {
                        success(result);
                    } else {
                        order.MyDB.load({ startid: 0, cvnumber: cvnumber, pid: 0, newTime: 0 }, function () {
                            order.loadNew = false;
                            order.getdata(success, cvnumber);
                        })
                    }
                });
            }, 2);
        }
    }

    //跟新列表/获取更多
    order.LoadM = function (startid, cvnumber, type) {
        var url = appUrl(order.MyDB.url);
        $.ajax({
            url: url,
            data: { startid: startid, cvnumber: cvnumber, pid: 0, newTime: 0 },
            type: "Get",
            dataType: 'json',
            success: function (result) {
                var json = result
                if (json.result == 10000) {
                    if (startid == 0) {
                        order.MyDB.update(order.MyDB.dbName, json.data, order.bindNew);
                    } else {
                        var list = json.data.shike;
                        if (list.length > 0) {
                            $("#orderlistid").append($("#order_ListTemplate").render(json.data));
                            order.iscroller.refresh();
                            order.loadingMore = false;
                            $("#order-more span").removeClass("preloader").html("&nbsp;");
                            $("#order-more").removeClass("now");
                        } else {
                            order.loadingMore = false;
                            $("#order-more span").removeClass("preloader").html("&nbsp;");
                            $("#order-more").removeClass("now");
                        }
                        //直接绑定
                    }
                }
            },
            error: function (er) {
                console.log("服务器获取失败");
            }
        });
    };

    //绑定数据
    order.bindNew = function (data) {
        if (typeof data != 'object') {
            data = eval("(" + data + ")");
        }
        var list = data.shike;
        if (list.length > 0) {
            $("#orderlistid").html($("#order_ListTemplate").render(data));
        } else {
            $("#orderlistid").html('<div class="noData">还没有人发布过经历。赶紧成为第一个吧...</div>');
        }
        order.iscroller.refresh();
        order.isRefresh = false;
        $("#order-downPull span").html("下拉刷新");
        $("#order-downPull").removeClass("now");
        localStorage.setItem(order.key, "no");
    };

    //搜索
    order.search = function (searchval, pageIndex, success) {
        var url = appUrl('/experlist/searchshike');
        $.ajax({
            url: url,
            data: { uasTitle: searchval, cvnumber: order.MyDB.cvnumber, pid: 0, pageIndex: pageIndex },
            type: "Get",
            dataType: 'json',
            success: function (result) {
                var json = result
                if (json.result == 10000) {
                    var data = json.data;
                    if (order.pageIndex == 1) {
                        success(data, true);
                    } else {
                        success(data, false);
                    }
                }
            },
            error: function (er) {
                console.log("服务器获取失败");
            }
        });
    }

    //搜索回调
    order.searchM = function (data, type) {
        if (type) {
            if (data.shike.length > 0) {
                $("#orderlistid").html($("#order_ListTemplate").render(data));
            } else {
                $("#orderlistid").html('<div class="noData">没有找到你想要的东西呢....</div>');
            }
        } else {
            if (data.shike.length > 0) {
                $("#orderlistid").append($("#order_ListTemplate").render(data));
                order.loadingMore = false;
                $("#order-more span").removeClass("preloader").html("&nbsp;");
                $("#order-more").removeClass("now");
            } else {
                order.loadingMore = false;
                $("#order-more span").removeClass("preloader").html("&nbsp;");
                $("#order-more").removeClass("now");
            }
        }
        pubFigure.removeFigureSearchOptions();
        order.iscroller.refresh();
        order.pageIndex = data.pageTb[0].PageIndex;
        order.PageCount = data.pageTb[0].PageCount;
    }

    //搜索取消
    order.on("#order-search .search-cancel", "touchend", function () {
        //加载数据
        order.getdata(order.bindNew, order.MyDB.cvnumber);
        order.issearch = false;
        order.loadingMore = false;
    })

    //时间格式转换
    $.views.helpers({
        DateTimeoder: function (id, type) {
            return DateTime(id, type);
        },
        contentsHtml: function (cont) {
            var result = "";
            var yourString = cont;
            var str = yourString.split(",");
            for (var i = 0; i < str.length; i++) {
                result += "<img src='" + str[i] + "' />";
            }
            return result;
        }, replaceE: function (str) {
            if (str != null) {
                return EmojiJM(str);
            } else {
                return '';
            }
        }, dateSEFuncOrder: function (stype, stime, etype, etime) {
            return dateSEFunc(stype, stime, etype, etime);
        }, DateTimeHtmlOrder: function (statrTstirng, sType, endTstring, endType, type) {
            var tim = TimeTrans.toText(statrTstirng, sType, endTstring, endType);
            switch (type) {
                case 1:
                    return tim.main;
                    break;
                case 2:
                    return tim.more;
                    break;
            }
        }
    });
})(jQuery)