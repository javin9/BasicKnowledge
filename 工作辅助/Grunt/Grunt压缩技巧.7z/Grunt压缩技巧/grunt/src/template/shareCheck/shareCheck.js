(function ($) {

    shareCheck.init = function () {
        var share = R.getPara(R.getUrl().cPage, 'key');
        //根据key获取分享的页面
        wxShare.getShareInfo(share, function (t) {
            t.url = RemoveUrlParam('key', t.url);
            R.share.data = { maxDeep: t.deep, nowDeep: 0, formUrl: t.url };
            if (!!t && !!t.url) { R.to(t.url); } else { R.to('login') }
        }, function (e) {
            R.to('login');
        });
    }


})(jQuery);
