﻿(function () {
    var cvnumber = getCurrentCV();
    var N = pageCarNeng;
    N.onPageLoad = function () {
        log(R);
        appUser.gettag(cvnumber, 1, function (tags) {
            tag.bind(tags);
            tag.getTag();
        });
    }
    //删除技能标签
    N.on(".car-tag .tag-item", "touchend", function (e, ev) {
        var that = ev.self;
        if ($(that).hasClass("current")) {
            $(that).removeClass("current");
        } else {
            $(that).addClass("current");
        }
    });
    //添加标签
    N.on(".tag-item-add", "touchend", function (e, ev) {
        app.prompt("请输入标签名", [
			{
			    title: "取消",
			    fn: function () { tag.close(); }
			},
			{
			    title: "确定",
			    fn: function (val) {
			        var v = val;
			        if ($.trim(v) != '') {
			            tag.addTag(v);
			        }
			    }
			}
        ]);
    });
    N.on('.pull-right', 'touchend', function (e, ev) {
        var val = tag.getTag();
        var txt = val ? val.replace(/\|/ig, ',') : '待填写';
        appUser.update(cvnumber, "ability_tag",val, function () {
            $('#pageCar_list_abilitytag').text(txt);
            $('#pageSpace_abilitytag').text(txt);
            R.to(R.prePage.name || 'pageCarList', 10);
        });
    });

    var tag = {
        bind: function (json) {
            json = $.grep(json, function (item, i) {
                return item.name.length > 0;
            });
            var template = '<span class="tag-item" data-value={{:id}}>{{:name}}</span>';
            var t = $.templates(template);
            var html = t.render(json);
            html += '<span class="tag-item-add">添加</span>';
            $('#pageCarNeng_tags').html(html);
        },
        addTag: function (v) {
            v = $.trim(v);
            if (v.length > 10) {
                app.alert('标签字数不能大于十个字哦');
                return;
            }
            if (this.exist(v)) {
                app.alert('标签不能重复哦');
                return;
            }
            var t = '<span class="tag-item">' + v + '</span>';
            $('#pageCarNeng_tags').prepend(t);
            this.close();
        },
        //获取最终修改后的标签
        getTag: function () {
            var t = '';
            $('#pageCarNeng_tags span').each(function (i, item) {
                if (!$(this).hasClass('current') && !$(this).hasClass('tag-item-add')) {
                    t += $(this).text() + '|';
                }
            });
            if (t) {
                t = t.substr(0, t.length - 1);
            }
            return t;
        },
        //判断标签是否存在
        exist: function (tag) {
            var e = false;
            $('#pageCarNeng_tags span').each(function (i, item) {
                if (!$(this).hasClass('tag-item-add')) {
                    if ($(this).text() === tag) { e = true; }
                }
            });
            return e;
        },
        close: function () {
            app.hideModal();
        }
    };
})(jQuery);
