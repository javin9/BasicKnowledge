﻿(function ($) {
    var cvnumber = getCurrentCV();
    var p1 = pageCarPhone1;
    p1.onPageLoad = function () {
        pageCardHelper.getphone(function (result) {
            if (!result.ishidemobile) {
                $('#pageCarPhone_switch').removeClass("off").addClass("on");
                $('#pageCarPhone_switch').find("input").val("on");
            }
            $('#pageCarPhone_phone').text(result.mobile);
        });
    }
    p1.onPageLoadInit = function () {
        p1.on("#phone-next", "touchend", function (e, ev) {
            app.pwd("请输入登录密码", [
                {
                    title: "取消",
                    fn: function (val) { app.hideModal(); }
                },
                {
                    title: "确定",
                    fn: function () {
                        var pwd = $('.modal-input').val();
                        if (pwd.length) {
                            ajaxTool.ajaxPost(appUrl('account/checkpwd'), { cvnumber: cvnumber, pwd: pwd }, function (result) {
                                if (result.result == 10000) {
                                    app.hideModal();
                                    R.to('pageCarPhone2');
                                } else {
                                    app.alert('密码不正确，请重试');
                                    $('.modal-input').val('');
                                }
                            });
                        } else {
                            app.alert('请输入密码');
                        }
                    }
                }
            ]);
        });
    }
    p1.on(".switch", "touchend", function (e, ev) {
        var that = ev.self;
        if ($(that).hasClass("disabled")) return false;
        if ($(that).hasClass("off")) {
            $(that).removeClass("off").addClass("on");
            $(that).find("input").val("on");
            log('打开')
            pageCardHelper.updatehide(false);
        } else {
            $(that).removeClass("on").addClass("off");
            $(that).find("input").val("off");
            pageCardHelper.updatehide(true);
        }
    });
})(jQuery)
