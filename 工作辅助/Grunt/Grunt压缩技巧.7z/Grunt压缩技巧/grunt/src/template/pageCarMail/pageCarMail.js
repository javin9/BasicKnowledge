﻿; (function ($) {
    pageCarMail.onPageLoad = function () {
        pageCardHelper.setinfo('pageCar_email', 'email');
    }
    //保存
    pageCarMail.on('.pull-right', 'touchend', function (e, ev) {
        pageCardHelper.updateinfo('pageCar_email', 'email');
    });
})(jQuery);