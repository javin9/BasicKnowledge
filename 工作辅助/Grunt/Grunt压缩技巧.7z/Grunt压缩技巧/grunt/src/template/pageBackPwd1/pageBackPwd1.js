﻿(function () {
    pageBackPwd1.init = function () {
        var footerData = xzbTool.data.plat()[0];
        if (!isNull(footerData.foot_left_title)) {
            $("#pwd1leftStr").text(footerData.foot_left_title);
        }
        if (!isNull(footerData.foot_right_title)) {
            $("#pwd1rightStr").text(footerData.foot_right_title);
        }
    };

    pageBackPwd1.onPageLoad = function () {
        console.log("pageBackPwd1——进入");
        $("#getpwdmobile").val(pageBackPwd1.getParam().mobile);
    };
    //getcode
    pageBackPwd1.on("#getcode", "touchend", function (e,ev) {
        var that = $(e.target), bd_mobile = $("#getpwdmobile").val().trim();
            //重新更换缓存中的手机号
            //envObj.SaveLocals("mobile_cupid", bd_mobile);
            var isValid = regex_data.IsPhone.test(bd_mobile);
            if (!isValid) {
                app.alert('请输入有效的手机号');
                return false;
            }

            if (isValid) {
                if (!that.hasClass('btn-disabled')) {
                    CheckMobileIsExist({
                        mobile: bd_mobile,
                        callback: checkExistCallback,
                        bsFunc: checkExistbsFunc,
                        id: '#getcode',
                        className: 'btn-disabled',
                        text: '获取验证码'
                    });
                }
            }
    });

    //验证手机号是否存在的beforeSend
    function checkExistbsFunc() {
        $("#getcode").addClass('btn-disabled');
    };
    //验证手机号是否存在的callback
    function checkExistCallback(json) {
        if (json.result == 14017) {
            console.log(json);
            envObj.SaveLocals("getpwd_mobile", json.data.phone||$("#getpwdmobile").val().trim());
            R.to('pageBackPwd2');
        } else if (json.result == 10000) {
            app.alert('手机号未注册');
            $("#getcode").removeClass('btn-disabled');
        } else {
            app.alert(json.msg);
            $("#getcode").removeClass('btn-disabled');
        }
    }
})(jQuery);