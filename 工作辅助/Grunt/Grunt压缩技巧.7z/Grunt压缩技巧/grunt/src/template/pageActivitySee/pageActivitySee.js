﻿(function ($) {
    var see = pageActivitySee;
    see.iscroller = null;
    see.initPhoto = null;
    see.loadingMore = false;
    see.com = true;
    see.like = false;
    see.with = false;
    see.name = '';
    see.cvnumber = 0;
    see.rcvnumber = 0;
    see.topid = 0;
    see.parentid = 0;
    see.pageindex = 1;
    see.pagecount = 1;
    see.contents = "";
    see.isopen = true;
    var articleId = 0;
    see.onPageLoadInit = function () {
        see.iscroller = app.iscroll("#page-activity-see");

      
        app.autoArea("#activity-message");

        see.iscroller.on("scrolling", function () {
            var tag = $("#activity-preview-tag").offset().top,
				navbar = $("#activity-preview-tag").parents(".page").find(".headerBar").eq(0).height();
            if (tag - navbar < 0) {
                $("#activity-preview-fixed-tag").addClass("visible");
            } else {
                $("#activity-preview-fixed-tag").removeClass("visible");
            }
        })
        //加载更多预备调用
        see.iscroller.on("scrollEnd", function () {
            if (this.y == this.maxScrollY && !see.loadingMore && see.com && see.pageindex <= see.pagecount) {
                $("#activity-com-more span").addClass("preloader");
                see.loadingMore = true;
                //调用加载更多评论函数
                see.getCommentPraise(articleId, 1, 0, (see.pageindex + 1));
            } else if (this.y == this.maxScrollY && !see.loadingMore && see.like && see.pageindex <= see.pagecount) {
                $("#activity-like-more span").addClass("preloader");
                see.loadingMore = true;
                //调用加载更多喜欢函数
                see.getCommentPraise(articleId, 2, 0, (see.pageindex + 1));
            } else if (this.y == this.maxScrollY && !see.loadingMore && see.with && see.pageindex <= see.pagecount) {
                $("#activity-with-more span").addClass("preloader");
                see.loadingMore = true;
                //调用加载更多同行函数
                see.getCommentPraise(articleId, 4, 0, (see.pageindex + 1));
            }

        });
    }
    see.onPageLoad = function () {
        if (articleId != see.getParam('id')) {
            $(".page-see-content,#pagecomment,#pagelike,#pageopen").html("");
            articleId = see.getParam('id');
            see.getContents();
            see.addBrowse();
        }
    }
    //编辑
    see.on("#btnedit", "touchend", function () {
        R.to("pageActivityEditor?Id=" + articleId, "", "");
    })
    //删除del
    see.on(".del", "touchend", function () {
        app.alert("确定删除吗？", [{
            title: "确定", fn: function () {
                app.hideAlert();
                see.DelArtilce();
            }
        },
        { title: "取消", fn: function () { app.hideAlert(); } }], "删除提示");
    })
    //内容模板
    var contenthtml = '<div class="create-name"><div class="create-name-mox" data-route-to="{3}"><span>{0}</span><span>{1}</span> </div></div><div class="app-editor-content">{2}</div>';
    //头部模板
    var titlehtml = '{0}<div class="preview-header"><span class="preview-time">{1}</span><span class="preview-title">{2}</span> </div><div class="activity-tag"><span ><i>地点：</i>{7}</span></div><em class="preview-info"><span data-route-to="">{3}</span>始发于{4}&nbsp;&nbsp;{5}人报名&nbsp;&nbsp;{6}人查看</em>';
    //头部背景
    var backhtml = '<div class="preview-background" id="preview-back" ><img src="{0}" class=""  data-src="{0}"  data-size="{1}" /></div>';
    //加载主体内容和补充内容
    see.getContents = function () {
        ajaxTool.ajaxPost(appUrl("getarticlebyid"), { articleId: articleId, type: 0, cvnumber: getCurrentCV(), articleType: 2 }, function (result) {
            console.log(result);
            if (result.result == 10000) {
                if (!!result.data) {
                    var data = result.data, html;
                    if (data.id > 0) {
                        var firstTime = data.start_time, firstForamt = data.start_type, lastTime = data.end_time, lastForamt = data.end_type;
                        var time = TimeTrans.toText(firstTime, firstForamt, lastTime, lastForamt);
                        html = titlehtml.format1(!!data.back_img ? backhtml.format1(domain.imgUrl + data.back_img, (data.width + "*" + data.height)) : "", time.main + '<em>' + time.more + '</em>', EmojiJM(data.title), data.name, DateTime(data.add_time, 1), data.partake, data.browse_show == 0 ? 1 : data.browse_show, data.address);
                  
                        $(".page-see-content").append(html);
                        if (data.address.length == 0) { $(".activity-tag").hide(); }
                        $("#witherid").val(data.witherid);
                        if (data.witherid > 0) {
                            $("#page_open span").text("取消报名");
                            $("#baoming").text("取消报名").attr("data-sign","1");
                        }
                        var fb_cvnumber = data.cv_number;
                        if (fb_cvnumber == getCurrentCV()) {//自己进来
                            $("#page_share").show();
                            $("#page_open").hide();
                            $("#page_zj").show();
                            $("#page_br").hide();
                            $("#baoming").show();
                            $("#bieren").hide();
                        } else {
                            $("#page_share").hide();
                            $("#page_open").show();
                            $("#page_zj").hide();
                            $("#page_br").show();
                            $("#baoming").hide();
                            $("#bieren").show();
                        }
                        see.isopen = data.is_open;
                        var commentHtml = "";
                        commentHtml += contenthtml.format1(data.name, DateTime(data.add_time, 1), EmojiJM(data.contents), "");
                       
                        $(".preview-info").after(commentHtml);
                        if (data.contents.length > 0) {

                        } else {
                            $(".create-name").hide();
                        }
                        var drophtmlContent=dropHtml(data.contents);
                        wxShare.init({
                            page: 'pageActivitySee',
                            title: EmojiJM(data.title),
                            desc: "发布者:" + data.name + "\n" + (drophtmlContent.length > 20 ? drophtmlContent.substring(0, 20) : drophtmlContent),
                            imgUrl: !!data.back_img ? data.back_img : data.head_photo
                        });

                        setTimeout(function () {
                            see.iscroller.refresh();
                        }, 500);
                        see.initPhoto = app.initPhoto("#page-activity-see .page-see-content");
                        see.getCommentPraise(articleId, 1, 1, 1);
                        if(!!data.back_img) ArticleBackPic(SS("#preview-back"));

                    } else {
                        app.alert("你访问的活动不存在！");

                    }
                }
            }
        });
    };
    //获取 下的数字  评论  点赞  报名
    see.getCommentPraise = function (id, type, numtype, pageindex) {
        ajaxTool.ajaxPost(appUrl("getcomment"), { id: id, type: type, numtype: numtype, cvnumber: getCurrentCV(), pageIndex: pageindex },
            function (result) {
                console.log(result);
                if (result.result = 10000) {
                    if (numtype == 1) {
                        if (!!result.data.numlist) {
                            var praise = result.data.numlist.praise;
                            var comm = result.data.numlist.comm;
                            var activty = result.data.numlist.activty;
                            $("#activity-header-like i").html("(" + praise + ")");
                            $("#activity-header-like").attr("data-like", praise);
                            $("#activity-header-com i").html("(" + comm + ")");
                            $("#activity-header-com").attr("data-com", comm);
                            $("#activity-preview-fixed-tag,#activity-preview-tag").html($("#template_tag").render(result.data.numlist));
                            $('#activity-preview-tag span').eq(type - 1).addClass("preview-list-tag-active").siblings().removeClass("preview-list-tag-active");
                            $("#activity-preview-fixed-tag span").eq(type - 1).addClass("preview-list-tag-active").siblings().removeClass("preview-list-tag-active");
                            $("#bieren i").html(activty);
                        }
                    }
                    if (!!result.data.pageing) {
                        see.pageindex = result.data.pageing.pageindex;
                        see.pagecount = result.data.pageing.pagecount;
                        if (see.pageindex == 1) {
                            $("#pagecomment,#pagelike,#pageopen").html("");
                        }
                    }
                    if (type == 1) { //评论模板
                        if (result.data.comm != null && result.data.comm.length > 0) {
                            $("#pagecomment").append($("#template_coment").render(result.data));
                        }
                    } else if (type == 2) {
                        if (result.data.praisecom != null && result.data.praisecom.length > 0) {
                            $("#pagelike").append($("#template_like").render(result.data));
                            if (result.data.opernum > 0) { //自己已赞
                                $("#activity-like").addClass("liked").attr("data-id", result.data.id);
                            } else {
                                $("#activity-like").removeClass("liked").attr("data-id", 0);
                            }
                        }
                    } else if (type == 4) {
                        if (result.data.praisecom != null && result.data.praisecom.length > 0) {
                            $("#pageopen").append($("#template_like").render(result.data));
                        }
                    }
                    if (!see.isopen) {
                        $(".activity-with-tag").hide();
                    }
                   
                    see.loadingMore = false;
                    if (type == 1) {
                        $("#activity-com-more span").removeClass("preloader").html("&nbsp;");
                        $("#activity-com-more").removeClass("now");
                    } else if (type == 2) {
                        $("#activity-like-more span").removeClass("preloader").html("&nbsp;");
                        $("#activity-like-more").removeClass("now");
                    } else if (type == 3) {
                        $("#activity-with-more span").removeClass("preloader").html("&nbsp;");
                        $("#activity-with-more").removeClass("now");
                    }
                    //刷新滚动条
                    see.iscroller.refresh();
                }
            });
    }
    //删除
    see.DelArtilce = function () {
        ajaxTool.ajaxPost(appUrl("delarticle"), { id: articleId, type:2 }, function (result) {
            console.log(result);
            if (result.result == 10000) {
                ThingLocData();
                app.alert("删除成功！");
                R.to(-1);
            }
        });
    }
    //喜欢点赞
    see.PraiseAdd = function (articleId, cvnumber, flag) {
        ajaxTool.ajaxPost(appUrl("addpraise"), { articleId: articleId, cvnumber: cvnumber, flag: flag, articleType: 2 }, function (result) {
            console.log(result);
            if (result.result == 10000) {
                if (!!result.data) {
                    var resdata = $.parseJSON(result.data);
                    var praisehtml = ' <li class="table-view-cell" data-id="{3}">'
                     + '<img src="{0}" />'
                     + '<span class="liuyan-name" data-route-to="{4}">{1}</span>'
                     + '<span class="liuyan-text">{2}</span>'
                     + '</li>';
                    if (flag == 0) {
                        appUser.get(getCurrentCV(), function (result) {
                            $("#pagelike").prepend(praisehtml.format1(result.headphoto, result.name, !!result.identity_title?result.identity_title:"", resdata[0].id, "pageSpace?cv=" + result.cvnumber));
                        });
                    } else {
                        $("#pagelike li[data-id=" + resdata[0].id + "]").remove();
                    }
                    ThingLocData();
                }
            }
        });
    }
    //add评论
    see.addComment = function (articleId, contents, cvnumber, rcvnumber, topId, parentId) {
        ajaxTool.ajaxPost(appUrl("addcommnet"), { articleId: articleId, contents: contents, cvnumber: cvnumber, rcvnumber: rcvnumber, topId: topId, parentId: parentId, articleType: 2 },
            function (result) {
                console.log(result);
                if (result.result == 10000) {
                    if (!!result.data) {
                        var resdata = $.parseJSON(result.data);
                        var id = resdata[0].Id;
                        var title = resdata[0].title;
                        var model = {};
                        appUser.get(getCurrentCV(), function (result) {
                            model.headphoto = result.headphoto;
                            model.name = result.name;
                            model.cvnumber = result.cvnumber;
                            model.contents = EmojiJM(contents);
                            model.addtime = DateTime(new Date(), 4);
                            model.topid = id;
                            model.id = id;
                            model.title = title;
                            var tt = ' <li class="table-view-cell"  >'
                        + '<img src="{0}" data-route-to="" />'
         + '<span class="liuyan-name" data-name="{1}" data-topid="{2}" data-commid="{3}"  data-cvnumber="{4}"  data-route-to="{8}">{5}</span>'
         + '<span class="liuyan-time">{6}</span>'
         + '<span class="liuyan-text">{7}</span>'
         + '</li>';
                            $("#pagecomment").prepend(tt.format1(model.headphoto, model.name, model.topid, model.id, model.cvnumber, model.title, model.addtime, model.contents, "pageSpace?cv="+model.cvnumber));
                        });

                        var comm = $("#exper-header-com").attr("data-com");
                        comm++;
                        $("#exper-header-com i").html("(" + comm + ")");
                        $("#exper-header-com").attr("data-com", comm);
                        $(".exper-com-tag i").html(comm);

                        //清空
                        $("#activity-message textarea").val("").trigger("change");
                        see.rcvnumber = 0;
                        see.parentid = 0;
                        $("#activity-message textarea").attr("placeholder", "评论");
                        see.iscroller.refresh();
                        ThingLocData();

                        $("#page_open, #page_share").removeClass("out");
                        $("#activity-message").addClass("footerBar-overlay");
                        $(".modal-over-white").removeClass("modal-overlay-visible");
                        $("#activity-message textarea").blur();
                    }
                }
            });
    }
    //浏览
    see.addBrowse = function () {
        ajaxTool.ajaxPost(appUrl("addbrowse"), { articleId: articleId, articleType: 2, cvnumber: getCurrentCV() },
          function (result) {
          });
    }
    //报名或取消报名
    see.addOpen = function (type) {
        ajaxTool.ajaxPost(appUrl("addsign"), { articleId: articleId, cvnumber: getCurrentCV(), type: type },
         function (result) {
             if (result.result == 10000) {
                 console.log(result);
                 if (!!result.data) {
                     var resdata = $.parseJSON(result.data);
                     if (type == 0) {
                         var praisehtml = ' <li class="table-view-cell" data-id="{3}">'
                       + '<img src="{0}" />'
                       + '<span class="liuyan-name" data-route-to="{4}">{1}</span>'
                       + '<span class="liuyan-text">{2}</span>'
                       + '</li>';
                         appUser.get(getCurrentCV(), function (result) {
                             $("#pageopen").prepend(praisehtml.format1(result.headphoto, result.name, !!result.identity_title ? result.identity_title : "", resdata[0].id, "pageSpace?cv=" + result.cvnumber));
                         });
                         $("#witherid").val(resdata[0].id);
                         var opennum = $("#activity-preview-tag .activity-with-tag i").text();
                         $('.activity-with-tag i,#bieren i').text(parseInt(opennum) + 1);

                         $("#page_open span").text("取消报名");
                         $("#baoming").text("取消报名").attr("data-sign","1");
                         app.alert("报名成功");
                     } else {
                         $("#pageopen li[data-id=" + resdata[0].id + "]").remove();
                         var opennum = parseInt($("#activity-preview-tag .activity-with-tag i").text());
                         $('.activity-with-tag i,#bieren i').text(parseInt(opennum) - 1);
                         $("#witherid").val("");
                         $("#page_open span").text("报名");
                         $("#baoming").text("我要报名").removeAttr("data-sign");
                     }
                     ThingLocData();
                 }
             }
         });
    }
    //发布人自己报名取消报名
    see.on("#baoming", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).attr("data-sign") == "1") {
            see.addOpen(1);
        } else {
            see.addOpen(0);
        }
    });

    see.on("#page_open", "touchend", function (e, ev) {
        var self = ev.self;
        var witherid = $("#witherid").val();
     
      // return false;
        if (witherid>0) { //取消
            see.addOpen(1);
        } else {
            see.addOpen(0);
        }
    });


    //清空
    see.on("#activity-message-send", "touchend", function () {
        var comm_content = $("#comm_content").val();
        if (comm_content.length > 0) {
            see.addComment(articleId, EmojiBM(comm_content.replace(/\n/g, '<br/>')), see.cvnumber, see.rcvnumber, see.topid, see.parentid);

        }
    })

    //评论
    see.on("#activity-header-com, #activity-com", "touchend", function () {
        $(".activityBtn").addClass("out");
        $("#activity-message").removeClass("footerBar-overlay");
        $(".modal-over-white").addClass("modal-overlay-visible");
        setTimeout(function () {
            $("#activity-message textarea").focus();
        }, 400)
        see.cvnumber = getCurrentCV();
    })

    //取消评论
    see.on(".modal-overlay-visible", "touchend", function () {
        $(".activityBtn").removeClass("out");
        $("#activity-message").addClass("footerBar-overlay");
        $(".modal-over-white").removeClass("modal-overlay-visible");
        $("#activity-message textarea").blur();
        see.name = '';
        $("#activity-message textarea").attr("placeholder", "评论");
    })

    //切换
    see.on("#activity-preview-tag span, #activity-preview-fixed-tag span", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("preview-list-tag-active")) return false;
        var index = $(self).index();
        $("#activity-preview-tag span").eq(index).addClass("preview-list-tag-active").siblings().removeClass("preview-list-tag-active");
        $("#activity-preview-fixed-tag span").eq(index).addClass("preview-list-tag-active").siblings().removeClass("preview-list-tag-active");
        $("#activity-preview .preview-item").eq(index).addClass("preview-active").siblings().removeClass("preview-active");
        see.iscroller.refresh();//加载完对应的数据后记得重新初始化滚动条
        see.pageindex = 1;
        $("#pagecomment,#pagelike,#pageopen").html("");
        if ($(self).hasClass("activity-com-tag")) {
            see.com = true;
            see.like = false;
            see.with = false;
            see.getCommentPraise(articleId, 1, 0, see.pageindex);
        } else if ($(self).hasClass("activity-like-tag")) {
            see.com = false;
            see.like = true;
            see.with = false;
            see.getCommentPraise(articleId, 2, 0, see.pageindex);
        } else if ($(self).hasClass("activity-with-tag")) {
            see.com = false;
            see.like = false;
            see.with = true;
            see.getCommentPraise(articleId, 4, 0, see.pageindex);
        }
    })

    //喜欢
    see.on("#activity-header-like, #activity-like", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("liked")) {
            $("#activity-header-like, #activity-like").removeClass("liked");
            var like = $("#activity-header-like").attr("data-like");
            like--;
            $("#activity-header-like i").html("(" + like + ")");
            $("#activity-header-like").attr("data-like", like)
            $(".activity-like-tag i").html(like)
            //执行去掉喜欢函数
            see.PraiseAdd(articleId, getCurrentCV(), 1);
        } else {
            $("#activity-header-like, #activity-like").addClass("liked");
            var like = $("#activity-header-like").attr("data-like");
            like++;
            $("#activity-header-like i").html("(" + like + ")");
            $("#activity-header-like").attr("data-like", like)
            $(".activity-like-tag i").html(like)
            //执行添加喜欢函数
            see.PraiseAdd(articleId, getCurrentCV(), 0);
        }
    })

    //回复XXX
    see.on(".preview-item-content .liuyan-name", "longtouch", function (e, ev) {
        var self = ev.self;
        if (typeof ($(self).attr("data-name")) == "undefined") return false;
        var name = $(self).attr("data-name");
        see.name = name;
        see.topid = $(self).attr("data-topid");
        see.parentid = $(self).attr("data-commid");
        see.cvnumber = $(self).attr("data-cvnumber");
        see.rcvnumber = getCurrentCV();
        $("#activity-message textarea").attr("placeholder", "回复" + name);
        $(".activityBtn").addClass("out");
        $("#activity-message").removeClass("footerBar-overlay");
        $(".modal-over-white").addClass("modal-overlay-visible");
        setTimeout(function () {
            $("#activity-message textarea").focus();
        }, 400)
    })
    $.views.helpers({
        DateTime: function (id, type) {
            return DateTime(id, type);
        },
        jmContent: function (contents) {
            return EmojiJM(contents);
        }
    });
})(jQuery)
