﻿(function ($) {
    var biogList = pageBiogList;
    var memoryId = biogList.getParam('memoryId');
    var privacy=biogList.getParam("privacy");
    biogList.onPageLoadInit = function () {
        app.iscroll("#page-activitySet");
        biogList.pageBiogList();
    }

    //传记列表
    biogList.pageBiogList = function () {
        ajaxTool.ajaxPost(appUrl("getbioglist"), { cvnumber: getCurrentCV() }, function (result) {
            console.log(result);
            if (result.result == 10000) {
                if (result.data.length>0) {
                    var htmltemp = '<li class="table-view-cell " data-id="{2}" ><span> {0}<i>{1}</i> </span></li>';
                    var html = "";
                    for (var i = 0; i < result.data.length; i++) {
                        html += htmltemp.format1(EmojiJM(result.data[i].title), EmojiJM(result.data[i].Contents), result.data[i].id);
                    }
                    $("#biogList").html(html);
                } else {
                    //没有传记
                    $("#xx").html("您还没有创建传记哦，快去“我的—传记”里添加吧！");
                }
            }
        });
    }
    //保存
    biogList.on("#btn_ok", "touchend", function () {
        var biographyChapterId = $("#biogList li[class*='setting-active']").attr("data-id");
        if (biographyChapterId > 0) {
            ajaxTool.ajaxPost(appUrl("insertjoinmemory"), { biographyChapterId: biographyChapterId, cvnumber: getCurrentCV(), memoryId: memoryId }, function (result) {
                console.log(result);
                if (result.result == 10000) {
                    R.to("pageExperSet?articleId=" + memoryId + "&privacy=" + privacy, "", "");
                }
            });
        } else {
            app.alert("请选择一个进行收录");
        }

    });

    //权限
    biogList.on("#biogList .table-view-cell", "touchend", function (e, ev) {
        var self = ev.self;
        $(self).addClass("setting-active").siblings().removeClass("setting-active");
    })
    //返回
    biogList.on("#route-back", "touchend", function (e, ev) {
        R.to("pageExperSet?articleId=" + memoryId + "&privacy=" + privacy);
       
    })
})(jQuery);