﻿(function ($) {
    var about = pageAbout;
    about.iscroller = null;
    about.onPageLoadInit = function () {
        $.ajax({
            type: 'get',
            url: appUrl('about'),
            success: function (json) {
                json = eval("(" + json + ")");
                if (json&&json.length>0) {
                    $("#aboutlist").before($("#about").render(json));
                    about.iscroller.refresh();
                }
            }
        });
        about.iscroller = app.iscroll("#pageAbout");
    }
    about.on("#logout", "touchend", function (e, ev) {
        app.alert("确定退出吗？", [{
            title: "确定", fn: function () {
                //退出后 再进来 因为页面没有卸载 所以要 写入 页面更新标记 这样的话进入四个菜单页面 就会自动跟新
                localStorage.setItem("experischange_jy", "have");
                localStorage.setItem("experischange_our", "have");
                localStorage.setItem("thingchange_1", "have");
                localStorage.setItem("thingchange_2", "have");
                localStorage.setItem("thingchange_3", "have");
                deleteCurrentCv();
                R.to("login");
                app.hideAlert();
            }   
        }, {
            title: "取消", fn: function () {
                app.hideAlert();
            }
        }], "退出提示");
    });
})(jQuery);
