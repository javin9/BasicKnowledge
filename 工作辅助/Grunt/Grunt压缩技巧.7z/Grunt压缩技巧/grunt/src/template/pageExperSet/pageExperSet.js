﻿(function ($) {
    var sets = pageExperSet;
    var articleId = 0, code = "", privacy = 1, ispush = true;
    sets.onPageLoadInit = function () {
        var resultPlat = xzbTool.data.plat();
        ispush = $.getCookie("exper_push");
        $("#pushtxt").text("推送到" + (!!resultPlat[0].menu_title ? resultPlat[0].menu_title : "记忆"));
        ispush != "false" ? $(".switch").removeClass("off").addClass("on") : $(".switch").removeClass("on").addClass("off");
    }
    sets.onPageLoad = function () {
        articleId = sets.getParam('articleId');
        code = sets.getParam('code');
        privacy = sets.getParam("privacy");

        if (code == "ok") {
            privacy = 3;
        }
      
        $('#securityprivacy').find('li.table-view-cell').eq(privacy - 1).addClass("setting-active").siblings().removeClass("setting-active");
    }
    sets.on(".security .table-view-cell", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("setting-active") || $(self).index() == 2) return false;
        if ($(self).index() === 1) {
            $("#sendUp-exper").removeClass("on").addClass("off disabled");
            $("#sendUp-exper").find("input").val("off")
        } else {
            $("#sendUp-exper").removeClass("disabled");
        }
        $(self).addClass("setting-active").siblings().removeClass("setting-active");
    })
    //记忆
    sets.on(".switch", "touchend", function (e, ev) {
        var that = ev.self;
        if ($(that).hasClass("disabled")) return false;
        if ($(that).hasClass("off")) {
            $(that).removeClass("off").addClass("on");
            $(that).find("input").val("on");
        } else {
            $(that).removeClass("on").addClass("off");
            $(that).find("input").val("off");
        }
    });
    //返回
    sets.on("#ExperBack", "touchend", function () {
        if (R.prePage.name == 'pageOur') {
            R.to(-1);
        } else {
            R.to("pageExperEditor?Id=" + articleId);
        }
    });
    //经历部分可见
    sets.on("#pageExper_partSee", "touchend", function () {
        R.to("pageSelecter?id=" + articleId + "&articleType=1");
    });
    sets.on("#shoulu", "touchend", function () {
        R.to("pageBiogList?memoryId=" + articleId + "&privacy=" + privacy);
    });
    //完成   getCurrentCV()
    sets.on(".pull-right", "touchend", function (e, ev) {
        var privacy = $(".security li[class*='setting-active']").index() + 1;
        var isPush = $("#kg_push").val() == "on" ? 1 : 0;

        ajaxTool.ajaxPost(appUrl("updateprivacy"), { articleId: articleId, articleType: 1, cvNumber: getCurrentCV(), privacy: privacy, isPush: isPush }, function (result) {
            if (result.result == 10000) {
                ExperLocData();
                R.to("pageOur");
                //alert("保存成功");
            }
        });
    });

})(jQuery);
