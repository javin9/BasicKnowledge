﻿(function ($) {
    var currentPageName = R.currPage.name;
    var notdefine = 'undefined';
    var cvnumber ;// getCurrentCV();
    var oldUserInfo = {};//旧值，判断有没有修改
    pageCarList.onPageLoad = function () {
        cvnumber = getCurrentCV();
        pageCardHelper.init();
    }
 
    var pageCardHelper = {
        options: {
            cvnumber: 0,
            platform: 0
        }, 
        init: function () {
            if (this.isload()) {
                return;
            } else {
                this.options.cvnumber = cvnumber;
                this.options.platform = 1;
                this.getinfo();
            }
        },
        back: function () {
            R.to("pageCarList",10);
        },
        handleJSON: function (j) {
            for (var k in j) { if (!j[k]) j[k] = '待填写'; }
            return j;
        },
        isload: function () {
            return !!($('#pageCar_userCardInfo .page-content').length);
        },
        setinfo: function (id,name) {
            appUser.get(cvnumber, function (result) {
                oldUserInfo[name] = EmojiJM(result[name]);
                $('#' + id).val(EmojiJM(result[name]));
            });
        },
        updateinfo: function (id, name) {
            var val = $.trim($('#' + id).val());
            
            if (oldUserInfo[name] === val || (val == "" && oldUserInfo[name]==null)) {
                log('没有修改内容，不做更新，直接返回');
                this.back();
            } else {
                appUser.update(cvnumber, name, val, function () {
                    log('修改成功，返回');
                    $('#pageCar_list_' + name).text(val);
                    pageCardHelper.back();
                });
            }
        },
        getinfo: function () {
            appUser.get(pageCardHelper.options.cvnumber, function (result) {
                    var userInfoHtml = jsRenderBinding({
                        page: "pageCar.templateCarList",
                        json: pageCardHelper.handleJSON(result)
                    });
                    $('#pageCar_userCardInfo').html(userInfoHtml);
                    //最后初始化滚动条
                    app.iscroll("#pageCar_userCardInfo");
            }, function (msg) {
                log(msg);
            });
        },
        getphone: function (callback) {
            appUser.get(cvnumber, function (result) {
                if (result) {
                   callback(result)
                }
            });
        },
        updatehide: function (hide) {
            appUser.update(cvnumber, 'ishidemobile', hide, function () {
                $('#pageCar_mobilePublic').text('(' + (hide ? '不公开' : '公开') + ')');
            })
        },
        updatephoto: function (data) {
            appUser.update(cvnumber, 'headphoto', data.web_url, function () {
                $('#pageCarList_list_photo').attr('src', data.web_url);
                pageCardHelper.back();
            })
        }
    };
    window.pageCardHelper = pageCardHelper;
})(jQuery);