﻿;(function ($) {
    pageCarAddress.onPageLoad = function () {
        pageCardHelper.setinfo('pageCar_address', 'address');
    }
    //保存
    pageCarAddress.on('.pull-right', 'touchend', function (e, ev) {
        pageCardHelper.updateinfo('pageCar_address', 'address');
    });
})(jQuery);