﻿(function ($) {
    var pwdSet = pagePwdSet;
    pwdSet.iscroller = null;
    pwdSet.onPageLoadInit = function () {
        pwdSet.iscroller = app.iscroll("#pwdSet");

    }
    pwdSet.on("#cpwd", "touchend", function (e, ev) {
        var that = $(e.target);
        var of = $("#of").val().trim(),
            nf = $("#nf").val().trim(),
            ns = $("#ns").val().trim();


        if (/^\s*$/.test(of)) {
            app.alert('请填写原密码');
            return false;
        }
        if (/^\s*$/.test(nf)) {
            app.alert('请填写新密码');
            return false;
        }
        if (/^\s*$/.test(ns)) {
            app.alert('请填写确认密码');
            return false;
        }

        if (nf != ns) {
            app.alert('新密码和确认密码不一致');
            return false;
        }

        if (!that.hasClass('btn-disabled')) {
            $.ajax({
                type: 'post',
                url: appUrl('cpwd'),
                beforeSend: function () {
                    that.addClass('btn-disabled');
                },
                data: { cvnumber: getCurrentCV(), loginPwd: of, newPwd: nf },
                success: function (json) {
                    console.log(json);
                    if (json.result == 10000) {
                        app.alert(json.msg);
                        R.to('login');
                    } else {
                        app.alert(json.msg);
                    }
                    that.removeClass('btn-disabled');
                }
            });
        }

    });
})(jQuery);