(function($){
    var sel = pageSelecter;
    sel.scroller = null;
    sel.scroller1 = null;
    sel.onPageLoad = function () {
	    
        //初始化搜索框
        app.searchInit(".search");
        if (!sel.scroller) {
            sel.scroller = app.iscroll("#pageScrollSingle");
            sel.scroller1 = app.iscroll('#pageScrollMuilty');
        }
        initSelect();
        initDidSelected();
        //绑定数据
        bind();
        //初始化显示哪个
        selecter.init();
        //注册点击框事件
        box.registerEvent(sel);
    }
	

    //开关
    sel.on(".switch","touchend",function(e,ev){
        var that = ev.self;
        if ($(that).hasClass("disabled")) return false;
        if ($(that).hasClass("off")) {
            $(that).removeClass("off").addClass("on");
            $(that).find("input").val("on");
        } else {
            $(that).removeClass("on").addClass("off");
            $(that).find("input").val("off");
        }
    })
	

    //关闭选择
    sel.on(".modal-over-back","touchend",function(e,ev){
        close();
    })
	
    //选择
    sel.on(".btn-checkbox","touchend",function(e,ev){
        var that = ev.self;
        app.checkBox($(that));
    })
    //点击班级
    sel.on('#pageSelecter_right_class>li>span', 'touchend', function (e, ev) {
        var $this = $(ev.self);
        var selected = $this.hasClass('on');//是否选中
        var joinid = $this.data('joinid');
        var data = { eid: 0, year: 0, joinid: 0 };
        var ey = getCurrentYearEid();
        data.eid = ey.eid;
        data.year = ey.year;
        data.joinid = joinid;
        if (selected) {
            //如果选中，那么添加
            selecter.addClass(data);
        } else {
            //没有选中，那么移除
            selecter.removeClass(data);
        }
    });
    //点击右侧年份
    sel.on('#pageSelecter_right_year>li>span', 'touchend', function (e, ev) {
        var joinid = $(ev.self).data('joinid');
        var eid = getCurrentLeftEid();
        var data = {
            eid: eid,
            joinid:joinid
        };
        if ($(ev.self).hasClass('on')) {
            selecter.addGrade(data);
        } else {
            selecter.removeGrade(data);
        }
    });
    //点击左侧系
    sel.on('#pageSelecter_left_xi>li', 'touchend', function (e, ev) {
        var xi = $(ev.self).data('value');
        //初始化选中哪个的系
        selecter.resetSelectedZY(xi);
    });
    //点击左侧阶段筛选年份
    sel.on('#pageSelect_left_edu>li', 'touchend', function (e, ev) {
        var eid = $(ev.self).data('value');
        selecter.resetSelectedYear(eid);
    });

    //点击右侧专业
    sel.on('#pageSelecter_right_zhuanye>li>span', 'touchend', function (e, ev) {
        var $this = $(ev.self);
        var data = { flag: $this.data('flag'), value: $this.data('value') };
        if ($this.hasClass('on')) {
            selecter.addZY(data);
        } else {
            selecter.removeZY(data);
        }
    });

    sel.on('.pull-left', 'touchend', function () {
        if (selecter.params.articleId > 0) {
            var page = '';
            switch (parseInt(selecter.params.articleType)) {
                case 1:
                    page = 'pageExperSet';
                    break;
                case 2:
                    page = 'pageActivitySet';
                    break;
                case 3:
                    page = 'pageThingSet';
                    break;
            }
            R.to(page + '?code=cancle&articleId=' + selecter.params.articleId, 10);
        } else {
            R.to(-1, 10);
        }
    });

    //最终确定保存
    sel.on('#pageSelecter_lastConfirm', 'touchend', function (e, ev) {
        var allWorker, allStudent, allSchoolFriend;//是否所有
        allStudent = selecter.isSwitchOn('pageSelecter_selectAllStudent');
        allWorker = selecter.isSwitchOn('pageSelecter_selectAllWorker');
        allSchoolFriend = selecter.isSwitchOn('pageSelecter_selectAllSchoolFriend');
        var json = selecter.getResult(allWorker, allStudent, allSchoolFriend);
        //如果是文章，那么就保存，否则，直接存到本地缓存，转换给查询人物的条件里面去
        var article = selecter.params.articleId > 0;
        json.cvNumber = getCurrentCV();
        json.Pid = 0;
        json.articleId = selecter.params.articleId || 0;
        json.usersearch = false;
        console.log("dddd");
        log(json.str);
        //string str, RetrieveOptionsSingle single, bool issingle, long cvNumber, int Pid, long articleId
        ajaxTool.ajaxPost(appUrl('user/savesearch'), json, function (result) {
            if (result.result == 10000) {
                var page = R.prePage.name || 'pageFigure';
                if (json.articleId > 0) {

                    //pageExperSet ： 1   pageActivitySet ：2  pageThingSet ：3
                    switch (parseInt(selecter.params.articleType)) {
                        case 1:
                            page = 'pageExperSet';
                            break;
                        case 2:
                            page = 'pageActivitySet';
                            break;
                        case 3:
                            page = 'pageThingSet';
                            break;
                    }
                    R.to(page + '?code=ok&articleId=' + json.articleId, 10);
                } else {
                    if (selecter.params.single) {
                        //只有单选才会走这一步
                        var newArray = [];
                        for (var i = 0; i < result.data.length; i++) {
                            newArray.push({
                                flag: result.data[i].flag,
                                value: result.data[i].value,
                                type: result.data[i].type
                            });
                        }
                        json.str = JSON.stringify(newArray);
                    }
                    pubFigure.setFigureSearchOptions(json.str);
                    R.to(page, 10);
                }
            } else {
                app.alert('出错啦');
            }
        })
    });



    //初始化各个选择框
    function initSelect() {
        /*教职工*/
        sel.on('.pageSelecter_select_position', 'touchend', function (e, ev) {
            $(".modal-over-back").addClass("modal-overlay-visible");
            $("#pageSelecter_module_position").addClass("selecter-in");
            app.iscroll('#pageSelecter_scroll_position');
        });
        /*在校生*/
        //选择班级
        sel.on("#pageSelecter_select_class", "touchend", function (e, ev) {
            $("input[type=search]").blur();
            $(".modal-over-back").addClass("modal-overlay-visible");
            $("#pageSelecter_module_class").addClass("selecter-in");
            app.iscroll("#pageSelecter_scroll_year");
            app.iscroll("#pageSelecter_scroll_class");
            //在校生
            selecter.setType(moduleType.student);
            selecter.resetSelectedClass();
        })

        //选择系
        sel.on("#pageSelecter_select_xi", "touchend", function (e, ev) {
            $(".modal-over-back").addClass("modal-overlay-visible");
            $("#pageSelecter_module_xi").addClass("selecter-in");
            app.iscroll('#pageSelecter_scroll_rightxi');
            //在校生
            selecter.setType(moduleType.student);
            //重置之前选择的
            selecter.resetSelectedXi();
        })

        //选择年份
        sel.on("#pageSelecter_select_year", "touchend", function (e, ev) {
            $(".modal-over-back").addClass("modal-overlay-visible");
            $("#pageSelecter_module_year").addClass("selecter-in");
            app.iscroll("#pageSelecter_scroll_edu");
            app.iscroll('#pageSelecter_scroll_rightyear');
            //在校生
            selecter.setType(moduleType.student);
            selecter.resetSelectedYear();
        })

        //选择专业
        sel.on("#pageSelecter_select_zhuanye", "touchend", function (e, ev) {
            $(".modal-over-back").addClass("modal-overlay-visible");
            $("#pageSelecter_module_zhuanye").addClass("selecter-in");
            app.iscroll("#pageSelecter_scroll_zhuanye");
            app.iscroll('#pageSelecter_scroll_leftxi');
            //在校生
            selecter.setType(moduleType.student);
            selecter.resetSelectedZY();
        })

        /*校友*/
        //选择班级
        sel.on("#pageSelecter_select1_class", "touchend", function (e, ev) {
            $("input[type=search]").blur();
            $(".modal-over-back").addClass("modal-overlay-visible");
            $("#pageSelecter_module_class").addClass("selecter-in");
            app.iscroll("#pageSelecter_scroll_year");
            app.iscroll("#pageSelecter_scroll_class");
            //xiaoyou
            selecter.setType(moduleType.schoolfriend);
            selecter.resetSelectedClass();
        })

        //选择系
        sel.on("#pageSelecter_select1_xi", "touchend", function (e, ev) {
            $(".modal-over-back").addClass("modal-overlay-visible");
            $("#pageSelecter_module_xi").addClass("selecter-in");
            app.iscroll('#pageSelecter_scroll_rightxi');
            //xiaoyou
            selecter.setType(moduleType.schoolfriend);
            selecter.resetSelectedXi();
        })

        //选择年份
        sel.on("#pageSelecter_select1_year", "touchend", function (e, ev) {
            $(".modal-over-back").addClass("modal-overlay-visible");
            $("#pageSelecter_module_year").addClass("selecter-in");
            app.iscroll("#pageSelecter_scroll_edu");
            app.iscroll('#pageSelecter_scroll_rightyear');
            //xiaoyou
            selecter.setType(moduleType.schoolfriend);
            selecter.resetSelectedYear();
        })

        //选择专业
        sel.on("#pageSelecter_select1_zhuanye", "touchend", function (e, ev) {
            $(".modal-over-back").addClass("modal-overlay-visible");
            $("#pageSelecter_module_zhuanye").addClass("selecter-in");
            app.iscroll("#pageSelecter_scroll_zhuanye");
            app.iscroll('#pageSelecter_scroll_leftxi');
            //xiaoyou
            selecter.setType(moduleType.schoolfriend);
            selecter.resetSelectedZY();
        });
    }

    //绑定确定选择
    function initDidSelected(){
        sel.on('.selecter-btn-right', 'touchend', function (e, ev) {
            var $this = $(ev.self);
            var t = $this.data('type');
            if(selecter.isStudent()){
                switch (t) {
                    case 'banji':
                        break;
                    case 'year':
                        break;
                    case 'zhuanye':
                        break;
                    case 'xi':
                        var xi = selecter.getSelected('pageSelecter_right_xi');
                        if (xi.length) {
                            selecter.selectedResult.student.xi = xi;
                        }
                        break;
                }
            } else if (selecter.isSchoolFriend()) {
                switch (t) {
                    case 'banji':
                        break;
                    case 'year':
                        break;
                    case 'zhuanye':
                        break;
                    case 'xi':
                        var xi = selecter.getSelected('pageSelecter_right_xi');
                        if (xi.length) {
                            selecter.selectedResult.schoolfriend.xi = xi;
                        }
                        break;
                }
            } else {
                if (t == 'zhineng') {
                    var p = selecter.getSelected('pageSelecter_right_position');
                    selecter.selectedResult.worker.position = p;
                }
                //其他情况
                box.handleConfirm(t);
            }
            //关闭
            close();
        });
    }
    //绑定数据
    function bind() {
        xzbTool.bind.bindYear('#pageSelecter_left_year');
        xzbTool.bind.bindJD('#pageSelecter_right_edu');
        xzbTool.bind.bindLeftJD('#pageSelect_left_edu');
        var eid = getCurrentLeftEid();//下一句得用，暂时放下
        xzbTool.bind.bindRightYear('#pageSelecter_right_year');
        xzbTool.bind.bindLeftXi('#pageSelecter_left_xi');
        var xi = getCurrentLeftXi();
        xzbTool.bind.bindRightZY('#pageSelecter_right_zhuanye',xi);
        xzbTool.bind.bindXi('#pageSelecter_right_xi');
        xzbTool.bind.bindZn('#pageSelecter_right_position');
        var r = getCurrentYearEid();
        xzbTool.bind.bindClass('#pageSelecter_right_class', r);
        //绑定样式
        setSelectClassChange(sel);//选中变化

	   
    }
    //选中变化
    //班级条件变化
    function setSelectClassChange(obj) {
        //年级
        obj.on('.selecter-left-list>ul>li', 'touchend', function (e, ev) {
            var $this = $(ev.self);
            var year = $this.data('joinid');
            $this.addClass('current').siblings().removeClass('current');
            var r = getCurrentYE(obj);
            xzbTool.bind.bindClass('#pageSelecter_right_class', r);
            //设置已经选中的项
            selecter.resetSelectedClass();
        });
        //阶段
        obj.on('.selecter-right-title>span', 'touchend', function (e, ev) {
            var $this = $(ev.self);
            var eid = $this.data('joinid');
            $this.addClass('current').siblings().removeClass('current');
            var r = getCurrentYearEid();
            xzbTool.bind.bindClass('#pageSelecter_right_class', r);
            //设置已经选中的项
            selecter.resetSelectedClass();
        });
    }
    //获取当前选中条件
    function getCurrentYearEid() {
        var year = $('#pageSelecter_scroll_year>ul>li').filter('.current').first();
        if (!year.length) {
            year = $('#pageSelecter_scroll_year>ul>li').first();
            year.addClass('current');
        }
        var eid = $('.selecter-right-title>span').filter('.current').first();
        if (!eid.length) {
            eid = $('.selecter-right-title>span').first();
            eid.addClass('current');
        }
        var r = {
            year: year.length ? year.data('value') : 0,
            eid: eid.length ? eid.data('value') : 0
        }
        return r;
    }
    //获取左侧系
    function getCurrentLeftXi() {
        var firstXi = $('#pageSelecter_left_xi>li').filter('.current').first();
        if (!firstXi.length) {
            firstXi = $('#pageSelecter_left_xi>li').first();
            firstXi.addClass('current');
            return firstXi.data('value');
        }
        return firstXi.data('value');
    }
    // 获取当前选中的左侧阶段
    function getCurrentLeftEid() {
        var firstE = $('#pageSelect_left_edu>li').filter('.current').first();
	   
        if (!firstE.length) {
            firstE = $('#pageSelect_left_edu>li').first();
            firstE.addClass('current');
            return firstE.data('value');
        }
        return firstE.data('value');
    }
    //关闭
    function close() {
        $(".selecter-in").removeClass("selecter-in");
        $(".modal-over-back").removeClass("modal-overlay-visible");
    }
    //当前弹出类型
    var moduleType = {
        worker:0,
        student: 1,
        schoolfriend: 2
    }
    //flag应该从p.js里面取
    var flag = {
        e:1,
        year:8,
        b:5,
        z:4,
        identity: 9,
        xi:3
    }
    //默认身份
    var identity = {
        student: 1,
        schoolfriend: 2,
        teacher: 3,
        worker: 4
    };
    //通用弹框选择，单选，适用于其他身份（其实其他身份也需要通用，时间问题，暂缓）
    var box = {
        identity:{
            current: 0,
            allOthers:[]
        },
        result:{},
        registerEvent: function (obj) {
            obj.on(".selectobj", "touchend", function (e, ev) {
                var that = $(ev.self),
                    selectid = that.find('span').attr('data-selectid');
                var identityId = that.data('identity');
                box.identity.current = identityId;
                var oSelecter = $('#pageSelecterIdentitySelect>.selecter[data-typeid="' + selectid + '"]').first();
                $(".modal-over-back").addClass("modal-overlay-visible");
                oSelecter.addClass('selecter-in');
                app.iscroll('#list' + selectid);
            });
        },
        //处理单选选中
        handleConfirm: function (flag) {
            var selectedArr = [];
            $('#list' + flag + '>ul>li').each(function (i, item) {
                var $this = $(this);
                var s = $this.find('span').first();
                if (s.hasClass('on')) {
                    selectedArr.push({
                        flag: flag, value: s.data('joinid'),
                        identity: box.identity.current
                    });
                }
            });
            var key = box.identity.current.toString() + flag.toString();
            this.result[key] = {};
            this.result[key]["arr"] = selectedArr;
            this.result[key]["all"] = $('#pageSelecter_selectAll' + box.identity.current).hasClass('on');
            log(this.result);
        },
        getSingleTemplate: function (flag) {
            var confirmButton = '<div class="selecter-btn"><span class="selecter-btn-right" data-type="' + flag + '">确定</span></div>';
            var name = xzbTool.getTemplateType(flag);
            var template = '<div class="selecter" data-template="1" data-typeid="' + flag + '"  data-typeName="' + name + '">' + confirmButton + '<div class="selecter-right"><div class="selecter-right-list"  id="list' + flag + '"><ul class="table-view">{{for data}}<li  class="table-view-cell"><span class="btn-checkbox" data-flagid="{{:flag}}" data-joinid="{{:id}}" >{{:name}}</span><input type="hidden" value="off" /></li>{{/for}}</ul></div></div></div>';
            var data = { data: xzbTool.getAll(flag) };
            var html = xzbTool.bind.render(template, data);
            return html;
        },
        getTemplate: function (flag, op) {
            var o = parseInt(op);
            switch (o) {
                case 1:
                    return this.getSingleTemplate(flag);
                    break;
                default: return "";
            }
        }
	};
    //帮助类
	var selecter = {
	    init: function (identity) {
	        var single = $('#pageSelecter_singleSelect');
	        var mulity = $('#pageSelecter_muiltySelect');
	        var scrollMulity = $('#pageScrollMuilty');
	        var scrollSingle =$('#pageScrollSingle');
	        //开始执行页面加载内容
	       
	        appUser.getid(getCurrentCV(), function (user) {
	            var schoolfriend = false; student = false; zhiye = false;
	            for (var i = 0; i < user.length; i++) {
	                if (user[i].joinid == 1) {
	                    student = true;
	                }
	                if (user[i].joinid == 2) {
	                    schoolfriend = true;
	                }
	                if (user[i].joinid == 3 || user[i].joinid == 4) {
	                    zhiye = true;
	                }
	            }
	            if (zhiye) {
	                //如果是教职工
	                mulity.show();
	                scrollSingle.hide();
	                single.hide();
	                selecter.params.single = false;//非单选
	            } else {
	                //其他条件
	                mulity.hide();
	                scrollMulity.hide();
	                single.show();
	                selecter.params.single = true;//单选
	            }
	            selecter.loadHtml();
	            selecter.refresh();
	        });
	        this.params.articleId = R.getPara('id', 'id');
	        this.params.articleType = R.getPara('articleType', 'articleType');
	        //如果之前的页面是从劳人记忆过来的那么usersearch=true
	        if (R.prePage == '') {

	        }

	    },
	    loadHtml: function () {
	        $('.indentity').hide();//所有的先隐藏
	        if (this.hasSchoolFriend()) {
	            $('.identity2').show();
	        }
	        if (this.hasStudent()) {
	            $('.identity1').show();
	        }
	        if (this.hasWorker()) {
	            $('.identity4').show();
	        }
	        this.handleOtherIdentity();
	    },
	    hasStudent: function () {
	        return this.hasFlag(identity.student);
	    },
	    hasSchoolFriend: function () {
	        return this.hasFlag(identity.schoolfriend);
	    },
	    hasWorker: function () {
	        return this.hasFlag(identity.teacher) || this.hasFlag(identity.worker);
	    },
	    hasFlag: function (f) {
	        //判断身份的显示
	        var ids = xzbTool.data.allI();// 1,2,3,4
	        var arr = $.grep(ids, function (item, i) {
	            return item.id == f;
	        });
	        return arr.length > 0;
	    },
        //处理其他身份
	    handleOtherIdentity: function () {
	        var muilty = $('#pageSelecter_muiltySelect');
	        var single = $('#pageSelecter_singleSelect');
	        var selecterBox = $('#pageSelecterIdentitySelect');//select 容器
            //获取所有身份
	        var ids = xzbTool.data.allI();// 1,2,3,4
	        var arr = $.grep(ids, function (item, i) {
	            return item.id > identity.worker;
	        });
	        //获取所有template
	        var selectids = xzbTool.data.allIDSelected();
	       
	        var allOtherIdentity = [];

	        for (var i = 0; i < arr.length; i++) {
                //获取该身份下的可选择项
	            var items = $.grep(selectids, function (item, m) {
	                return item.RegId == arr[i].id && item.Operation!="0";
	            });
	            console.log(items);
	            var newItems = [];
	            for (var n = 0; n < items.length; n++) {
	                newItems.push({
	                    flag: items[n].DataId,
	                    name: items[n].Name,
	                    operate: items[n].Operation,
                        identityId:arr[i].id
	                });
	                //需要在页面上添加相应的选择框
	                var selectHtml = box.getTemplate(items[n].DataId, items[n].Operation);
	                selecterBox.append(selectHtml);
	            }

	            var data = {
	                identityName: arr[i].name,
	                identityId: arr[i].id,
	                items: newItems
	            };
	            allOtherIdentity.push(data);
	        }
	        var html = jsRenderBinding({
	            page: "pageSelecter.pageSelecter_template_singleCommonSelecter",
	            json: allOtherIdentity
	        });
	        if (selecter.params.single) {
	            single.append(html);
	        } else {
	            muilty.append(html);
	        }
            //要给赋值，最后保存的时候要用
	        box.identity.allOthers = allOtherIdentity;
	    },
	    refresh: function () {
	        sel.scroller.refresh();
	        sel.scroller1.refresh();
	    },
	    isSwitchOn: function (id) {
	        return $('#' + id).hasClass('on');//是否开关打开
	    },
	    isStudent: function () {
	        return this.params.moduleType == moduleType.student;
	    },
	    isSchoolFriend: function () {
	        return this.params.moduleType == moduleType.schoolfriend;
	    },
	    params: {
	        moduleType: 0,
	        single: false,
	        articleId: 0,
            articleType:0,
            usersearch:false
	    },
	    getId: function (callback) {
	        ajaxTool.ajaxGet(appUrl('user/identity'), { cvnumber: getCurrentCV() }, function (result) {
	            callback(result);
	        })
	    },
	    selectedResult: {
	        worker: {
	            position:[]
	        },
	        student: {
	            classes: [],
	            grade: [],
	            zhuanye: [],
                xi:[]
	        },
	        schoolfriend: {
	            classes: [],
	            grade: [],
	            zhuanye: [],
	            xi: []
	        }
	    },
	    singleResult: {
	        student: {
                all:false,
	            sameclass: false,
	            samegrade: false,
	            samezy: false,
                samexi:false
	        },
	        schoolfriend: {
                all:false,
	            sameclass: false,
	            samegrade: false,
	            samezy: false,
	            samexi: false
	        }
	    },
	    setType: function (t) {
	        this.params.moduleType = t;
	    },
	    getSelected: function (id) {
	        var obj = [];//重置
	        $('#' + id + ' li').each(function () {
	            var $span = $(this).find('span');
	            if ($span.hasClass('on')) {
	                //选中
	                var item = {
	                    flag: $span.data('flag'),
	                    value: $span.data('value')
	                }
	                obj.push(item);
	            }
	        });
	        return obj;
	    },
	    getSelectedClass: function () {
	    },
	    addClass: function (data) {
	        if (this.params.moduleType == moduleType.student) {
	            //学生添加班级
	            this.selectedResult.student.classes.push(data);
	        } else {
	            //校友添加班级
	            this.selectedResult.schoolfriend.classes.push(data);
	        }
	    },
	    addGrade: function (data) {
	        if (this.isStudent()) {
	            selecter.selectedResult.student.grade.push(data);
	        }
	        if (this.isSchoolFriend()) {
	            selecter.selectedResult.schoolfriend.grade.push(data);
	        }
	    },
	    addZY: function (data) {
	        if (this.isStudent()) {
	            this.selectedResult.student.zhuanye.push(data);
	        }
	        if (this.isSchoolFriend()) {
	            this.selectedResult.schoolfriend.zhuanye.push(data);
	        }
	    },
	    removeZY: function (data) {
	        if (this.isStudent()) {
	            var arr = $.grep(this.selectedResult.student.zhuanye, function (item, i) {
	                return item.value != data.value;
	            });
	            this.selectedResult.student.zhuanye = arr;
	        }
	        if (this.isSchoolFriend()) {
	            var arr = $.grep(this.selectedResult.schoolfriend.zhuanye, function (item, i) {
	                return item.value != data.value;
	            });
	            this.selectedResult.schoolfriend.zhuanye = arr;
	        }
	    },
	    removeGrade: function (data) {
	        if (this.isStudent()) {
	            var arr = $.grep(selecter.selectedResult.student.grade, function (item, i) {
	                return item.eid != data.eid || item.joinid != data.joinid;
	            });
	            selecter.selectedResult.student.grade = arr;
	        } else {
	            var arr = $.grep(selecter.selectedResult.schoolfriend.grade, function (item, i) {
	                return item.eid != data.eid || item.joinid != data.joinid;
	            });
	            selecter.selectedResult.schoolfriend.grade = arr;
	        }
	    },
	    removeClass: function (data) {
	        if (this.isStudent()) {
	            var arr = $.grep(selecter.selectedResult.student.classes, function (item, i) {
                    //删除那个已经选中的
	                return item.eid != data.eid || item.year != data.year || item.joinid != data.joinid;
	            });
	            selecter.selectedResult.student.classes = arr;
	        } else {
	            //校友删除班级
	            var arr = $.grep(selecter.selectedResult.schoolfriend.classes, function (item, i) {
	                //删除那个已经选中的
	                return item.eid != data.eid || item.year != data.year || item.joinid != data.joinid;
	            });
	            selecter.selectedResult.schoolfriend.classes = arr;
	        }
	    },
	    resetSelectedClass: function () {
	        //重新设置选中项
	        var data = [];
	        if (selecter.isStudent()) {
	            data = selecter.selectedResult.student.classes;
	        } else {
	            data = selecter.selectedResult.schoolfriend.classes;
	        }
	        $('#pageSelecter_right_class>li>span').each(function () {
	            var id = $(this).data('joinid');
	            var ey = getCurrentYearEid();
	            var arr = $.grep(data, function (item, i) {
	                return item.joinid == id && item.eid ==ey.eid && item.year == ey.year ;
	            });
	            if (arr.length) {
	                $(this).addClass('on');
	            } else {
	                $(this).removeClass('on');
	            }
	        })
	    },
	    resetSelectedZY: function (xi) {

	        xi = xi || getCurrentLeftXi();
	        xzbTool.bind.bindRightZY('#pageSelecter_right_zhuanye', xi);
	        //绑定完之后，赋之前选择的值
	        $('#pageSelecter_right_zhuanye>li>span').each(function () {
	            var value = $(this).data('value');
	            var data = selecter.isStudent() ? selecter.selectedResult.student.zhuanye : selecter.selectedResult.schoolfriend.zhuanye;
	            var arr = $.grep(data, function (item, i) {
	                return item.value == value;
	            });
	            if (arr.length) {
	                $(this).addClass('on');
	            } else {
	                $(this).removeClass('on');
	            }
	        })
	    },
	    resetSelectedYear: function (eid) {
	        eid = eid || getCurrentLeftEid();

	        xzbTool.bind.bindRightYear('#pageSelecter_right_year', eid);
	        app.iscroll('#pageSelecter_scroll_rightyear');
	        var data = this.isStudent()?selecter.selectedResult.student.grade:selecter.selectedResult.schoolfriend.grade;
	        $('#pageSelecter_right_year>li>span').each(function () {
	            var year = $(this).data('joinid');
	            var arr = $.grep(data, function (item, i) {
	                return item.eid == eid && item.joinid == year;
	            });
	            if (arr.length) {
                    //添加已经选中的样式
	                $(this).addClass('on');
	            }
	        });
	    },
	    resetSelectedXi: function () {
            
	        var data = this.isStudent() ? this.selectedResult.student.xi : this.selectedResult.schoolfriend.xi;
	        //pageSelecter_right_xi
	        $('#pageSelecter_right_xi>li>span').each(function () {
	            var value = $(this).data('value');
	            var arr = $.grep(data, function (item, i) {
	                return item.value == value&&item.flag == flag.xi;
	            });
	            if (arr.length) {
	                $(this).addClass('on');
	            } else {
	                $(this).removeClass('on');
	            }
	        })
	    },
	    getResult: function (allWorker, allStudent, allSFriend) {
	        var result = [];

	        var allType = 1;//条件分组
	        if (this.params.single) {
	            allWorker = selecter.isSwitchOn('pageSelecter_singleSelectAllWorker');
	        }
	        //职工
	        if (allWorker) {
	            result.push({ flag: flag.identity, value: identity.worker, type: allType++ });
	            result.push({ flag: flag.identity, value: identity.teacher, type: allType++ });
	        } else {
	            var position = selecter.selectedResult.worker.position;
	            //每个身份和position是一组
	            for (var i = 0; i < position.length; i++) {
	                allType++;
	                var newPosition = {
	                    type: allType,
	                    flag: position[i].flag,
	                    value: position[i].value
	                };
	                result.push(newPosition);
	                result.push({ flag: flag.identity, value: identity.teacher, type: allType });
	            }
	            for (var i = 0; i < position.length; i++) {
	                allType++;
	                var newPosition = {
	                    type: allType,
	                    flag: position[i].flag,
	                    value: position[i].value
	                };
	                result.push(newPosition);
	                result.push({ flag: flag.identity, value: identity.worker, type: allType });
	            }
	        }

	        if (this.params.single) {
	            //pageSelecter_singleSelectAllStudent pageSelecter_singleSelectAllSchoolFriend
	            //如果是单选，那么只取得单选的值就可以
	            this.singleResult.student.all = this.isSwitchOn('pageSelecter_singleSelectAllStudent');
	            this.singleResult.student.sameclass = this.isSwitchOn('pageSelecter_singleStudentSameClass');
	            this.singleResult.student.samegrade = this.isSwitchOn('pageSelecter_singleStudentSameGrade');
	            this.singleResult.student.samezy = this.isSwitchOn('pageSelecter_singleStudentSameZY');
	            this.singleResult.student.samexi = this.isSwitchOn('pageSelecter_singleStudentSameXi');
	            this.singleResult.schoolfriend.all = this.isSwitchOn('pageSelecter_singleSelectAllSchoolFriend');
	            this.singleResult.schoolfriend.sameclass = this.isSwitchOn('pageSelecter_singleSFSameClass');
	            this.singleResult.schoolfriend.samegrade = this.isSwitchOn('pageSelecter_singleSFSameGrade');
	            this.singleResult.schoolfriend.samezy = this.isSwitchOn('pageSelecter_singleSFSameZY');
	            this.singleResult.schoolfriend.samexi = this.isSwitchOn('pageSelecter_singleSFSameXi');

	        } else {
	            //学生
	            if (allStudent) {
	                allType++;
	                var t = allType;
	                result.push({ flag: flag.identity, value: identity.student, type: t });
	            } else {
	                //专业
	                if (selecter.selectedResult.student.zhuanye.length) {
	                    var zhuanye = selecter.selectedResult.student.zhuanye;
	                    for (var i = 0; i < zhuanye.length; i++) {
	                        allType++;
	                        var t = allType;
	                        log("专业的type=" + t);
	                        zhuanye[i].type = t;
	                        result.push({ flag: flag.identity, value: identity.student, type: t });
	                        result.push(zhuanye[i]);
	                    }

	                }
	                //系
	                if (selecter.selectedResult.student.xi.length) {
	                    var xi = selecter.selectedResult.student.xi;
	                    for (var i = 0; i < xi.length; i++) {
	                        allType++;
	                        var t = allType;
	                        xi[i].type = t;
	                        result.push({ flag: flag.identity, value: identity.student, type: t });
	                        result.push(xi[i]);
	                    }

	                }
	                //班级
	                if (selecter.selectedResult.student.classes.length) {
	                    var classes = selecter.selectedResult.student.classes;
	                    for (var i = 0; i < classes.length; i++) {
	                        //type 等于各个id转换为string想加，有重复风险。。。
	                        allType++;
	                        var t = allType;
	                        result.push({ flag: flag.e, value: classes[i].eid, type: t });//阶段
	                        result.push({ flag: flag.b, value: classes[i].joinid, type: t });//班级
	                        result.push({ flag: flag.year, value: classes[i].year, type: t });//年份
	                        result.push({ flag: flag.identity, value: identity.student, type: t });
	                    }
	                }
	                //年份
	                if (selecter.selectedResult.student.grade.length) {

	                    var grade = selecter.selectedResult.student.grade;
	                    for (var i = 0; i < grade.length; i++) {
	                        allType++;
	                        var t = allType;
	                        result.push({ flag: flag.e, value: grade[i].eid, type: t });//阶段
	                        result.push({ flag: flag.year, value: grade[i].joinid, type: t });//年份
	                        result.push({ flag: flag.identity, value: identity.student, type: t });
	                    }
	                }
	            }
	            //朋友
	            if (allSFriend) {
	                allType++;
	                var t = allType;
	                result.push({ flag: flag.identity, value: identity.schoolfriend, type: t });
	            } else {
	                //专业
	                if (selecter.selectedResult.schoolfriend.zhuanye.length) {
	                    var zhuanye = selecter.selectedResult.schoolfriend.zhuanye;
	                    for (var i = 0; i < zhuanye.length; i++) {
	                        allType++;
	                        var t = allType;
	                        zhuanye[i].type = t;
	                        result.push({ flag: flag.identity, value: identity.schoolfriend, type: t });
	                        result.push(zhuanye[i]);
	                    }

	                }
	                //系
	                if (selecter.selectedResult.schoolfriend.xi.length) {
	                    var xi = selecter.selectedResult.schoolfriend.xi;
	                    for (var i = 0; i < xi.length; i++) {
	                        allType++;
	                        var t = allType;
	                        xi[i].type = t;
	                        result.push({ flag: flag.identity, value: identity.schoolfriend, type: t });
	                        result.push(xi[i]);
	                    }

	                }
	                //班级
	                if (selecter.selectedResult.schoolfriend.classes.length) {
	                    var classes = selecter.selectedResult.schoolfriend.classes;
	                    for (var i = 0; i < classes.length; i++) {
	                        //type 等于各个id转换为string想加，有重复风险。。。
	                        allType++;
	                        var t = allType;
	                        result.push({ flag: flag.e, value: classes[i].eid, type: t });//阶段
	                        result.push({ flag: flag.b, value: classes[i].joinid, type: t });//班级
	                        result.push({ flag: flag.year, value: classes[i].year, type: t });//年份
	                        result.push({ flag: flag.identity, value: identity.schoolfriend, type: t });
	                    }
	                }
	                //年份
	                if (selecter.selectedResult.schoolfriend.grade.length) {

	                    var grade = selecter.selectedResult.schoolfriend.grade;
	                    for (var i = 0; i < grade.length; i++) {
	                        allType++;
	                        var t = allType;
	                        result.push({ flag: flag.e, value: grade[i].eid, type: t });//阶段
	                        result.push({ flag: flag.year, value: grade[i].joinid, type: t });//年份
	                        result.push({ flag: flag.identity, value: identity.schoolfriend, type: t });
	                    }
	                }
	            }
	        }
	        //2016-1-8添加
	        //这里处理新的身份数据，用户自定义添加的身份
	        /*----开始处理----*/
	        var other = box.result;
	        var allOthers = box.identity.allOthers;
	        //先遍历得到所有相应的key  key= identityid+itemflag  例如 身份id是5 ，某个选项flag 为10  key =510  arr(选中的条件) all(是否全选)
	        //log(box.identity.allOthers);
	        for (var i = 0; i < allOthers.length; i++) {
	            var id = allOthers[i].identityId.toString();
	            //遍历身份底下的子项目
	            for (var n = 0; n < allOthers[i].items.length; n++) {
	                var f = allOthers[i].items[n].flag.toString();
	                var key = id + f;
	                log(other[key]);
	                //得到相应的结果之后，开始转换
	                if (!other[key]) {
	                    other[key] = {
	                        all: selecter.isSwitchOn('pageSelecter_selectAll' + id),
	                        arr: []
	                    };
	                }
	                var o = other[key];
	                log(selecter.isSwitchOn('pageSelecter_selectAll5'));
	                o.all = selecter.isSwitchOn('pageSelecter_selectAll' + id);//得重新获取，因为用户可能操作按钮
	                if (o.all) {
	                    //全部，直接添加一条身份
	                    allType++;
	                    result.push({ flag: flag.identity, value: allOthers[i].identityId, type: allType });
	                } else {
	                    //遍历arr
	                    for (var a = 0; a < o.arr.length; a++) {
	                        var t = allType++;
	                        result.push({ flag: o.arr[a].flag, value: o.arr[a].value, type: t });
	                        result.push({ flag: flag.identity, value: allOthers[i].identityId, type: t });
	                    }
	                }

	            }
	        }
	        /*----处理完毕----*/
	        var json = JSON.stringify(result);
	        console.log(json);
	        var j = { str: json, single: this.singleResult, issingle: this.params.single };
	        return j;
	    }
	};
})(jQuery)