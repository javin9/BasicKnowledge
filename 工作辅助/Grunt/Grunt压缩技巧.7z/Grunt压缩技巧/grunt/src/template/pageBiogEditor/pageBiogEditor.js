﻿(function ($) {
    var biogEditor = pageBiogEditor;
    biogEditor.iscroller = null;
    biogEditor.initPhoto = null;
    biogEditor.editor = null;
    biogEditor.bioc = null;
    biogEditor.isPublic = 1;
    biogEditor.onPageLoadInit = function () {

    };

    biogEditor.onPageLoad = function () {
        biogEditor.initSet();
        var id = biogEditor.getParam("id") || 0;
        if (id == 0) {//添加
            biogEditor.editor = null;
            biogEditor.editor = new EditMobileClass(document.getElementById("bioedit"));
            biogEditor.editor.init();
            EditMobileData.text.add(biogEditor.editor);
        } else {//编辑
            biogEditor.getCharpter(id);
        }
        $("#savecharpter").attr("data-id", id);//id
    };
    biogEditor.initSet = function () {
        var headerF = $("#bioheader  span").eq(0);
        if (!headerF.hasClass("header-tag-active")) {
            headerF.addClass('header-tag-active').siblings().removeClass('header-tag-active');
        }

        $("#biotitle").val('');
        $("#previeTitle").text('');
        $("#previewContent,#biocontents").text('');
        $(".exper-content").show();
    };
    //查询编辑的数据
    biogEditor.getCharpter = function (id) {
        var cvNumber = getCurrentCV();
        if (cvNumber > 0) {
            $.ajax({
                type: 'post',
                async: false,
                url: appUrl('chapteredit'),
                data: { id: id, cvNumber: cvNumber },
                success: function (json) {
                    if (json.Result == 10000) {
                        biogEditor.bioc = json.Data.BioC;
                        var title = EmojiJM(biogEditor.bioc.Title),
                            content = biogEditor.bioc.Contents;
                        biogEditor.isPublic = biogEditor.bioc.IsPublic;

                        $("#biotitle").val(title); $("#previeTitle").text(title);//title
                        biogEditor.editor = null;
                        biogEditor.editor = new EditMobileClass(document.getElementById("bioedit"), EmojiJM(content));
                        biogEditor.editor.init();

                        if (json.Data.BioMList.length > 0) {
                            $("#biomemorylist").html($("#biomemoryTemplate").render(json.Data.BioMList));
                        }
                    }
                }, error: function () {
                    alert('error!');
                }
            });
        }

    };
    //生成媒体json
    biogEditor.createMediaJson = function (parent, cvNumber) {
        var imgArrObj = parent.find("div.app-editor-img").find("img"),
              videoArrObj = parent.find("video"),
            mediaArr = [],
            template = '{"CvNumber":"{0}","BioID":"BID","Biotype":"1","BioName":"","PFid":"PID","BigURL":"{1}","Url":"{2}","Width":"{3}","Height":"{4}","Type":"{5}"}';
        //img
        $.each(imgArrObj, function (i, item) {
            var $this = $(item);
            mediaArr.push(template.format([cvNumber, $this.attr("data-src").replace(domain.imgUrl, ""), $this.attr("src").replace(domain.imgUrl, ""), $this.attr("data-width"), $this.attr("data-height"), 1]));
        });
        //video
        $.each(videoArrObj, function (i, item) {
            var $this = $(item),
                url = $this.attr("data-url").replace(domain.imgUrl, "");
            mediaArr.push(template.format([cvNumber, $this.attr("video_image_url").replace(domain.imgUrl, ""), $this.attr("data-url").replace(domain.imgUrl, ""), 0, 0, 2]));
        });
        console.log(mediaArr);
        return mediaArr;
    }
    //savecharpter
    biogEditor.on("#savecharpter", "touchend", function (e, ev) {
        var that = $(e.atarget || ev.self),
            id = that.attr("data-id");
        var cvNumber = getCurrentCV();
        if (cvNumber > 0) {
            var title = $("#biotitle").val().trim();
            if (/^\s*$/.test(title)) {
                app.alert('请填写标题');
                return false;
            }
            var gethtml = biogEditor.editor.getHtml();
            if (/^\s*$/.test(gethtml.trim())) {
                app.alert('请填写内容');
                return false;
            }
            if (!that.hasClass('not')) {
                var mdeiaJson =biogEditor.createMediaJson($("#biocontents"), cvNumber);
                $.ajax({
                    type: 'post',
                    url: appUrl('bioedit'),
                    beforeSend: function () {
                        that.addClass('not');
                    },
                    data: { cvNumber: cvNumber, contents: EmojiBM(gethtml), title: EmojiBM(title), mdeiaJson: '{"key":[' + mdeiaJson.toString() + ']}', id: id },
                    success: function (json) {
                        if (json.Result == 10000) {
                            var charpterdata = { id: json.Data || 0, isPublic: biogEditor.isPublic };
                            envObj.SaveLocals("charpterdata", JSON.stringify(charpterdata));
                            R.to('pageBiogSet');
                        }
                        that.removeClass('not');
                    }
                });
            }
        }

    });
    //预览  
    biogEditor.on("#preview", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("header-tag-active")) return false;
        $(self).addClass("header-tag-active").siblings("span").removeClass("header-tag-active");
        $(".exper-content").hide();
        $(".preview-editor").show();
        $("#previewContent").html(biogEditor.editor.getHtml());
        biogEditor.initPhoto = app.initPhoto(".preview-editor");
        biogEditor.iscroller = app.iscroll(".preview-editor");
    });
    //编辑
    biogEditor.on("#editor", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("header-tag-active")) return false;
        $(self).addClass("header-tag-active").siblings("span").removeClass("header-tag-active");
        $(".exper-content").show();
        $(".preview-editor").hide();
        biogEditor.iscroller = null;
    })

    //点击标题弹出标签
    $(document).on("focus", ".biogEditor-header textarea", function (e, ev) {
        if ($("#biogEditor-tag").hasClass("in")) return false;
        $("#biogEditor-tag").addClass("in");
    }).on("blur", ".biogEditor-header textarea", function () {
        $("#biogEditor-tag").removeClass("in");
    })

    //选择标签
    biogEditor.on("#biogEditor-tag li", "touchend", function (e, ev) {
        var self = ev.self,
			val = $(self).text();
        $(".biogEditor-header textarea").val(val);
    });

})(jQuery);
