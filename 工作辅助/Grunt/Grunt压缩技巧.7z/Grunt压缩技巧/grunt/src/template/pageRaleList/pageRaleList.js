﻿(function ($) {
    var raleList = pageRaleList;
    raleList.iscroller = null;
    raleList.onPageLoadInit = function () {

    }
    raleList.onPageLoad = function () {
        var prePageName = R.prePage.name;
        if (isNull(prePageName) || prePageName == "pageBiogSet") {
            $("#nodata").hide(); $("#insertList").show(); $("#hasData").show();
            raleList.charpterdata = eval("(" + envObj.GetLocals('charpterdata') + ")");
            var id = raleList.charpterdata.id || 0;
            raleList.getlist(id);

        } else {
            R.to(prePageName);
        }
    };
    //选择
    raleList.on(".btn-checkbox", "touchend", function (e, ev) {
        var that = ev.self;
        app.checkBox($(that));
    });
    //返回
    raleList.on("#route-back", "touchend", function (e, ev) {
        R.to('pageBiogSet');
    });

    raleList.getlist = function (id) {
        var cvNumber = getCurrentCV();
        if (cvNumber > 0) {
            $("#listUl").html('');
            $.ajax({
                type: 'post',
                url: appUrl('bioariclelist'),
                data: { cvNumber: cvNumber, id: id },
                success: function (json) {
                    json = eval("(" + json + ")");
                    console.log(json);
                    var sLen = json.selected.length,
                          nsLen = json.noselected.length;
                    if (sLen == 0 && nsLen == 0) {
                        $("#nodata").show(); $("#insertList").hide(); $("#hasData").hide();
                    } else {
                        if (sLen > 0) {
                            $("#listUl").append($("#listTemplate").render(json.selected));
                        }

                        if (nsLen > 0) {
                            $("#listUl").append($("#listTemplate").render(json.noselected));
                        }
                    }
                    app.iscroll("#page-raleList");
                }, error: function () {

                }
            });
        }
    }
    /*保存*/
    raleList.on("#insertList", "touchend", function (e, ev) {
        var that = $(ev.self);
        var cvNumber = getCurrentCV();
        if (cvNumber > 0) {
            var id = raleList.charpterdata.id || 0;
            if (id > 0) {
                var arr = [];
                var $lis = $("#listUl").find("li.table-view-cell").find("span.on").parent('li');
                len = $lis.length;
                if (len > 0) {
                    if (!that.hasClass('not')) {
                        var template = '{"CvNumber":"{0}","BioId":"{1}","MemoryId":"{2}"}';
                        $lis.each(function (i) {
                            arr.push(template.format([cvNumber, id, $(this).attr("data-mid")]));
                        });
                        console.log('{"key":[' + arr + ']}');
                        var list = '{"key":[' + arr + ']}';

                        $.ajax({
                            type: 'post',
                            url: appUrl('bioinsertmemory'),
                            beforeSend: function () {
                                that.addClass('not');
                            },
                            data: { cvNumber: cvNumber, id: id, list: list },
                            success: function (json) {
                                if (json.Result == 10000) {
                                    R.to('pageBiogSet');
                                } else {
                                    app.alert("失败");
                                }
                                that.removeClass('not');
                            }, error: function () {

                            }
                        });
                    }
                } else {
                    app.alert('没有选择任何记忆');
                }
            } else {
                R.to('pageBiogSet');
            }
        }
    });
})(jQuery);
