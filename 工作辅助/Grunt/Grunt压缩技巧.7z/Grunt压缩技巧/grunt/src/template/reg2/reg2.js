﻿(function ($) {

    reg2.on(".icon-eye", "touchend", function (e, ev) {
        var that = $(ev.self),
			val = that.prev("input").val(),
			h = that.hasClass("ico-active");
        if (h) {
            that.prev("input").attr("type", "password").val(val);
            that.removeClass("ico-active");
        } else {
            that.prev("input").attr("type", "text").val(val);
            that.addClass("ico-active");
        }
    });

    reg2.init = function () {
        var footerData = xzbTool.data.plat();
        if (!isNull(footerData.foot_left_title)) {
            $("#reg2leftStr").text(footerData.foot_left_title);
        }
        if (!isNull(footerData.foot_right_title)) {
            $("#reg2rightStr").text(footerData.foot_right_title);
        }
        /*用于判断 是否重新发送验证码*/
        reg2.isSendCode = {
            flag: false,
            mobile: ''
        }
    }
    reg2.onPageLoad = function () {
        console.log("reg2——onPageLoad");

        console.log("prePage");
        console.log(R.prePage);

        console.log("currPage");
        console.log(R.currPage);

        console.log(reg2.isSendCode);

        reg2.currentmobile = envObj.GetLocals("regmobile");//当前的手机号
        console.log("reg2.currentmobile=" + reg2.currentmobile);

        /*
         作用：触发开始倒计时
         要求：注册第一个页面进来，并且手机号和上次发送的手机号不一致，此时自动触发发送验证码
         */
        //if (R.prePage.name=="reg1"&&reg2.isSendCode.mobile != reg2.currentmobile) {
        //    console.log('倒计时开始');
        //    reg_countdownFunc(reg2.currentmobile);
        //}
        var prePageName = R.prePage.name;
        if (prePageName != "reg1") {
            if (prePageName != "") {
                if (prePageName == 'reg3') {
                    R.to('login');
                } else {
                    R.to(prePageName);
                }
            }
        } else {
            if (reg2.isSendCode.mobile != reg2.currentmobile) {
                console.log('倒计时开始');
                reg_countdownFunc(reg2.currentmobile);
            }
        }

    }

    //点击倒计时
    reg2.on("#timecount", "touchend", function (e, ev) {
        console.log('点击倒计时');
        resendClick({
            btnId: '#reg2_page #timecount',//验证码外层元素的id
            callback: function () {
                SendCode({//发送验证码
                    mobile: reg2.currentmobile
                });
            }
        });
    });

    //输入密码和验证码,点击注册
    reg2.on("#regBtn", "touchend", function (e, eo) {
        console.log('点击注册');
        var code = $("#reg_code").val().trim();

        var isValid = regex_data.IsPostCode.test(code);
        if (!isValid) {
            app.alert('校验码不正确，请重新输入');
            return false;
        }
        isValid = regex_data.IsValidByte.test($("#reg_pwd").val().trim());
        if (!isValid) {
            app.alert('密码长度:6-10位');
            return false;
        }

        //return;
        var that = $(e.target);
        if (isValid) {
            if (!that.hasClass('btn-disabled')) {
                CheckCode({
                    mobile: reg2.currentmobile,
                    code: code,
                    callback: checkCodeCallback,
                    bsFunc: disableRegbtn,
                    id: '#regBtn',
                    className: 'btn-disabled',
                    text: '注册'
                });
            }
        }

    });
    /*-------------------------------------------------------------------------------------------------------------------------------------------------*/

    //倒计时
    function reg_countdownFunc(mobile) {
        resendClick({
            btnId: '#reg2_page #timecount',//验证码外层元素的id
            callback: function () {
                SendCode({//发送验证码
                    mobile: mobile,
                    bsFunc: function () {
                        console.log("发送验证码before");
                        reg2.isSendCode.flag = true;
                        reg2.isSendCode.mobile = mobile;
                        console.log(reg2.isSendCode.mobile);
                    }
                });
            }
        });
    };

    //检验验证码callback
    function checkCodeCallback(json) {
        if (json.result == 10000) {
            console.log('验证码正确');
            reg();
        } else {
            console.log('验证码错误');
            app.alert(json.msg);
            ableRegbtn();//自定义注册第二步按钮
        }
    };

    //点击注册
    function reg() {
        var parameters = {//post参数
            pwd: $("#reg_pwd").val().trim(),
            mobile: envObj.GetLocals("regmobile").trim()
        };

        //注册Post数据
        $.ajax({
            type: "post",
            url: appUrl('reg'),
            data: parameters,
            success: function (json) {
                if (json.result == 10000) {
                    console.log(json);
                    ableRegbtn();//启用注册第二步按钮
                    envObj.SaveLocals("userdata", JSON.stringify({ hasname: 0, cvNumber: json.data.cvNumber, mobile: json.data.mobile }));
                    R.to('reg3');
                } else {
                    app.alert(json.msg);
                    ableRegbtn();//启用注册第二步按钮
                }
            }, error: function () {
                app.alert('error');
            }
        });
    }

    //启用注册第二步按钮
    function ableRegbtn() {
        $("#regBtn").removeClass('btn-disabled').text('注册');
    }
    //禁用注册第二步按钮
    function disableRegbtn() {
        $("#regBtn").addClass('btn-disabled').text('正在注册···');
    }
})(jQuery);