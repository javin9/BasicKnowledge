﻿(function ($) {
    var biogSets = pageBiogSet;
    biogSets.charpterdata = null;
    biogSets.onPageLoad = function () {
        var prePageName = R.prePage.name;
        if (isNull(prePageName) || prePageName == 'pageBiogEditor' || prePageName == 'pageRaleList') {
            biogSets.charpterdata = eval("(" + envObj.GetLocals('charpterdata') + ")");
            var bioSelected = envObj.GetLocals('bioSelected'), select = biogSets.charpterdata.isPublic;
            if (!isNull(bioSelected)) {
                select = parseInt(bioSelected) == 0 ? false : true;
            }
            var $viewcell = $("#ispublicUl li.table-view-cell");
            select ? $viewcell.eq(0).addClass('setting-active').siblings().removeClass('setting-active') : $viewcell.eq(1).addClass('setting-active').siblings().removeClass('setting-active');/*show hide*/
            $("#pullright").attr('data-id', biogSets.charpterdata.id);
        } else {
            R.to(prePageName);
        }
    };
    biogSets.on(".security .table-view-cell", "touchend", function (e, ev) {
        var that = $(ev.self);
        envObj.SaveLocals("bioSelected", that.attr("data-id"));
        that.addClass("setting-active").siblings().removeClass("setting-active");
    });

    /*完成*/
    biogSets.on("#pullright", "touchend", function (e, ev) {
        var that = $(ev.self),
            id = that.attr("data-id") || 0,
            cvNumber = getCurrentCV(),
            isPublic = parseInt($("#ispublicUl").find("li.setting-active").attr('data-id')) == 0 ? false : true;
        if (cvNumber > 0) {
            if (id > 0) {
                if (isPublic != biogSets.charpterdata.isPublic) {
                    if (!that.hasClass('not')) {
                        $.ajax({
                            type: 'post',
                            url: appUrl('chapterauthor'),
                            beforeSend: function () {
                                that.addClass('not');
                            },
                            data: { id: id, cvNumber: cvNumber, isPublic: isPublic },
                            success: function (json) {
                                R.to('pageBiog');
                                that.removeClass('not');
                            }, error: function () {
                                that.removeClass('not');
                            }
                        })
                    }
                } else {
                    R.to('pageBiog');
                }
            } else {
                R.to('pageBiog');
            }
        }
    });
    //添加记忆
    biogSets.on("#toarticlelist", "touchend", function (e, ev) {
        var that = $(ev.self);
        R.to("pageRaleList");
    });
    //
    biogSets.on("#setcback", "touchend", function (e, ev) {
        var that = $(ev.self);
        R.to("pageBiogEditor?id=" + $("#pullright").attr("data-id"));
    });
})(jQuery);