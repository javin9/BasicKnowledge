﻿(function () {
    var biogSum = pageBiogSumEditor;
    biogSum.iscroller = null;
    biogSum.initPhoto = null;
    biogSum.onPageLoadInit = function () {
       
    }
    biogSum.onPageLoad = function () {
        biogSum.initSet();
        var id = biogSum.getParam("id") || 0;
        if (parseInt(id) == 0) {
            biogSum.editor = new EditMobileClass(document.getElementById("sumedit"));
            biogSum.editor.init();
            EditMobileData.text.add(biogSum.editor);
        } else {
            biogSum.getsum();
        }
    };

    //预览
    biogSum.on("#preview", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("header-tag-active")) return false;
        $(self).addClass("header-tag-active").siblings("span").removeClass("header-tag-active");
        $(".exper-content").hide();
        $(".preview-editor").show();
        $("#previewSumContent").html(biogSum.editor.getHtml());
        biogSum.initPhoto = app.initPhoto(".preview-editor");
        biogSum.iscroller = app.iscroll(".preview-editor");
    });

    //编辑
    biogSum.on("#editor", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("header-tag-active")) return false;
        $(self).addClass("header-tag-active").siblings("span").removeClass("header-tag-active");
        $(".exper-content").show();
        $(".preview-editor").hide();
        biogSum.iscroller = null;
    })

    //查询编辑内容
    biogSum.getsum = function () {
        var cvNumber = getCurrentCV();
        if (cvNumber > 0) {
            $.ajax({
                type: 'post',
                url: appUrl('getsumedit'),
                data: { cvNumber: cvNumber },
                success: function (json) {
                    json = eval("(" + json + ")");

                    biogSum.editor = new EditMobileClass(document.getElementById("sumedit"), EmojiJM(json[0].FigureSummary));
                    biogSum.editor.init();
                }, error: function () {

                }
            });
        }
    };
    //生成媒体json
    biogSum.createMediaJson = function (parent, cvNumber) {
        var imgArrObj = parent.find("div.app-editor-img").find("img"),
              videoArrObj = parent.find("video"),
            mediaArr = [],
            template = '{"CvNumber":"{0}","BioID":"BID","Biotype":"0","BioName":"","PFid":"PID","BigURL":"{1}","Url":"{2}","Width":"{3}","Height":"{4}","Type":"{5}"}';
        //img
        $.each(imgArrObj, function (i, item) {
            var $this = $(item);
            mediaArr.push(template.format([cvNumber, $this.attr("data-src").replace(domain.imgUrl, ""), $this.attr("src").replace(domain.imgUrl, ""), $this.attr("data-width"), $this.attr("data-height"), 1]));
        });
        //video
        $.each(videoArrObj, function (i, item) {
            var $this = $(item),
                url = $this.attr("data-url").replace(domain.imgUrl, "");
            mediaArr.push(template.format([cvNumber, $this.attr("video_image_url").replace(domain.imgUrl, ""), $this.attr("data-url").replace(domain.imgUrl, ""), 0, 0, 2]));
        });
        console.log(mediaArr);
        return mediaArr;
    }
    //
    biogSum.on("#sumexperSave", "touchend", function (e, ev) {
        var that = $(ev.self);
        var cvNumber = getCurrentCV();
        if (cvNumber > 0) {
            var gethtml = biogSum.editor.getHtml();
            if (/^\s*$/.test(gethtml.trim())) {
                app.alert('请填写内容');
                return false;
            } else {
                if (!that.hasClass('not')) {
                    var mediaJson = biogSum.createMediaJson($("#sumcontents"),cvNumber);
                    $.ajax({
                        type: 'post',
                        url: appUrl('summaryedit'),
                        beforeSend: function () {
                            that.addClass('not');
                        },
                        data: { summary: EmojiBM(gethtml), cvNumber: cvNumber, mediaJson: '{"key":[' + mediaJson.toString() + ']}' },
                        success: function (json) {
                            console.log(json);
                            R.to('pageBiog');
                            that.removeClass('not');
                        }, error: function () {

                        }
                    });
                }
            }
        }
    });
    /*初始化*/
    biogSum.initSet = function () {
        var headerF = $("#sumheader  span").eq(0);
        if (!headerF.hasClass("header-tag-active")) {
            headerF.addClass('header-tag-active').siblings().removeClass('header-tag-active');
        }
        $("#previewSumContent,#sumcontents").text('');
        $(".exper-content").show();
    };
})(jQuery)
