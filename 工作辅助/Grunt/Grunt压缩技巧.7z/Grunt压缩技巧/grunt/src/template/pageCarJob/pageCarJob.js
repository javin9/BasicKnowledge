﻿; (function ($) {
    pageCarJob.onPageLoad = function () {
        pageCardHelper.setinfo('pageCar_position', 'job');
    }
    //保存
    pageCarJob.on('.pull-right', 'touchend', function (e, ev) {
        pageCardHelper.updateinfo('pageCar_position', 'job');
    });
})(jQuery);