﻿(function ($) {
    login.on("#loginPage .icon-eye", "touchend", function (e, ev) {
        var that = ev.self,
			val = $(that).prev("input").val(),
			h = $(that).hasClass("ico-active");
        if (h) {
            $(that).prev("input").attr("type", "password").val(val);
            $(that).removeClass("ico-active");
        } else {
            $(that).prev("input").attr("type", "text").val(val);
            $(that).addClass("ico-active");
        }
    });
    login.para = '';
    /*初始化*/
    login.init = function () {
        console.log(appBase);
        var footerData = xzbTool.data.plat()[0];//
        if (!isNull(footerData.foot_left_title)) {
            $("#loginleftStr").text(footerData.foot_left_title);
        }
        if (!isNull(footerData.foot_right_title)) {
            $("#loginrightStr").text(footerData.foot_right_title);
        }


    }
    login.onPageLoad = function () {//mobile
        var plat = R.info.global.platform,
             key = "CvNumber" + plat,
         isRegKey = "Regstate" + plat,
         result = $.getCookie(key),
         isReg =parseInt($.getCookie(isRegKey))||0;
        var prePageName = R.prePage.name;
        if (prePageName !== "reg1" || prePageName !== "pageBackPwd2") {
            login.para = R.getUrl().para;
            console.log(login.para);
        }

        var result = $.getCookie(key);
        if (!isNull(result)) {
            if (isReg!==0) {
                R.to("pageOur");
            } else {
                R.to("reg3");
            }
        } else {
            $("#loginPwd,#loginName").val('');
            login.currentmobile = login.getParam("mobile");
            $("#loginName").val(login.currentmobile);
        }
    }
    /*点击登录*/
    login.on("#loginId", "touchend", function (e, ev) {
        var name = $("#loginName").val().trim(),
            pwd = $("#loginPwd").val().trim(),
           that = $(ev.self);
        /*开始验证*/
        var isValid = regex_data.IsPhone.test(name);
        if (!isValid) {
            app.alert('请输入有效的手机号');
            return false;
        }

        isValid = regex_data.IsValidByte.test(pwd);
        if (!isValid) {
            app.alert('密码长度:6-10位');
            return false;
        }
        login.currentmobile = name;
        if (isValid) {
            if (!that.hasClass('btn-disabled'))
                console.log('btn-disabled');
            $.ajax({
                type: 'post',
                url: appUrl("login"),
                data: {
                    name: name,
                    pwd: pwd
                },
                beforeSend: function () {
                    that.addClass('btn-disabled').text('登录中···');
                },
                success: function (json) {
                    if (json.result == 10000) {
                        R.share.off();
                        console.log("登录成功");
                        console.log(json);
                        $("input").blur();
                        if (parseInt(json.data.regstate) == 0) {
                            envObj.SaveLocals("userdata", JSON.stringify(json.data));
                            if (!isNull(login.para.trim())) {
                                R.to("reg3?" + login.para.trim());
                            } else {
                                R.to("reg3");
                            }
                        } else {
                            //跳转到其他页面
                            appUser.set({ cvnumber: json.data.cvNumber, pid: R.info.global.platform }, function () {
                                if (!isNull(login.para.trim())) {
                                    var url = login.para.trim().replace('&', '?');
                                    console.log('login');
                                    console.log(url);
                                    R.to(url);
                                } else {
                                    R.to("pageOur");
                                }
                            });
                        };
                    } else {
                        app.alert(json.msg);
                    }
                    resetBtn(that);
                }, error: function (json) {
                    alert('error');
                }
            });
        }
    })
    /*登录跳转到注册页面*/
    login.on("#logintoreg", "touchend", function (e, ev) {
        console.log("登录跳转到注册页面__________" + login.currentmobile);
        R.to('reg1', '9', { mobile: login.currentmobile });
    });
    /*登录跳转到找回密码*/
    login.on("#logintopwd", "touchend", function (e, ev) {
        console.log("登录跳转到找回密码__________" + login.currentmobile || $("#loginName").val());
        R.to('pageBackPwd1', '9', { mobile: login.currentmobile || $("#loginName").val() });
    });
    function resetBtn(that) {
        that.removeClass('btn-disabled').text('登录');
    }

})(jQuery);