(function ($) {
    var thingSets = pageThingSet;
    var articleId = 0, code = "", privacy = 1;
    thingSets.onPageLoadInit = function () {

    }
    thingSets.onPageLoad = function () {
        articleId = thingSets.getParam('articleId');
        if (R.prePage.name != "pageThingTagSet") {
            code = thingSets.getParam('code');
            privacy = thingSets.getParam("privacy");
            if (code == "ok") {
                privacy = 3;
            }
            $('.security .table-view-cell').eq(privacy - 1).addClass("setting-active").siblings().removeClass("setting-active");
        };
    }
    thingSets.on(".security .table-view-cell", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("setting-active") || $(self).index() == 2) return false;
        $(self).addClass("setting-active").siblings().removeClass("setting-active");
    })
    //����
    thingSets.on("#ThingBack", "touchend", function () {
        R.to("pageThingEditor?Id=" + articleId);
    });
    //�������ֿɼ�
    thingSets.on("#pageThing", "touchend", function () {
        R.to("pageSelecter?id=" + articleId+"&articleType=3", "", "");
    });
    //���   getCurrentCV()
    thingSets.on(".pull-right", "touchend", function (e, ev) {
        var privacy = $(".security li[class*='setting-active']").index() + 1;
        console.log(articleId)
        ajaxTool.ajaxPost(appUrl("updateprivacy"), { articleId: articleId, articleType: 3, cvNumber: getCurrentCV(), privacy: privacy }, function (result) {
            console.log(result);
            if (result.result == 10000) {
                ThingLocData();
                R.to("pageThing", "", "");
                //alert("����ɹ�");
            }
        });
    });
    //��ǩ��ת
    thingSets.on("#tagSet", "touchend", function () {
        R.to("pageThingTagSet?id=" + articleId + "&privacy=" + privacy, "", "");
    })
})(jQuery);