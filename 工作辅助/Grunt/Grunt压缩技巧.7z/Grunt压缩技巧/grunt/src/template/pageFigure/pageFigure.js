(function ($) {
    var figure = pageFigure;
    figure.MyDB = {
        dbName: "pageFigure",
        tabNames: [{ name: 'pageFigure', id: 'cvnumber' }, { name: 'pageFigureCollet', id: 'cvnumber' }],
        db: null,
        url: '/figure/list',
        cvnumber: getCurrentCV(),
        load: function (data, callback) {
            var url = appUrl(this.url);
            IndexDB.LoadData(this.dbName, url, data, false, callback, figure.MyDB.db);
        },
        update: function (name, data, success) {
            if (figure.MyDB.db != null) {
                IndexDB.update(name, data, this.cvnumber, success, 0, figure.MyDB.db);
            } else {
                IndexDB.openDB(figure.MyDB.dbName, figure.MyDB.tabNames, function () {
                    figure.MyDB.db = IndexDB._pageDB.db;
                    //获取数据 
                    IndexDB.update(name, data, figure.MyDB.cvnumber, success, 0, figure.MyDB.db);
                }, 2);
            }

        }
        //我的收藏
        , loadColle: function (data, callback) {
            var url = appUrl('/figure/colle');
            IndexDB.LoadData('pageFigureCollet', url, data, false, callback);
        }
    };
    figure.iscroller = null;
    figure.loadingMore = false;
    figure.isRefresh = false;
    figure.swiper = null;
    figure.iscollect = false;
    figure.issearch = false;
    figure.ishave = false;
    figure.pageIndex = 1;
    figure.PageCount = 0;
    figure.searchval = '';
    figure.loadNew = true;

    figure.init = function () {
        //初始化搜索框
        app.searchInit("#figure-search");
        if (figure.iscroller) return false;
        figure.iscroller = app.iscroll("#page-figure");

        //下拉刷新和加载更多-------------前端使用
        figure.iscroller.on("scroll", function () {
            if (this.y >= 40 && !figure.isRefresh && !figure.issearch) {
                this.minScrollY = 40;
                $("#downPull").addClass("now");
                $("#downPull span").html("松开刷新");
            } else if (this.y > 0 && this.y < 40 && !figure.isRefresh && !figure.issearch) {
                $("#downPull span").html("下拉刷新");
                this.minScrollY = 0;
                $("#downPull").removeClass("now");
            }
        });

        //下拉刷新和加载更多预备调用 figure.issearch
        figure.iscroller.on("scrollEnd", function () {
            if (!figure.isRefresh) {
                if ($("#downPull").hasClass("now")) {
                    $("#downPull span").addClass("preloader");
                    figure.isRefresh = true;
                    //调用刷新函数
                    //更新缓存重新绑定
                    if (!figure.iscollect) {
                        log("更新人物");
                        figure.LoadM(0);
                    } else {
                        log("我的收藏");
                        figure.LoadMC(figure.MyDB.cvnumber);
                    }
                } else {
                    $("#downPull span").removeClass("preloader").html('&nbsp;');
                }
            }
            if (this.y == this.maxScrollY && !figure.loadingMore && !figure.iscollect) {
                $("#figure-more span").addClass("preloader");
                figure.loadingMore = true;
                //调用加载更多函数
                //直接请求 不走 缓存
                if (!figure.iscollect && !figure.issearch) {
                    var starcv = $("#figurelistid li:last-child").attr("data-cv"); //获取最后一个人的cvNumber
                    figure.LoadM(starcv);
                    //console.log("人物页面加载更多");
                }
                //搜索加载更多
                if (figure.issearch && !figure.iscollect) {
                    if (figure.pageIndex < figure.PageCount) { //当前页不是最后一页
                        figure.pageIndex++; //下一页 index
                        //console.log("搜索 加载更多");
                        var $that = $("#figure-search"), searchval = $("#figure_search").val();
                        figure.search(searchval, figure.searchval, figure.pageIndex, figure.searchM);
                    } else {
                        $("#figurelistid").append('<div class="noData">没有更多东西了..</div>');
                        //figure.loadingMore = false;
                        $("#figure-more span").removeClass("preloader").html("&nbsp;");
                        $("#figure-more").removeClass("now");
                    }
                }
            }
        });

        //回车事件 搜索
        $("#figure-search-form").submit(function () {
            figure.pageIndex = 1;
            figure.PageCount = 0;
            figure.issearch = true;
            var $that = $("#figure-search"), searchval = $("#figure_search").val();
            figure.search(searchval, figure.searchval, figure.pageIndex, figure.searchM);
            return false;
        })

        appUser.get(figure.MyDB.cvnumber, function (result) {
            figure.getdata(figure.bindNew, figure.MyDB.cvnumber);
        }, function (msg) {
            log(msg);
        });

    }

    figure.onPageLoad = function () {
        //更改 db
        if (R.prePage.name == "pageSelecter") {
            //隐藏按钮
            figure.searchval = pubFigure.getFigureSearchOptions();
            if (figure.searchval != '') {
                $("#figure_sx").hide();
                $("#figure_alld").show();
                $("#figure-banner").hide(); //隐藏轮播图
                $("#figurelistid").html('<div class="noData">正在加载请稍后...</div>');//清空内容
                figure.pageIndex = 1;
                figure.PageCount = 0;
                figure.issearch = true;
                var $that = $("#figure-search"), searchval = $("#figure_search").val();
                figure.search(searchval, figure.searchval, figure.pageIndex, figure.searchM);
            }
        } else {
            if (figure.ishave && !figure.issearch && !figure.iscollect) {
                $("#figure_sx").show();
                $("#figure_alld").hide();
                $("#figure-banner").show(); //显示轮播图
                pubFigure.removeFigureSearchOptions();
            } else {
                $("#figure-banner").hide(); //隐藏轮播图
            }
        }
    }

    //第一次进入刷新一次
    figure.onPageLoadInit = function () {
        if (figure.loadNew) {
            figure.LoadM(0);
            figure.loadNew = false;
        }
    }
    //加载列表数据 先从本地取 没有 去加载 再从本地取出
    figure.getdata = function (success, cvnumber) {
        if (figure.MyDB.db != null) {
            //获取数据 
            IndexDB.Select(figure.MyDB.dbName, cvnumber, function (result) {
                if (typeof result != 'object') {
                    result = eval("(" + result + ")");
                }
                if (result != undefined) {
                    success(result);
                } else {
                    figure.MyDB.load({ startcv: 0, cvnumber: cvnumber, pid: 0 }, function () {
                        figure.loadNew = false;
                        figure.getdata(success, cvnumber);
                    })
                }
            }, figure.MyDB.db);
        } else {
            IndexDB.openDB(figure.MyDB.dbName, figure.MyDB.tabNames, function () {
                figure.MyDB.db = IndexDB._pageDB.db;
                //获取数据 
                IndexDB.Select(figure.MyDB.dbName, cvnumber, function (result) {
                    if (typeof result != 'object') {
                        result = eval("(" + result + ")");
                    }
                    if (result != undefined) {
                        success(result);
                    } else {
                        figure.MyDB.load({ startcv: 0, cvnumber: cvnumber, pid: 0 }, function () {
                            figure.loadNew = false;
                            figure.getdata(success, cvnumber);
                        })
                    }
                });
            }, 2);
        }
    }

    //更新任务列表或者获取更多人物列表数据
    figure.LoadM = function (startcv) {
        var url = appUrl(figure.MyDB.url);
        $.ajax({
            url: url,
            data: { startcv: startcv, cvnumber: figure.MyDB.cvnumber, pid: 0 },
            type: "Get",
            dataType: 'json',
            success: function (result) {
                var json = result
                if (json.result == 10000) {
                    if (startcv == 0) {//下拉刷新 //更新裤 重新绑
                        figure.MyDB.update(figure.MyDB.dbName, json.data, figure.bindNew);
                    } else {//滚动到底部 加载更多
                        if (json.data.list.length > 0) {
                            //console.log("加载更多");
                            $("#figurelistid").append($("#FigureListTemplate").render(json.data));
                            figure.iscroller.refresh();
                            figure.loadingMore = false;
                            $("#figure-more span").removeClass("preloader").html("&nbsp;");
                            $("#figure-more").removeClass("now");
                        } else {
                            figure.loadingMore = false;
                            $("#figure-more span").removeClass("preloader").html("&nbsp;");
                            $("#figure-more").removeClass("now");
                        }
                    }
                }
            },
            error: function (er) {
                console.log("服务器获取失败");
            }
        });
    };

    //刷新我的收藏列表
    figure.LoadMC = function (cvnumber) {
        var url = appUrl('/figure/colle');
        $.ajax({
            url: url,
            data: { cvnumber: cvnumber, pid: 0 },
            type: "Get",
            dataType: 'json',
            success: function (result) {
                //console.log(result);
                var json = result
                if (json.result == 10000) {
                    figure.MyDB.update("pageFigureCollet", json.data, figure.bindColl);
                }
            },
            error: function (er) {
                console.log("服务器获取失败");
            }
        });
    };

    //跟新列表后 重置一些东西
    figure.bindNew = function (data) {
        if (typeof data != 'object') {
            data = eval("(" + data + ")");
        }
        if (data.view.length > 0) {
            figure.ishave = true;
            $("#figure-banner").show();
            $("#figure-banner .swiper-wrapper").html($("#viewTemplate").render(data));
            //轮播图figure_banner
            if (figure.swiper) { figure.swiper.destroy() }
            figure.swiper = new Swiper('#figure-banner', {
                lazyLoading: true,
                pagination: '#figure-banner .swiper-pagination',
                paginationClickable: true,
                autoplay: 2500,
                loop: true
            });
        } else {
            figure.ishave = false;
        }
        if (data.list.length > 0) {
            $("#figurelistid").html($("#FigureListTemplate").render(data));
        } else {
            $("#figurelistid").html('<div class="noData">暂时还没有人哦。赶紧成为第一个吧...</div>');
        }
        figure.iscroller.refresh();
        figure.isRefresh = false;
        $("#downPull span").html("下拉刷新");
        $("#downPull").removeClass("now");
    };

    //进入我的收藏后 替换一些东西
    figure.bindColl = function (data) {
        //console.log(data);
        if (data.list.length > 0) {
            $("#figurelistid").html($("#FigureListTemplate").render(data));
        } else {
            $("#figurelistid").html('<div class="noData">你还没有收藏过人呢,赶紧去收藏一个吧...</div>');
        }
        figure.iscroller.refresh();
        figure.isRefresh = false;
        $("#downPull span").html("下拉刷新");
        $("#downPull").removeClass("now");
    };

    //获取我的收藏列表
    figure.getcoll = function (cvnumber, success) {
        if (figure.MyDB.db != null) {
            //获取数据 
            IndexDB.Select('pageFigureCollet', cvnumber, function (result) {
                if (typeof result != 'object') {
                    result = eval("(" + result + ")");
                }
                if (result != undefined) {
                    success(result);
                } else {
                    figure.MyDB.loadColle({ cvnumber: cvnumber, pid: 0 }, function () {
                        figure.getcoll(cvnumber, success);
                    })
                }
            }, figure.MyDB.db);
        } else {
            IndexDB.openDB(figure.MyDB.dbName, figure.MyDB.tabNames, function () {
                figure.MyDB.db = IndexDB._pageDB.db;
                //获取数据 
                IndexDB.Select('pageFigureCollet', cvnumber, function (result) {
                    if (typeof result != 'object') {
                        result = eval("(" + result + ")");
                    }
                    if (result != undefined) {
                        success(result);
                    } else {
                        figure.MyDB.loadColle({ cvnumber: cvnumber, pid: 0 }, function () {
                            figure.getcoll(cvnumber, success);
                        })
                    }
                });
            }, 2);
        }
    };

    //按条件搜索
    figure.search = function (searchval, Identityval, pageIndex, success) {
        var url = appUrl('/figure/search');
        $.ajax({
            url: url,
            data: { uasTitle: searchval, uasValue: Identityval, pid: 0, pageIndex: pageIndex },
            type: "Get",
            dataType: 'json',
            success: function (result) {
                var json = result
                if (json.result == 10000) {
                    var data = json.data;
                    if (figure.pageIndex == 1) {
                        success(data, true);
                    } else {
                        success(data, false);
                    }
                } else {

                }
            },
            error: function (er) {
                //figure.getdata(figure.bindNew, figure.MyDB.cvnumber);
                console.log("服务器获取失败");
            }
        });
    };

    //搜索回调
    figure.searchM = function (data, type) {
        if (type) {
            if (data.list.length > 0) {
                $("#figure-banner").hide(); //隐藏轮播图
                $("#figurelistid").html($("#FigureListTemplate").render(data));
            } else {
                $("#figure-banner").hide(); //隐藏轮播图
                $("#figurelistid").html('<div class="noData">没有符合条件的人哦.换一个条件试一下吧...</div>');
            }
        } else {
            if (data.list.length > 0) {
                $("#figurelistid").append($("#FigureListTemplate").render(data));
                figure.loadingMore = false;
                $("#figure-more span").removeClass("preloader").html("&nbsp;");
                $("#figure-more").removeClass("now");
            } else {
                figure.loadingMore = false;
                $("#figure-more span").removeClass("preloader").html("&nbsp;");
                $("#figure-more").removeClass("now");
            }
        }
        figure.iscroller.refresh();
        figure.pageIndex = data.pageTb[0].PageIndex;
        figure.PageCount = data.pageTb[0].PageCount;
    }

    //----------------------------事件开始-------------
    //点击我的收藏
    figure.on("#mycoll", "touchend", function () {
        $("#mycolldiv").show();//显示我的收藏头
        $("#figure-banner").hide(); //隐藏轮播图
        $("#figure-search .input-search").hide(); //隐藏搜索框
        //加载收藏数据
        figure.getcoll(figure.MyDB.cvnumber, figure.bindColl);
        figure.iscroller.scrollTo(0, 0, 0, 0);
        figure.iscollect = true;
    });

    //我的收藏-点击返回
    figure.on("#backfigure", "touchend", function () {
        figure.MyDB.db = null;
        $("#mycolldiv").hide();//隐藏我的收藏头
        //$("#figure-banner").show(); //显示轮播图
        $("#figure-search .input-search").show(); //显示搜索框
        //加载列表数据
        figure.getdata(figure.bindNew, figure.MyDB.cvnumber);
        figure.iscollect = false;
    });

    //点击搜索框
    figure.on(".figure", "touchend", function () { $("input[type=search]").blur(); });

    //筛选返回全部
    figure.on("#figure_alld", "touchend", function (e) {
        $("#figure_sx").show();
        $("#figure_alld").hide();
        pubFigure.removeFigureSearchOptions();
        figure.getdata(figure.bindNew, figure.MyDB.cvnumber);
        figure.issearch = false;
        figure.loadingMore = false;
    });


    //搜索取消
    figure.on("#figure-search .search-cancel", "touchend", function () {
        //加载数据
        figure.getdata(figure.bindNew, figure.MyDB.cvnumber);
        figure.issearch = false;
        figure.loadingMore = false;
    })

    //时间格式转换
    $.views.helpers({
        chtml: function (str) {
            if (str != null) {
                var str1 = dropHtml(str);
                return EmojiJM(str1);
            } else {
                return str;
            }

        }
    });

})(jQuery);


