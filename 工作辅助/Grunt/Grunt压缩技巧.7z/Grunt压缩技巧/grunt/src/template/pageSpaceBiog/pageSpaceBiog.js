﻿(function ($) {
    var spaceBiog = pageSpaceBiog;
    spaceBiog.scroller = null;

    spaceBiog.onPageLoadInit = function () {
       helper.load();
    }

    var helper = {
        params: {
            cvNumber: parseInt(R.getPara('cv', 'cv')),
            currentCvNumber: getCurrentCV()
        },
        load: function () {
            ajaxTool.ajaxGet(appUrl('user/getbio'), { cvnumber: helper.params.cvNumber }, function (result) {
                if (result.result == 10000) {
                    helper.bind(result.data);
                } else {
                    app.alert('读取用户传记信息失败，请刷新页面重试');
                }
            });
            //检测是否收藏过
            pubFigure.iscollect(helper.params.currentCvNumber, helper.params.cvNumber, function (iscollect) {
                if (iscollect) {
                    $('#space-like').addClass("liked-space");
                    $('#space-biog-like').addClass("liked-space");
                } else {
                    $('#space-like').removeClass("liked-space");
                    $('#space-biog-like').removeClass("liked-space");
                }
            });
        },
        getjson: function (data,callback) {
            appUser.get(helper.params.cvNumber, function (user) {
                //先绑定用户的联系方式信息
                helper.bindUser(user);
                //
                var json = {
                    username: user.name,
                    headphoto: user.headphoto,
                    titles: [{ identity_title: user.identity_title }],
                    summary: '',
                    chapters: [],
                };
                if (user.school_friend) {
                    log('校友')
                    //如果是校友，添加公司，职位信息
                    json.titles.push({ identity_title: (user.company||'') + ' ' + (user.job||'') });
                }
                //概述
                json.summary = data.summary.length ? data.summary[0].summary : '';
                var chapters = [];
                for (var i = 0; i < data.chapters.length; i++) {
                    var c = {
                        title: data.chapters[i].title,
                        contents: data.chapters[i].contents
                    }
                    //得到相应的记忆集合
                    var memeory = $.grep(data.memories, function (item, m) {
                        return item.chapterid == data.chapters[i].id;
                    });
                    //记忆列表转换
                    var cMemories = [];
                    for (var j = 0; j < memeory.length; j++) {
                        cMemories.push({
                            starttime: memeory[j].starttime,
                            starttype: memeory[j].starttype,
                            endtime: memeory[j].endtime,
                            endtype: memeory[j].endtype,
                            title: memeory[j].title
                        });
                    }
                    c.memories = cMemories;
                    chapters.push(c);
                }
                json.chapters = chapters;
                callback(json);
            });
        },
        bindUser: function (user) {
            var html = jsRenderBinding({
                page: 'pageSpaceBio.pageSpaceBio_template_userContact',
                json: user
            });
            $('#pageSpaceBio_userContact').html(html);
            $('#pageSpaceBack_userName').append(user.name);
            var model = {
                cvnumber: user.cvnumber,
                name: user.name,
                title: user.identity_title,
                organization: user.company,
                mobile: user.mobile,
                email: user.email,
            }
            $.ajax({
                url: domain.getQrCode,
                type: "POST",
                data: model,
                success: function (result) {
                    if (result.result == 10000) {
                        document.getElementById('pageSpaceBio_qrCode').src = result.data.src;
                    }
                }
            });
        },
        bind: function (data) {
            this.getjson(data, function (j) {
                console.log(j);
                //pageSpaceBio_template_mainContent
                var html = jsRenderBinding({
                    page: 'pageSpaceBio.pageSpaceBio_template_mainContent',
                    json: j
                });
                $('#pageSpaceBiog_mainContent').html(html);
                if (!spaceBiog.scroller) spaceBiog.scroller = app.iscroll("#page-spaceBiog");
                spaceBiog.initPhoto = app.initPhoto(".space-biog-car");
            });
        }
    };





    //收藏
    spaceBiog.on("#space-biog-like", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("liked-space")) {
            $(self).removeClass("liked-space");
            pubFigure.collect(helper.params.currentCvNumber, helper.params.cvNumber, false, function () {
                $(self).removeClass("liked-space");
                $('#space-like').removeClass('liked-space');
            });
        } else {
            pubFigure.collect(helper.params.currentCvNumber, helper.params.cvNumber, true, function () {
                $(self).addClass("liked-space");
                $('#space-like').addClass('liked-space');
            });
        }
    })

    //查看联系方式
    spaceBiog.on("#space-biog-phone", "touchend", function (e, ev) {
        $(".modal-over-back").addClass("modal-overlay-visible");
        $(".space-contact").addClass("in");
    })

    //关闭联系方式
    spaceBiog.on(".space-contact-btn", "touchend", function (e, ev) {
        $(".modal-over-back").removeClass("modal-overlay-visible");
        $(".space-contact").removeClass("in");
    })

})(jQuery)
