(function(e) {
    typeof define == "function" && define.amd ? define(["jquery"], e) : e(jQuery)
})(function(e) {
    function t(e) {
        this.x = e.offset().left,
        this.y = e.offset().top,
        this.width = e.width(),
        this.height = e.height(),
        this.left = e.position().left,
        this.top = e.position().top
    }
    var n = "mousedown",
    r = "mousemove",
    i = "mouseup";
    "ontouchend" in document && (n = "touchstart", r = "touchmove", i = "touchend"),
    e.CanvasCrop = function(s) {
        var o = e.extend({},
        {
            limitOver: 1,
            isMoveOver: !1
        },
        s),
        u = e(s.cropBox) || e(".cropBox"),
        a = 0,
        f = 1,
		initScale = 1,
		START_X,
		START_Y,
        l = 1,
        c = new t(u),
        h = s.thumbBox ? e(s.thumbBox) : u.find(".thumbBox"),
        p = new t(h),
        d = s.imgSrc,
        v = new Image,
        m = {},
        g = {
            dx: p.x - c.x,
            dy: p.y - c.y
        },
        y,
        b,
        w = {
            left: 0,
            top: 0
        },
        E = function() {
            if (!d) throw "image src is not defined";
            S(),
            v.src = d;
            //u.off(".CropDown").on(n + ".CropDown", N)
			
        },
        S = function() {
            v.onload = function() {
                y = document.createElement("canvas"),
                x(),
                getScale(),
                y.id = "visbleCanvas",
                y.style.position = "absolute",
                b = y.getContext("2d"),
                drawImage(),
                setPosition({
                    x: (c.width - y.width) / 2,
                    y: (c.height - y.height) / 2
                }),
                u.find("#visbleCanvas").remove(),
                u.prepend(y),
                v.onload = v.onerror = null
				START_X = (c.width - y.width) / 2;
				START_Y = (c.height - y.height) / 2;
				var mc = new Hammer(document.querySelector(s.cropBox));
				mc.add(new Hammer.Pan({ threshold: 0, pointers: 0 }));
				mc.add(new Hammer.Pinch({ threshold: 0 })).recognizeWith([mc.get('pan'), mc.get('rotate')]);
				mc.off("panstart panmove panend").on("panstart panmove panend", onPan);//拖动事件
				mc.off("pinchstart pinchmove pinchend").on("pinchstart pinchmove pinchend", onPinch);//放大缩小事件
				var SE = new t(e(y));
				function onPan(ev){
					var imgDis = {
						x: START_X + ev.deltaX,
						y: START_Y + ev.deltaY
					}
					setPosition(imgDis);
					if(ev.type == "panend"){
						START_X = w.left;	
						START_Y = w.top;
					}
					
				}
				var isScale=1;
				function onPinch(ev) {
					if(ev.type == 'pinchstart') {
						isScale = initScale || 1;
					}
					if(ev.type =="pinchmove"){
						k.scale(isScale*ev.scale);
					}
					if(ev.type == "pinchend"){
						initScale= isScale*ev.scale;
					}
				}
            },
            v.onerror = function() {
                alert("下载图片出错")
            }
        },
        x = function() {
            var e = v.width,
            t = v.height,
            n = e / t;
            n < 1 ? o.limitOver == 1 ? t = c.height: o.limitOver == 2 && (e = p.width, t = e / n) : o.limitOver == 1 ? (e = c.width, t = e / n) : o.limitOver == 2 && (t = p.height),
            l = t / v.height
        },
        T = function() {
            var e = u.find(".thumbBox"),
            t = "<div class='cropPoint' style='left:-4px;top:-4px;' id='leftTopPoint'></div><div class='cropPoint' style='right:-4px;top:-4px;' id='rightTopPoint'></div><div class='cropPoint' style='left:-4px;bottom:-4px;' id='leftBottomPoint'></div><div class='cropPoint' style='right:-4px;bottom:-4px;' id='rightBottomPoint'></div>";
            e.append(t)
        },
        N = function(n) {
            n.preventDefault();
            if (!y) return ! 1;
            var s = new t(e(y)),
            o = C(n),
            u = {
                x: o.pageX,
                y: o.pageY
            };
            this.onselectstart = function() {
                return ! 1
            },
            e(document).on(r + ".CropMove",
            function(e) {
                e.preventDefault();
                var t = C(e),
                n = t.pageX - u.x,
                r = t.pageY - u.y;
                imgDis = {
                    x: s.left + n,
                    y: s.top + r
                },
                setPosition(imgDis)
				console.log(s);
            }),
            e(document).on(i + ".CropLeave",
            function(t) {
                t.preventDefault(),
                e(document).off(".CropMove").off(".CropLeave")
            })
        },
        C = function(e) {
            return {
                pageX: hasTouch() ? e.originalEvent.touches[0].pageX: e.pageX,
                pageY: hasTouch() ? e.originalEvent.touches[0].pageY: e.pageY
            }
        };
        innerRotate = function() {
            var e = y.width,
            t = y.height,
            n = Math.PI * a / 180,
            r = Math.round(Math.cos(n) * 1e3) / 1e3,
            i = Math.round(Math.sin(n) * 1e3) / 1e3;
            y.height = Math.abs(r * t) + Math.abs(i * e),
            y.width = Math.abs(r * e) + Math.abs(i * t),
            n <= Math.PI / 2 ? b.translate(i * t, 0) : n <= Math.PI ? b.translate(y.width, -r * t) : n <= 1.5 * Math.PI ? b.translate( - r * e, y.height) : b.translate(0, -i * e),
            b.rotate(n)
        },
        hasTouch = function() {
            return "ontouchend" in document
        },
        getScale = function() {
            m.w = y.width = v.width * l * f,
            m.h = y.height = v.height * l * f
        },
        drawImage = function() {
            b.clearRect(0, 0, y.width, y.height),
            b.drawImage(v, 0, 0, m.w, m.h)
        },
        getPosition = function(e, t) {
            return {
                x: w.left + (e - y.width) / 2,
                y: w.top + (t - y.height) / 2
            }
        },
        setPosition = function(t) {
            var n = {
                left: p.x - c.x,
                top: p.y - c.y,
                right: p.x - c.x + p.width,
                bottom: p.y - c.y + p.height
            };
            o.isMoveOver && (n.left - t.x < 0 ? t.x = n.left: n.right > t.x + y.width && (t.x = n.right - y.width), n.top - t.y < 0 ? t.y = n.top: n.bottom > t.y + y.height && (t.y = n.bottom - y.height)),
            e(y).css({
                left: t.x,
                top: t.y
            }),
            w = {
                left: t.x,
                top: t.y
            },
            g = {
                dx: t.x - n.left,
                dy: t.y - n.top
            }
        },
        canvasTransform = function(e) {
            if (!y) return ! 1;
            var t = y.width,
            n = y.height;
            f = typeof e.ratio == "undefined" ? f: e.ratio,
            a = typeof e.rot == "undefined" ? a: e.rot,
            b.save(),
            getScale(),
            innerRotate(),
            drawImage(),
            b.restore();
            var r = getPosition(t, n);
            setPosition(r)
        };
		
		
        var k = {
            rotate: function(e) {
                canvasTransform({
                    rot: e
                })
            },
            scale: function(e) {
                canvasTransform({
                    ratio: e
                })
            },
            getDataURL: function() {
                var e = p.width,
                t = p.height,
                n = document.createElement("canvas"),
                r = n.getContext("2d");
                return n.width = e,
                n.height = t,
                r.drawImage(y, g.dx, g.dy, y.width, y.height),
                n.toDataURL("image/png")
            },
            getSourceURL: function() {
                return v.src
            }
        };
        return E(),
        k;
    }
});