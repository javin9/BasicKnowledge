(function ($) {
    var pImg = pageCarUserImg, img = new Image(), CanvasCrop, rot = 0, ratio = 1;
    pImg.uploadSuccess = function (url) {
        pageCardHelper.updatephoto(url);
    }
    //初始化方法
    function initImg(src) {
        img.src = src || document.querySelector("#canvas_img").src;
        img.onload = function (e) {
            CanvasCrop = $.CanvasCrop({
                cropBox: "#imageBox",
                imgSrc: img.src,
                limitOver: 2
            });
        }
        //左旋转
    }
    pImg.on(".rotate-left", "touchend", function (e, ev) {
        rot += 90;
        rot = rot > 360 ? 90 : rot;
        CanvasCrop.rotate(rot);
        //pImg.isUploadPhoto = true;
    })
    //右旋转
    pImg.on(".rotate-right", "touchend", function (e, ev) {
        //$(document).on("touchend",".rotate-right",function(e){
        rot -= 90;
        rot = rot < 0 ? 270 : rot;
        CanvasCrop.rotate(rot);
        //pImg.isUploadPhoto = true;
    })
	//保存头像
    pImg.on("#userImg-save", "touchend", function (e, ev) {
        if (!pImg.isUploadPhoto) {
            //没有上传新的
            R.to('pageCarList', 10);
            return;
        }
        var base64 = CanvasCrop.getDataURL();
        var json = getUploadJson(base64);//获取要上传的json
        $.ajax({
            type: "POST",
            url: domain.uploadBase64,
            data: JSON.stringify(json),
            contentType: "application/json",
            success: function (result) {
                var newUrl = result.data[0];
                pImg.uploadSuccess(newUrl);//回调，在主文件里面
            },
            error: function (error) {
                log(error);
            }
        });

    });


	
    //页面加载
	pImg.onPageLoad = function () {
	    var src = $('#pageCarList_list_photo').attr('src');
	    initImg(src);
	    pImg.isUploadPhoto = false;
	}
    //上传图片
	pImg.bioUploadFile = function (that) {
	    that = $(that);
	    //console.log(that);
	    var files = that[0].files
	    if (files.length > 0) {
	        var imgContent = files[0];
	        var settingsTypesArr = that.data("type").split(",");//设置的图片格式
	        var imgType = imgContent.name.split(".").pop().toLowerCase();//上传的图片格式
	        if (imgContent.size > parseInt(that.data("size")) * 1024 * 1024 || $.inArray(imgType, settingsTypesArr) < 0) {
	            app.alert("图片格式不正确或图片过大");
	            return false;
	        } else {
	            var imgReader = new FileReader();
	            imgReader.readAsDataURL(imgContent);
	            imgReader.onload = function (e) {
	                var img = $('#canvas_img');
	                img.attr('src', this.result);
	                initImg();
	            }
	            pImg.isUploadPhoto = true;
	        }
	    }
	    else {
	        //myApp.alert("上传失败");
	    }
	}
    //获取上传参数
	function getUploadJson(base64) {
	    var type = '.' + base64.split(';')[0].split('/')[1];
	    var imageJsonList = [{
	        "client_id": "",
	        "annex_name": $.Guid() + type,
	        "datetime": "",
	        "make": "",
	        "make_mode": "",
	        "gps": "",
	        "exif": "",
	        "base64": "",
	        "amends": [
                {
                    "client_id": "",
                    "base64": base64,
                    "type": type,
                    "width": "200",
                    "height": "205"
                }
	        ],
	        "previews": []
	    }];
	    return imageJsonList;
	}
	
})(jQuery);
