(function ($) {
    var exper = pageExper;
    exper.MyDB = {
        dbName: "pageExper",
        tabNames: [{ name: 'pageExper', id: 'cvnumber' }],
        db: null,
        url: '/experlist/list',
        cvnumber: getCurrentCV(),
        load: function (data, callback) {
            var url = appUrl(this.url);
            IndexDB.LoadData(this.dbName, url, data, false, callback, exper.MyDB.db);
        },
        update: function (name, data, success) {
            if (exper.MyDB.db != null) {
                IndexDB.update(name, data, this.cvnumber, success, 0, this.db);
            } else {
                IndexDB.openDB(exper.MyDB.dbName, exper.MyDB.tabNames, function () {
                    exper.MyDB.db = IndexDB._pageDB.db;
                    IndexDB.update(name, data, exper.MyDB.cvnumber, success, 0, exper.MyDB.db);
                }, 2);
            }

        }
    }
    exper.iscroller = null;
    exper.loadingMore = false;
    exper.swiper = null;
    exper.isRefresh = false;
    exper.pageIndex = 1;
    exper.key = "experischange_jy";
    exper.issearch = false;
    exper.PageCount = 0;
    exper.loadNew = true;

    //经历 添加 编辑 修改 评论 同行 只要是操作数据了 操作完成后 调用 
    //localStorage.setItem("experischange_jy", "have");
    //localStorage.setItem("experischange_our", "have");

    exper.init = function () {
        //初始化搜索框
        app.searchInit("#exper-search");
        exper.iscroller = app.iscroll("#page-exper");

        //下拉刷新和加载更多-------------前端使用
        exper.iscroller.on("scroll", function () {
            if (this.y >= 40 && !exper.isRefresh && !exper.issearch) {
                $("#exper-downPull span").html("松开刷新");
                this.minScrollY = 40;
                $("#exper-downPull").addClass("now");
            } else if (this.y > 0 && this.y < 40 && !exper.isRefresh && !exper.issearch) {
                $("#exper-downPull span").html("下拉刷新");
                this.minScrollY = 0;
                $("#exper-downPull").removeClass("now");
            }
        });
        //下拉刷新和加载更多预备调用
        exper.iscroller.on("scrollEnd", function () {
            if (!exper.isRefresh) {
                if ($("#exper-downPull").hasClass("now")) {
                    $("#exper-downPull span").addClass("preloader");
                    exper.isRefresh = true;
                    //调用刷新函数
                    exper.LoadM(0, exper.MyDB.cvnumber);
                } else {
                    $("#exper-downPull span").removeClass("preloader").html('&nbsp;');
                }
            }
            if (this.y == this.maxScrollY && !exper.loadingMore) {
                $("#exper-more span").addClass("preloader");
                exper.loadingMore = true;
                //调用加载更多函数
                if (!exper.issearch) {//列表加载更多
                    var $that = $("#experlistid .exper-content-list-ul:last-child .exper-content-list-li:last-child");
                    var startid = $that.attr("data-id"), cv = $that.attr("data-cv");
                    if (startid) {
                        exper.LoadM(startid, cv);
                    } else {
                        exper.loadingMore = false;
                        $("#exper-more span").removeClass("preloader").html("&nbsp;");
                        $("#exper-more").removeClass("now");
                    }
                    // console.log("记忆页面加载更多");
                } else {//搜索加载更多
                    if (exper.pageIndex < exper.PageCount) {
                        exper.pageIndex++;
                        var $that = $("#exper-search"), searchval = $("#exper_search").val();
                        if ($that.hasClass("search-active") && !$that.find(".icon-clear").hasClass("hidden")) {
                            exper.search(searchval, exper.pageIndex, exper.searchM);
                        } else {
                            $("#exper-more span").removeClass("preloader").html("&nbsp;");
                            $("#exper-more").removeClass("now");
                        }
                    } else {
                        //exper.loadingMore = false;
                        $("#experlistid").append('<div class="noData">没有更多的东西了....</div>');
                        $("#exper-more span").removeClass("preloader").html("&nbsp;");
                        $("#exper-more").removeClass("now");
                    }
                }
            }

        });
        //搜索
        $("#exper-search-form").submit(function () {
            exper.pageIndex = 1;
            exper.PageCount = 0;
            exper.issearch = true;
            var $that = $("#exper-search"), searchval = $("#exper_search").val();
            if ($that.hasClass("search-active") && !$that.find(".icon-clear").hasClass("hidden")) {
                //console.log(searchval);
                exper.search(searchval, exper.pageIndex, exper.searchM);
            }
            return false;
        });

        appUser.get(exper.MyDB.cvnumber, function (result) {
            exper.getdata(exper.bindNew, exper.MyDB.cvnumber);
        }, function (msg) {
            log(msg);
        });
    }

    exper.onPageLoad = function () {
        var isc = localStorage.getItem(exper.key);
        if (isc == "have") {//有变化
            exper.LoadM(0, exper.MyDB.cvnumber);
        }
        //判断上一页是什么页面
        if (R.prePage.name == "pageExperOrder") {
            //表示有新消息
            $("#exper_shike").removeClass("new");
        }
    }
    //第一次进入时候 去刷新
    exper.onPageLoadInit = function () {
        if (exper.loadNew) {
            exper.LoadM(0, exper.MyDB.cvnumber);
            exper.loadNew = false;
        }
    }
    //加载列表数据 先从本地取 没有 去加载 再从本地取出
    exper.getdata = function (success, cvnumber) {
        if (exper.MyDB.db != null) {
            //获取数据 
            IndexDB.Select(exper.MyDB.dbName, cvnumber, function (result) {
                if (typeof result != 'object') {
                    result = eval("(" + result + ")");
                }
                if (result != undefined) {
                    success(result);
                } else {
                    exper.MyDB.load({ startid: 0, cvnumber: cvnumber, pid: 0, newTime: $("#exper_sumall").attr("data-newId") }, function () {
                        exper.loadNew = false;
                        exper.getdata(success, cvnumber);
                    })
                }
            }, exper.MyDB.db);
        } else {
            IndexDB.openDB(exper.MyDB.dbName, exper.MyDB.tabNames, function () {
                exper.MyDB.db = IndexDB._pageDB.db;
                //获取数据 
                IndexDB.Select(exper.MyDB.dbName, cvnumber, function (result) {
                    if (typeof result != 'object') {
                        result = eval("(" + result + ")");
                    }
                    if (result != undefined) {
                        success(result);
                    } else {
                        exper.MyDB.load({ startid: 0, cvnumber: cvnumber, pid: 0, newTime: $("#exper_sumall").attr("data-newId") }, function () {
                            exper.loadNew = false;
                            exper.getdata(success, cvnumber);
                        })
                    }
                });
            }, 2);
        }
    }

    //跟新列表/获取更多
    exper.LoadM = function (startid, cvnumber) {
        var url = appUrl(exper.MyDB.url);
        $.ajax({
            url: url,
            data: { startid: startid, cvnumber: cvnumber, pid: 0, newTime: $("#exper_sumall").attr("data-newId") },
            type: "Get",
            dataType: 'json',
            success: function (result) {
                var json = result
                if (json.result == 10000) {
                    if (startid == 0) {
                        exper.MyDB.update(exper.MyDB.dbName, json.data, exper.bindNew);
                    } else {
                        var list = json.data.list;
                        var newd = new Array();
                        for (var i in list) {
                            //判断页面是否已经有 改年的ul 
                            if ($("#" + i).length > 0) {//有 则加到这个ul 下面 
                                $("#" + i).append($("#exper_liTemplate").render(list[i]));
                                exper.iscroller.refresh();
                                exper.loadingMore = false;
                                $("#exper-more span").removeClass("preloader").html("&nbsp;");
                                $("#exper-more").removeClass("now");
                            } else {//没有 正常加
                                newd.push({ year: i, data: list[i] });
                                json.data.list = newd.reverse();
                                if (json.data.list.length > 0 && json.data.list[0].data.length > 0) {
                                    //console.log("加载更多");
                                    $("#experlistid").append($("#exeper_ListTemplate").render(json.data));
                                    exper.iscroller.refresh();
                                    exper.loadingMore = false;
                                    $("#exper-more span").removeClass("preloader").html("&nbsp;");
                                    $("#exper-more").removeClass("now");
                                } else {
                                    exper.loadingMore = false;
                                    $("#exper-more span").removeClass("preloader").html("&nbsp;");
                                    $("#exper-more").removeClass("now");
                                }
                            }

                        }
                    }
                }
            },
            error: function (er) {
                console.log("服务器获取失败");
            }
        });
    };

    //绑定数据
    exper.bindNew = function (data) {
        if (typeof data != 'object') {
            data = eval("(" + data + ")");
        }
        if (data.ishaveNew == 1) {
            //表示有新消息
            $("#exper_shike").addClass("new");
        } else {
            //没有新消息
            $("#exper_shike").removeClass("new");
        }
        if (data.view.length > 0) {
            $("#exper-banner").show();
            $("#exper-banner .swiper-wrapper").html($("#exeper_viewTemp").render(data));
            //轮播图exper_banner
            if (exper.swiper) { exper.swiper.destroy() }
            exper.swiper = new Swiper('#exper-banner', {
                lazyLoading: true,
                pagination: '#exper-banner .swiper-pagination',
                paginationClickable: true,
                autoplay: 2500,
                loop: true
            });
        }
        if (data.sum.length > 0) {
            $("#exper_sumall").show();
            $("#exper_sumall").html("共有" + data.sum[0].sum + "条记忆，" + Percentage(data.sum[0].mysum, data.sum[0].sum) + "由你贡献");
            $("#exper_sumall").attr("data-newId", data.sum[0].newId)
        }
        var list = data.list;
        var newd = new Array();
        for (var i in list) {
            newd.push({ year: i, data: list[i] });
        }
        data.list = newd.reverse();
        if (data.list.length > 0 && data.list[0].data.length > 0) {
            $("#experlistid").html($("#exeper_ListTemplate").render(data));
        } else {
            $("#experlistid").html('<div class="noData">暂时还没有人哦。赶紧成为第一个吧...</div>');
        }
        exper.iscroller.refresh();
        exper.isRefresh = false;
        $("#exper-downPull span").html("下拉刷新");
        $("#exper-downPull").removeClass("now");
        localStorage.setItem(exper.key, "no");
    };
    //搜索
    exper.search = function (searchval, pageIndex, success) {
        var url = appUrl('/experlist/search');
        $.ajax({
            url: url,
            data: { uasTitle: searchval, cvnumber: exper.MyDB.cvnumber, pid: 0, pageIndex: pageIndex },
            type: "Get",
            dataType: 'json',
            success: function (result) {
                var json = result
                if (json.result == 10000) {
                    var data = json.data;
                    if (exper.pageIndex == 1) {
                        success(data, true);
                    } else {
                        success(data, false);
                    }
                }
            },
            error: function (er) {
                console.log("服务器获取失败");
            }
        });
    }


    //搜索回调
    exper.searchM = function (data, type) {
        var list = data.list;
        var newd = new Array();
        for (var i in list) {
            newd.push({ year: i, data: list[i] });
        }
        data.list = newd.reverse();
        if (type) {
            $("#exper-banner").hide(); //隐藏轮播图
            $("#exper_sumall").hide(); //隐藏统计
            if (data.list.length > 0 && data.list[0].data.length > 0) {
                $("#experlistid").html($("#exeper_ListTemplate").render(data));
            } else {
                $("#experlistid").html('<div class="noData">没有找到你想要的东西呢....</div>');
            }
        } else {
            if (data.list.length > 0) {
                $("#experlistid").append($("#exeper_ListTemplate").render(data));
                exper.loadingMore = false;
                $("#exper-more span").removeClass("preloader").html("&nbsp;");
                $("#exper-more").removeClass("now");
            } else {
                exper.loadingMore = false;
                $("#exper-more span").removeClass("preloader").html("&nbsp;");
                $("#exper-more").removeClass("now");
            }
        }
        pubFigure.removeFigureSearchOptions();
        exper.iscroller.refresh();
        exper.pageIndex = data.pageTb[0].PageIndex;
        exper.PageCount = data.pageTb[0].PageCount;
    }

    //搜索取消
    exper.on("#exper-search .search-cancel", "touchend", function () {
        //加载数据
        exper.getdata(exper.bindNew, exper.MyDB.cvnumber);
        exper.issearch = false;
        exper.loadingMore = false;
    })

    //点击时刻
    exper.on("#exper_shike", "touchend", function () {
        //要更新 本地数据库里的一个值  ishaveNew 在跳转页面
        R.to("pageExperOrder");

    });

    //时间格式转换
    $.views.helpers({
        DateTimeHtml: function (statrTstirng, sType, endTstring, endType, type) {
            var tim = TimeTrans.toText2(statrTstirng, sType, endTstring, endType);
            switch (type) {
                case 1:
                    return tim.listUp;
                    break;
                case 2:
                    return tim.listDown;
                    break;
                case 3:
                    return tim.more;
                    break;
            }
        },
        isNowY: function (year, index) {
            var myDate = new Date();
            var newy = myDate.getFullYear().toString();
            if (year == newy && index == 0) { //是今年 并且 是第一个
                return false;
            } else {
                return true;
            }
        },
        contentsHtmlt: function (cont) {
            var result = "";
            var yourString = cont;
            var str = yourString.split(",");
            for (var i = 0; i < str.length; i++) {
                result += "<img src='" + str[i] + "' />";
            }
            return result;
        }, replaceE: function (str) {
            if (str != null) {
                return EmojiJM(str);
            } else {
                return '';
            }
        }
    });


})(jQuery)
