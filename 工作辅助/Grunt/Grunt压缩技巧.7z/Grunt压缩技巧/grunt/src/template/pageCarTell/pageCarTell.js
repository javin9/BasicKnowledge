﻿; (function ($) {
    pageCarTell.onPageLoad = function () {
        pageCardHelper.setinfo('pageCar_landline', 'landline');
    }
    //保存
    pageCarTell.on('.pull-right', 'touchend', function (e, ev) {
        pageCardHelper.updateinfo('pageCar_landline', 'landline');
    });
})(jQuery);