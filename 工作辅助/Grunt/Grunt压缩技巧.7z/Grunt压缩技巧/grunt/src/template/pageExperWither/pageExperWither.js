(function () {
    var wither = pageExperWither;
    wither.iscroller = null;
    wither.initPhoto = null;
    var articleId = 0, experId = 0, supId = 0;
    var editor;
    wither.onPageLoadInit = function () {

        wither.initPhoto = app.initPhoto(".preview-editor");

    }
    wither.onPageLoad = function () {
        articleId = wither.getParam("id");
        supId = wither.getParam("supid");
        if (supId > 0) {//编辑
            wither.getsupp();
        } else {
            editor = new EditMobileClass(document.getElementById("editStage"));
            editor.init();
            EditMobileData.text.add(editor);
        }
    }
    //编辑获取内容
    wither.getsupp = function () {
        ajaxTool.ajaxPost(appUrl("getsuppbyid"), { id: supId }, function (result) {
            if (result.result == 10000) {
                if (!!result.data) {
                    var resdata = $.parseJSON(result.data);
                    editor = new EditMobileClass(document.getElementById("editStage"), resdata[0].Contents);
                    editor.init();
                }
            } else {
                editor = new EditMobileClass(document.getElementById("editStage"));
                editor.init();
                EditMobileData.text.add(editor);
            }
        });
    }
    //保存
    wither.on(".experSave", "touchend", function () {
        var contents = editor.getHtml();
        var type=$(".btn-checkbox").hasClass("on")?1:0;
        // return false;
        if (editor.isAjaxEnd()) {
            ajaxTool.ajaxPost(appUrl("addsupp"), { id: supId, articleId: articleId, contents: contents, cvnumber: getCurrentCV(), type: type }, function (result) {
                console.log(result);
                if (result.result == 10000) {
                    ExperLocData();
                    R.to(-1);// R.to("pageExperSee?id=" + articleId);
                }
            });
        } else {
            app.alert("您的照片/视频还未上传完成，请稍等..！");
        }
    }); 
    //返回
    wither.on("#WitherBack", "touchend", function () {
        if (!editor.isAjaxEnd()) {
            app.alert("您的照片/视频还未上传完成，请稍等..,确定返回吗？", [{
                title: "确定", fn: function () {
                    app.hideAlert();
                    R.to(-1);//"pageExperSee?id=" + articleId)
                    editor.abortAjax();//中断ajax请求
                }
            },
           { title: "取消", fn: function () { app.hideAlert(); } }], "返回提示");
        } else {
            R.to(-1);
        }
    });
    //预览
    wither.on("#preview", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("header-tag-active")) return false;
        $(self).addClass("header-tag-active").siblings("span").removeClass("header-tag-active");
        $(".exper-content").hide();
        $(".preview-editor").show();
        var gethtml = editor.getHtml();
        $(".preview-editor .app-editor-content").html(gethtml);
        if (!wither.iscroller) wither.iscroller = app.iscroll(".preview-editor");
    })

    //编辑
    wither.on("#editor", "touchend", function (e, ev) {
        var self = ev.self;
        if ($(self).hasClass("header-tag-active")) return false;
        $(self).addClass("header-tag-active").siblings("span").removeClass("header-tag-active");
        $(".exper-content").show();
        $(".preview-editor").hide();
        wither.iscroller = null;
    })
    //选择
    wither.on(".btn-checkbox", "touchend", function (e, ev) {
        var that = ev.self;
        app.checkBox($(that));
    })
})(jQuery)
