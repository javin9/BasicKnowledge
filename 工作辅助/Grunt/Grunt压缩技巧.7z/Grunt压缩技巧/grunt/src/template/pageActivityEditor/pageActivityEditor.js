(function($){
	var activity = pageActivityEditor;
	activity.iscroller = null;
	activity.initPhoto = null;
	var editor, articleId = 0, privacy = 1;
	activity.onPageLoadInit = function () {
		
		//时间选择
		var currYear = (new Date()).getFullYear();	
		var opt={};
		opt.datetime = {preset : 'datetime'};
		opt.default = {
			theme: 'android-ics light', //皮肤样式
			display: 'modal', //显示方式 
			mode: 'scroller', //日期选择模式
			lang:'zh',
			dateFormat: 'yy-mm-dd',
			startYear:currYear - 10, //开始年份
			endYear:currYear + 10 //结束年份
		};
		articleId = activity.getParam('Id');
		if (articleId > 0) {
		    activity.GetArticleById(articleId);
		} else {
		    editor = new EditMobileClass(document.getElementById("editStage"));
		    editor.init();
		    $.setCookie("activ_open",true);
		}
		var optDateTime = $.extend(opt['datetime'], opt['default']);
		$("#activity_firstTime").mobiscroll(optDateTime).datetime(optDateTime);
		$("#activity_lastTime").mobiscroll(optDateTime).datetime(optDateTime);
	    //初始化默认时间值
		var nowtime = DateTime(new Date(), 0);
		var time = TimeTrans.toText(nowtime, 2);
		$("#activity_firstTime").val(nowtime.Replace("/", "-")).attr("data-foramt", 2);
		$("#select-time").html(time.main + '<em>' + time.more + '</em>');
	}
	
	
    //详情页
	activity.GetArticleById = function (articleId) {
	    ajaxTool.ajaxPost(appUrl("getarticlebyid"), { articleId: articleId, type: 0, articleType:2 }, function (result) {
	        console.log(result);
	        if (result.result == 10000) {
	            if (!!result.data) {
	                //var resdata = $.parseJSON(result.data);
	                var data = result.data;
	                editor = new EditMobileClass(document.getElementById("editStage"), EmojiJM(data.contents));
	                editor.init();
	                $("#titile").text(EmojiJM(data.title));
	                $("#address").text(data.address);
	                privacy = data.privacy > 0 ? data.privacy : 1;
	                $.setCookie("activ_open", data.is_open);
	                var firstTime = data.start_time, firstForamt = data.start_type, lastTime = data.end_time, lastForamt = data.end_type;
	                $("#activity_firstTime").val(SevCombiTime(firstTime, firstForamt)).attr("data-foramt", firstForamt);
	                if (!!data.back_img) {
	                    $(".exper-header-back").attr("src", domain.imgUrl + data.back_img).removeClass("hidden");
	                    $(".header-back").hide(); $(".header-back-del").removeClass("hidden");
	                }
	                $("#backimg").val(data.back_img).attr("data-width", data.width).attr("data-height", data.height);;
	                if (!!data.end_time) $("#activity_lastTime").val(SevCombiTime(lastTime, lastForamt)).attr("data-foramt", lastForamt);
	                $(".preview-info").html('<span data-route-to="">{0}</span>始发于{1}&nbsp;&nbsp;{2}人报名&nbsp;&nbsp;{3}人查看'.format1(data.name, DateTime(data.add_time, 1), data.browse_show, data.partake));
	                if (!!data.contents) $(".create-name").html('<div class="create-name-mox" data-route-to=""><span>{0}</span><span>{1}</span></div>'.format1(data.name, DateTime(data.add_time, 1)));
	                var time = TimeTrans.toText(firstTime, firstForamt, lastTime, lastForamt);
	                $("#select-time").html(time.main + '<em>' + time.more + '</em>');
	            }
	        }
	    });
	}
	//预览
	activity.on("#preview","touchend",function(e,ev){
		var self = ev.self;
		if($(self).hasClass("header-tag-active"))return false;
		$(self).addClass("header-tag-active").siblings("span").removeClass("header-tag-active");
		$(".exper-content").hide();
		$(".preview-editor").show();
	    activity.iscroller = app.iscroll(".preview-editor");
	    if (!!$("#backimg").val()) {
	        $(".preview-background").remove();
	        $('.preview-content').prepend('<div class="preview-background"><img src="{0}"  data-src="{0}"  id="preview-back" data-size="{1}" class="" /></div>'.format1(domain.imgUrl + $("#backimg").val(), ($("#backimg").attr("data-width") + "*" + $("#backimg").attr("data-height"))));
	        ArticleBackPic(SS(".preview-background"));
	    } else {
	        $(".preview-background").remove();
	    }
		$(".preview-editor .preview-time").html($("#select-time").html());
		$(".preview-title").html($("#titile").val());
		var gethtml = editor.getHtml();
		$(".preview-editor .app-editor-content").html(gethtml);
		appUser.get(getCurrentCV(), function (result) {
		    var name = result.name;
		    var time = new Date();
		    $(".preview-info").html('<span data-route-to="">{0}</span>始发于{1}&nbsp;&nbsp;{2}人报名&nbsp;&nbsp;人查看'.format1(name, DateTime(time, 1), 0, 0));
		    if (!!gethtml) { $(".create-name").html('<div class="create-name-mox" data-route-to=""><span>{0}</span><span>{1}</span></div>'.format1(name, DateTime(time, 1))); }
		    activity.initPhoto = app.initPhoto(".preview-editor");
		    setTimeout(function () {
		        activity.iscroller.refresh();
		    }, 500);
		    
		});
		
		
	})
    //上传背景
	$(document).on("change", "#back", function (e) {
	    var file = e.target.files[0];
	    //var reader = new FileReader();  
	    ////将文件以Data URL形式读入页面  
	    //reader.readAsDataURL(file);  
	    //reader.onload=function(e){  
	    //   // console.log(this.result);
	    //}
	    //var data = new FormData();
	    //var key = $.Guid();
	    //data.append(key, file);

	    //$.ajax({
	    //    url: domain.uploadImage,
	    //    data: data,
	    //    type: "post",
	    //    processData: false,
	    //    contentType: false,
	    //    success: function (result) {
	    //        if (result.result == 10000) {
	    //            $("#backimg").val(result.data[0].data_url);
	    //            $(".exper-header-back").attr("src", domain.imgUrl+ result.data[0].data_url).removeClass("hidden");
	    //           // app.alert("背景上传成功，可以点预览查看");
	    //        }
	    //    }
	    //});
	    editor.addImage("", file, { width: 1080, height: 608 }, function (o) {
	        $(".exper-header-back").attr("src", o.amend.base64);
	    }, function (t, o) {
	        var result = eval('(' + t + ')');
	        $("#backimg").val(result.data[0].data_url).attr("data-width", o.amend.width).attr("data-height", o.amend.height);
	        $(".header-back").hide();
	        $(".exper-header-back,.header-back-del").removeClass("hidden");

	    }, function (percent) {
	        $(".header-back").html(percent + "%");
	    });
	});
    //删除背景
	activity.on(".header-back-del", "touchend", function () {
	    $(".header-back").html('设置背景<input type="file" id="back" />').show();
	    $(".header-back-del").addClass("hidden");
	    $('.exper-header-back').attr("src", "/img/back.jpg").addClass("hidden");
	    $("#backimg").val("");
	});
	//编辑
	activity.on("#editor","touchend",function(e,ev){
		var self = ev.self;
		if($(self).hasClass("header-tag-active"))return false;
		$(self).addClass("header-tag-active").siblings("span").removeClass("header-tag-active");
		$(".exper-content").show();
		$(".preview-editor").hide();
		activity.iscroller = null;
	})
    //保存
	activity.on(".experSave", "touchend", function (e, ev) {
	    var self = ev.self;
	    var title = EmojiBM($("#titile").val());
	    var address =$("#address").val();
	    var content = EmojiBM(editor.getHtml());
	    var startTime = $("#activity_firstTime").val(), endTime = $("#activity_lastTime").val(), startType = $("#activity_firstTime").data("foramt"), endType = $("#activity_lastTime").data("foramt"), backImg = $("#backimg").val(), cvNumber = getCurrentCV(), width = $("#backimg").attr("data-width"), height = $("#backimg").attr("data-height");
	    if (!$('.experSave').hasClass("not")) {
	       
	        if (!!startTime) {
	            if (!!title) {
	                if (editor.isAjaxEnd()) {
	                    $('.experSave').addClass("not");
	                   
	                    startTime = CombiTime(startTime, startType);
	                    endTime = CombiTime(endTime, endType);
	                    if(!!endTime){
	                        if (new Date(endTime).getTime() < new Date(startTime).getTime()) {
	                            app.alert("结束时间必须大于开始时间");
	                            $('.experSave').removeClass("not");
	                            return false;
	                        }
	                    }
	                    var imgArr = bioInsertImgArr($("#editStage img"));
	                    var videoArr = bioInsertVideoArr($("#editStage video"));
	                    ajaxTool.ajaxPost(appUrl("saveactivity"), { id: articleId, title: title, contents: content, backImg: backImg, startTime: startTime, endTime: endTime, startType: startType, endType: endType, cvNumber: cvNumber, imgStr: '{"key":[' + imgArr.toString() + ']}', address: address, width: width, height: height, videoStr: '{"key":[' + videoArr.toString() + ']}' }, function (result) {
	                        $('.experSave').removeClass("not");
	                        if (result.result == 10000) {
	                            if (!!result.data) {
	                                var resdata = $.parseJSON(result.data);
	                                ThingLocData();
	                                R.to("pageActivitySet?articleId=" + resdata[0].Id + "&privacy=" + privacy, "", "");
	                            }
	                        }
	                    });
	                } else {
	                    app.alert("您的照片/视频还未上传完成，请稍等..");
	                }
	            } else {
	                app.alert("请填写活动标题");
	            }
	        } else {
	            app.alert("请选择时间");
	        }
	    }
	});
    //返回
	activity.on("#ActivityBack", "touchend", function () {
	    if (!editor.isAjaxEnd()) {
	        app.alert("您的照片/视频还未上传完成，请稍等..,确定返回吗？", [{
	            title: "确定", fn: function () {
	                app.hideAlert();
	                R.to(-1);
	                editor.abortAjax();//中断ajax请求
	            }
	        },
           { title: "取消", fn: function () { app.hideAlert(); } }], "返回提示");
	    } else {
	        R.to(-1);
	    }
	});
    /*Des:获取所有图片，生成数组, $this_content:当前对象 */
	function bioInsertImgArr($this_content) {
	    var spanArr = $this_content,
             imgArr = [],
             template = '{"RowId":"{0}","A_Id":"R_Id","BigURL":"{1}","Url":"{2}","ArticleType":"2","Type":"1","Width":"{3}","Height":"{4}","PlatFormId":"PFID"}';
	    $.each(spanArr, function (i, item) {
	        var $this = $(item);
	        imgArr.push(template.format([(i + 1), $this.attr("data-src").replace(domain.imgUrl, ""), $this.attr("src").replace(domain.imgUrl, ""), $this.attr("data-width"), $this.attr("data-height")]));
	    });
	    return imgArr;
	}
    //视频
	function bioInsertVideoArr($this_content) {
	    var spanArr = $this_content,
             imgArr = [],
             template = '{"RowId":"{0}","A_Id":"R_Id","BigURL":"{1}","Url":"{2}","ArticleType":"1","Type":"2","Width":"{3}","Height":"{4}","PlatFormId":"PFID"}';
	    $.each(spanArr, function (i, item) {
	        var $this = $(item);
	        var url = $this.attr("data-url").replace(domain.imgUrl, "");
	        imgArr.push(template.format([(i + 1), url, url, 0, 0]));
	    });
	    return imgArr;
	}
	//选择时间
	activity.on("#select-time","touchend",function(e,ev){
		$(".add-timer").addClass("in");
	})
	
	//清空时间
	activity.on(".resetTime","touchend",function(e,ev){
		$(ev.self).prev("input").val('').attr("data-foramt",0);
	})
	
	//关闭时间
	activity.on("#time-close","touchend",function(e,ev){
		$(".add-timer").removeClass("in");
	})
	
	//时间确定
	activity.on("#time-save","touchend",function(e,ev){
		$(".add-timer").removeClass("in");
		var firstTime = $("#activity_firstTime").val(),
			firstForamt = $("#activity_firstTime").attr("data-foramt"),
			lastTime = $("#activity_lastTime").val(),
			lastForamt = $("#activity_lastTime").attr("data-foramt");
		
		var time = TimeTrans.toText(firstTime,firstForamt,lastTime,lastForamt);
		$("#select-time").html(time.main + '<em>' + time.more +'</em>');
	})
	
})(jQuery);
