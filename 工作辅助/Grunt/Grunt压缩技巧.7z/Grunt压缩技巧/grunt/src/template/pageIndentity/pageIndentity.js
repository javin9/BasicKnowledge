(function($){
    var cvnumber = getCurrentCV();
	var I = pageIndentity;
	//左滑删除
	I.on(".navigate-right","slide",function(e,ev){
		var that = ev.self;
		if($(that).parents(".pageScroll").find(".navigate-right").length<2)return false;
		$(".swipe-left").removeClass("swipe-left");	
		$(that).parents(".table-view-cell").addClass("swipe-left");
	},{direc:"left"});
	I.on(".pageScroll", "touchstart", function (e, ev) {
	    $(".swipe-left").removeClass("swipe-left");
	});
    //编辑
	I.on('.navigate-right', 'touchend', function (e, ev) {
	    var value = $(ev.self).parents('li').first().data('id');
	    R.to('pageIndAdd?id=' + value);
	});
    //删除
	I.on('.swipe-del', 'touchend', function (e, ev) {
	    var id = $(ev.self).data('id');
	    i.deluid(id, function () {
            //重新设置身份信息
	        appUser.set({ cvnumber: getCurrentCV(), pid: 0 }, function (result) {
	            ExperLocData();
	        });
	        if ($(ev.self).parents('li').siblings().length == 1) {
	            $(ev.self).parents('ul').first().remove();
	        } else {
	            $(ev.self).parents('li').first().remove();//移除
	        }
	    });
	});
	
	I.onPageLoad = function () {
        //如果是保存或者第一次进来，才刷新
	    if (R.getPara('code', 'code') == 'ok'||!i.isload()) {
	            i.bind();
	    }
	}

	var flag = {
	    e: 1,//阶段
	    p: 2,//职能
	    x: 3,//系
	    z: 4,//专业
	    b: 5,//班级
	    y: 8 //年份
	};
	var i = {
	    isload: function () {
	        return !!$('#pageIdentity_userIdentites').find('ul').length;
	    },
	    data:[],
	    bind: function () {
	        appUserIdentity.get(cvnumber, function (data) {
	            var html = jsRenderBinding({
	                page: 'pageIdentity.pageIdentity_template_identity',
	                json: data
	            });
	            html += '  <div class="list-block"><span data-route-to="pageIndAdd">添加学院身份</span></div>';
	            $('#pageIdentity_userIdentites').html(html);
	            app.iscroll('.pageScroll');
	        });
	    },
	    deluid: function (id,success) {
	        ajaxTool.ajaxPost(appUrl('user/deluserid'), { cvnumber: cvnumber, id: id }, function (result) {
	            if (result.result == 10000) {
                    if(typeof success === 'function') success();
	            }
	        });
	    }
	};
})(jQuery);
