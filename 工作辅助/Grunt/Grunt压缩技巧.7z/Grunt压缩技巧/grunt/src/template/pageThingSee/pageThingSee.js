(function($){
	var see = pageThingSee;
	see.iscroller = null;
	see.initPhoto = null;
	see.loadingMore = false;
	see.name = '';
	see.cvnumber = getCurrentCV();
	see.rcvnumber = 0;
	see.topid = 0;
	see.parentid = 0;
	see.pageindex = 1;
	see.pagecount = 1;
	see.contents = "";
	var fb_cvnumber=0;
	var editor, articleId = 0;
	see.onPageLoadInit = function(){
		see.iscroller = app.iscroll("#page-thing-see");
		
		app.autoArea("#thing-message");

	

		//加载更多预备调用
		see.iscroller.on("scrollEnd",function(){
		    if (this.y == this.maxScrollY && !see.loadingMore && see.pageindex <= see.pagecount) {
				$("#thing-see-more span").addClass("preloader");
				see.loadingMore = true;
			    //调用加载更多函数
				see.getCommentPraise(articleId, 1, 0, (see.pageindex + 1));
			}
			
		});
	}
	see.onPageLoad = function () {
	    if (articleId != see.getParam('id')) {
	        $(".page-see-content,.preview-item-content").html("");
	        articleId = see.getParam('id');
	        see.getContents();
	        see.addBrowse();
	    }
	   
	}
    //编辑
	see.on("#btnedit", "touchend", function () {
	    R.to("pageThingEditor?Id=" + articleId, "", "");
	})
    //删除del
	see.on(".del", "touchend", function () {
	    app.alert("确定删除吗？", [{
	        title: "确定", fn: function () {
	            app.hideAlert();
	            see.DelArtilce();
	        }
	    },
        { title: "取消", fn: function () { app.hideAlert(); } }], "删除提示");
	})
    //内容模板
	var contenthtml = '<div class="create-name"><div class="create-name-mox" data-route-to="{3}"><span>{0}</span><span>{1}</span> </div></div><div class="app-editor-content">{2}</div>';
    //头部模板
	var titlehtml = '<div class="preview-header"><span class="preview-title">{0}</span> </div><em class="preview-info"><span data-route-to="">{1}</span>始发于{2}&nbsp;&nbsp;{3}人回应&nbsp;&nbsp;{4}人查看</em>';
  
    //加载主体内容和补充内容
	see.getContents = function () {
	    ajaxTool.ajaxPost(appUrl("getarticlebyid"), { articleId: articleId, type: 1, cvnumber: getCurrentCV(), articleType: 3 }, function (result) {
	        console.log(result);
	        if (result.result == 10000) {
	            if (!!result.data) {
	                var data = result.data, html;
	                if (data.id > 0) {
	                    html = titlehtml.format1(EmojiJM(data.title), data.name, DateTime(data.add_time, 1), data.partake, data.browse_show == 0 ? 1 : data.browse_show);
	                    $(".page-see-content").append(html);
	                    if (data.praise > 0) { $("#thing-header-like").attr("data-like", data.praise); $("#thing-header-like i").html('(' + data.praise + ')'); }
	                    if (data.witherid > 0) {
	                        $('.like').addClass('liked');
	                    }
	                     fb_cvnumber = data.cv_number;
	                    if (fb_cvnumber == getCurrentCV()) {//自己进来
	                        $("#page_zj").show();
	                        $("#page_br").hide();
	                    } else {
	                        $("#page_zj").hide();
	                        $("#page_br").show();
	                    }
	                    var commentHtml = "";
	                    commentHtml += contenthtml.format1(data.name, DateTime(data.add_time, 1), EmojiJM(data.contents), "");
	                    if (!!data.listContent) {
	                        for (var i = 0; i < data.listContent.length; i++) {
	                            commentHtml += contenthtml.format1(data.listContent[i].uname, DateTime(data.listContent[i].addTime, 1), EmojiJM(data.listContent[i].contents), "");
	                        }
	                    }
	                    $(".preview-info").after(commentHtml);
	                    if (data.contents.length > 0 || data.listContent!=null) {

	                    } else {
	                        $(".create-name").hide();
	                    }
	                    var drophtmlContent = dropHtml(data.contents);
	                   
	                    wxShare.init({
	                        page: 'pageThingSee',
	                        title: EmojiJM(data.title),
	                        desc: "发布者:" + data.name + "\n" + (drophtmlContent.length > 20 ? drophtmlContent.substring(0, 20) : drophtmlContent),
	                        imgUrl: domain.imgUrl + data.head_photo
	                    });

	                    see.initPhoto = app.initPhoto("#page-thing-see .page-see-content");
	                    setTimeout(function () {
	                        see.iscroller.refresh();
	                    }, 500);
	                    see.getCommentPraise(articleId, 1, 1, 1);
	                } else {
	                    app.alert("你访问的互助不存在！");

	                }
	            }
	        }
	    });
	};
    //获取 下的数字  评论  
	see.getCommentPraise = function (id, type, numtype, pageindex) {
	    ajaxTool.ajaxPost(appUrl("getcomment"), { id: id, type: type, numtype: numtype, cvnumber: getCurrentCV(), pageIndex: pageindex },
            function (result) {
                console.log(result);
                if (result.result = 10000) {
                   
                    if (type == 1) { //评论模板
                        if (result.data.comm != null && result.data.comm.length > 0) {
                            $(".preview-item-content").append($("#template_coment").render(result.data));
                            see.loadingMore = false;
                        } else {
                            see.loadingMore = true;
                        }
                    } 
                    if (!!result.data.pageing) {
                        see.pageindex = result.data.pageing.pageindex;
                        see.pagecount = result.data.pageing.pagecount;
                        if (result.data.pageing.datacount==0) {
                            $("#notdata").show();
                        }
                    }
                    $("#thing-see-more span").removeClass("preloader");
                  
                    //刷新滚动条
                    see.iscroller.refresh();
                    see.getuserinfo();
                }
            });
	}
    //删除
	see.DelArtilce = function () {
	    ajaxTool.ajaxPost(appUrl("delarticle"), { id: articleId, type: 3 }, function (result) {
	        console.log(result);
	        if (result.result == 10000) {
	            ThingLocData();
	            app.alert("删除成功！");
	            R.to(-1);
	        }
	    });
	}
    //喜欢点赞
	see.PraiseAdd = function (articleId, cvnumber, flag) {
	    ajaxTool.ajaxPost(appUrl("addpraise"), { articleId: articleId, cvnumber: cvnumber, flag: flag, articleType:3 }, function (result) {
	        console.log(result);
	        if (result.result == 10000) {
	            ThingLocData();
	        }
	    });
	}
    //add评论
	see.addComment = function (articleId, contents, cvnumber, rcvnumber, topId, parentId) {
	    ajaxTool.ajaxPost(appUrl("addcommnet"), { articleId: articleId, contents: contents, cvnumber: cvnumber, rcvnumber: rcvnumber, topId: topId, parentId: parentId, articleType: 3 },
            function (result) {
                console.log(result);
                if (result.result == 10000) {
                    if (!!result.data) {
                        var resdata = $.parseJSON(result.data);
                        var id = resdata[0].Id;
                        var title = resdata[0].title;
                        var model = {};
                        appUser.get(getCurrentCV(), function (result) {
                            model.headphoto = result.headphoto;
                            model.name = result.name;
                            model.cvnumber = result.cvnumber;
                            model.contents = EmojiJM(contents);
                            model.addtime = DateTime(new Date(), 4);
                            model.topid = id;
                            model.id = id;
                            model.title = title;
                            var tt = ' <li class="table-view-cell"  >'
                        + '<img src="{0}" data-route-to="" />'
         + '<span class="liuyan-name" data-name="{1}" data-topid="{2}" data-commid="{3}"  data-cvnumber="{4}"  data-route-to="{8}">{5}</span>'
         + '<span class="liuyan-time">{6}</span>'
         + '<span class="liuyan-text">{7}</span>'
         + '</li>';
                            $(".preview-item-content").prepend(tt.format1(model.headphoto, model.name, model.topid, model.id, model.cvnumber, model.title, model.addtime, model.contents, "pageSpace?cv=" + model.cvnumber));
                        });

                        $("#notdata").hide();
                        //清空
                        $("#thing-message textarea").val("").trigger("change");
                      
                        see.rcvnumber = 0;
                        see.parentid = 0;
                        // $("#thing-message textarea").attr("placeholder", "评论");
                        see.iscroller.refresh();
                        ThingLocData();
                    }
                }
            });
	}
    //浏览
	see.addBrowse = function () {
	    ajaxTool.ajaxPost(appUrl("addbrowse"), { articleId: articleId, articleType: 1, cvnumber: getCurrentCV() },
          function (result) {
          });
	}

    //联系他
	see.getuserinfo = function () {
	    ajaxTool.ajaxPost(appUrl("getuserinfo"), { cvnumber: fb_cvnumber },
         function (result) {
             if (result.result == 10000) {
                 if (!!result.data) {
                     var resdata = $.parseJSON(result.data);
                     $("#thing-contact").prepend($("#template_userinfo").render(resdata));
                     var model = {
                         cvnumber: resdata[0].cvnumber,
                         name: resdata[0].name,
                         title: resdata[0].identity_title,
                         organization: resdata[0].company,
                         mobile: resdata[0].mobile,
                         email: resdata[0].email,
                     }
                     $.ajax({
                         url: domain.getQrCode,
                         type: "POST",
                         data: model,
                         success: function (result) {
                             if (result.result == 10000) {
                                 document.getElementById('qrimg').src = result.data.src;
                             }
                         }
                     });
                 }
             }
         });
	}
	//清空
	see.on("#thing-message-send", "touchend", function () {
	    var comm_content = $("#comm_content").val();
	    if (comm_content.length > 0) {
	        see.addComment(articleId, EmojiBM(comm_content.replace(/\n/g, '<br/>')), see.cvnumber, see.rcvnumber, see.topid, see.parentid);

	    }
		$("#thing-message textarea").val("").trigger("change");
	})

    //喜欢
	see.on("#thing-header-like", "touchend", function (e, ev) {
	    var self = ev.self;
	    if ($(self).hasClass("liked")) {
	        $("#thing-header-like").removeClass("liked");
	        var like = $("#thing-header-like").attr("data-like");
	        like--;
	        $("#thing-header-like i").html("(" + like + ")");
	        $("#thing-header-like").attr("data-like", like)
	        //执行去掉喜欢函数
	        see.PraiseAdd(articleId, getCurrentCV(), 1);
	    } else {
	        $("#thing-header-like").addClass("liked");
	        var like = $("#thing-header-like").attr("data-like");
	        like++;
	        $("#thing-header-like i").html("(" + like + ")");
	        $("#thing-header-like").attr("data-like", like)
	        //执行添加喜欢函数
	        see.PraiseAdd(articleId, getCurrentCV(), 0);
	    }
	})
    //回复XXX
	see.on(".preview-item-content .liuyan-name", "longtouch", function (e, ev) {
	    var self = ev.self;
	    if (typeof ($(self).attr("data-name")) == "undefined") return false;
	    var name = $(self).attr("data-name");
	    see.name = name;
	    see.topid = $(self).attr("data-topid");
	    see.parentid = $(self).attr("data-commid");
	    see.cvnumber = $(self).attr("data-cvnumber");
	    see.rcvnumber = getCurrentCV();
	    $("#thing-message textarea").attr("placeholder", "回复" + name);
	    $("#thing-message").removeClass("footerBar-overlay");
	    $(".modal-over-white").addClass("modal-overlay-visible");
	    setTimeout(function () {
	        $("#thing-message textarea").focus();
	    }, 400)
	})
    //查看联系方式
	see.on("#thing-phone", "touchend", function (e, ev) {
	    $(".modal-over-back").addClass("modal-overlay-visible");
	    $("#thing-contact").addClass("in");
	})

    //关闭联系方式
	see.on("#thing-contact-btn", "touchend", function (e, ev) {
	    $(".modal-over-back").removeClass("modal-overlay-visible");
	    $("#thing-contact").removeClass("in");
	})
	$.views.helpers({
	    DateTime: function (id, type) {
	        return DateTime(id, type);
	    },
	    jmContent: function (contents) {
	        return EmojiJM(contents);
	    },
	    isShow: function (str) {
	        return !!str ? true : false;
	    }
	});
})(jQuery)
