/* EditMobileClass 移动端富文本编辑器
*	version		: 	V0.5 解决了上传中的进度条层在 getHTML时的删除问题（通过设置HTML上的data-edit-onlyedit)
*                        解决了图片组的多张大图后，前端读取图片的 无响应期（提前插入‘读取图片'层）
*/


var EditMobileData = {
    //图片ajax地址
    ajaxUrl: domain.uploadBase64,//http://api.gurucv.ms/v3/upload/base64  //upload.asp

    //视频AJAX地址
    ajaxVideoUrl: domain.uploadVideo,

    //标题工具
    title: {
        add: function (self, e) {
            var html = '<div contenteditable="true" class="app-editor-m editor-title" data-edit-type="title"></div>',
				conDom = EditMobileData.strToEle(html);
            self.stage.appendChild(conDom);
            conDom.focus();
        },
        toShow: function (ele) {
            if (ele.innerHTML == '') S(ele).removeEle();
            ele.removeAttribute("contenteditable");
        },
        toEdit: function (ele) {
            ele.setAttribute('contenteditable', 'true')
        },
        editFn: []
    },

    //文本工具
    text: {
        add: function (self, e) {
            var html = '<div contenteditable="true" class="app-editor-m editor-text" data-edit-type="text"></div>',
				conDom = EditMobileData.strToEle(html);
            self.stage.appendChild(conDom);
            conDom.focus();
        },
        toShow: function (ele) {
            if (ele.innerHTML == '') S(ele).removeEle();
            ele.removeAttribute("contenteditable");
        },
        toEdit: function (ele) {
            ele.setAttribute('contenteditable', 'true')
        },
        editFn: []
    },

    //图片工具
    image: {
        add: function (self, e) {
            var file = E.Target(e).files[0], img,
				html = '<div class="app-editor-m app-editor-img" data-edit-type="image"><img src="/img/imgReader.jpg" ><div class="editor-img-overlay" data-edit-onlyedit="percent"><span class="editor-upload-text"></span><span class="editor-upload-overlay" style="bottom: 100%;"></span></div></div>',
				toDom = EditMobileData.strToEle(html),
				img = S(toDom).child(0).t,
				upIng = S(img).nextEle().t;
            if (!IsImageType(file.type)) {
                app.alert("图片类型必须是.gif,jpeg,jpg,png中的一种!");
                return false;
            }
            self.stage.appendChild(toDom);
            self.addImage(toDom, file, { width: 1080, height: 608 }, function (o) {
                img.src = o.preview.base64;
            }, function (t, o) {
                S(upIng).removeEle();
                var result = eval('(' + t + ')');
                img.src = result.data[1].web_url;
                img.dataset.src = domain.imgUrl + result.data[0].data_url;
                $(img).attr("data-width", o.amend.width);
                $(img).attr("data-height", o.amend.height);
                img.dataset.size = o.amend.width + '*' + o.amend.height;
            }, function (percent) {
                upIng.children[0].innerHTML = percent + '%';
                upIng.children[1].style.bottom = percent + '%';
            });
        },
        toShow: function () { },
        toEdit: function () { }
    },


    /////////////////////////////////////照片墙工具
    photos: {
        add: function (self, e) {
            var id = NEWGuid();
            var html = '<div class="app-editor-m editor-photo-list"  id="' + id + '"  data-edit-type="photos"></div>',
				htmlAdd = '<span class="icon editor-photo-list-plus" data-edit-onlyedit="add"><input type="file" multiple/></span>',
				toDom = EditMobileData.strToEle(html), addDom = EditMobileData.strToEle(htmlAdd);
            toDom.appendChild(addDom);
            //for (var i = 0; i < E.Target(e).files.length;i++){
            //    if (!IsImageType(E.Target(e).files[i].type)) {
            //        app.alert("图片类型必须是.gif,jpeg,jpg,png中的一种!");
            //        return false;
            //    } 
            //}
            self.stage.appendChild(toDom);
            EditMobileData.photos._addFile(E.Target(e).files, toDom, addDom, self, id);
            E.Add(addDom, 'change', function (e) {
                EditMobileData.photos._addFile(E.Target(e).files, toDom, addDom, self, id);
            });
        },
        toShow: function (ele, self) {
            var waitDel = $('[data-edit-onlyedit]', ele);
            for (var i = 0, l = waitDel.length; i < l; i++) $(waitDel[i]).remove();
        },
        toEdit: function (ele, self) {
            var htmlAdd = '<span class="icon editor-photo-list-plus" data-edit-onlyedit="add"><input type="file" multiple/></span>',
				addDom = EditMobileData.strToEle(htmlAdd);
            ele.appendChild(addDom);
            E.Add(addDom, 'change', function (e) { EditMobileData.photos._addFile(E.Target(e).files, ele, addDom, self) })
        },
        _addFile: function (files, toDom, addDom, self, id) {
            var htmlIt = '<div class="editor-photo-list-item editor-img-upload"><img src="" /><div class="editor-img-overlay" data-edit-onlyedit="percent"><span class="editor-upload-text">读取图片</span><span class="editor-upload-overlay" style="bottom: 0%;"></span></div>',
				imgDom = EditMobileData.strToEle(htmlIt), imgOut, img, upIng, num = 0;
            for (var i = 0, l = files.length; i < l; i++) {
                imgOut = imgDom.cloneNode(true), img = imgOut.firstChild, upIng = S(img).nextEle().t;
                if (!IsImageType(files[i].type)) {
                    //app.alert("图片类型必须是.gif,jpeg,jpg,png中的一种!");
                    num++;
                    continue;
                }
              
                toDom.insertBefore(imgOut, addDom);
                (function (imgOut, img, upIng, toDom) {
                    self.addImage(toDom, files[i], {}, function (o) {
                        img.src = o.preview.base64;
                    }, function (t, o) {
                        var result = eval('(' + t + ')');
                        S(upIng).removeEle();
                        img.src = domain.imgUrl + result.data[1].data_url;
                        img.dataset.src = domain.imgUrl + result.data[0].data_url;
                        $(img).attr("data-width", o.amend.width);
                        $(img).attr("data-height", o.amend.height);
                        img.dataset.size = o.amend.width + "*" + o.amend.height;
                    }, function (percent) {
                        S(upIng).child(0).t.innerHTML = percent + '%';
                        S(upIng).child(-1).t.style.bottom = percent + '%';
                    });
                })(imgOut, img, upIng, toDom)
            }
           //删除加号
            if (num == files.length) {
                $("div[id=" + id + "]").remove();
            };
        },
    },



    //视频工具
    video: {
        add: function (self, e) {
            var file = E.Target(e).files[0],
            html = '<div class="app-editor-m app-editor-img" data-edit-type="video"><video controls="controls" width="100%">您的浏览器不支持 video 标签。</video><div class="editor-img-overlay" data-edit-onlyedit="percent"><span class="editor-upload-text"></span><span class="editor-upload-overlay" style="bottom: 100%;"></span></div></div>',
                toDom = EditMobileData.strToEle(html),
                video = S(toDom).child(0).t,
                upIng = S(video).nextEle().t;
            self.stage.appendChild(toDom);
            if (file.type == "video/mp4" || file.type == "video/quicktime") {
                var model = [];
                var data = new FormData();
                var key = NEWGuid();//video/mp4  video/quicktime
                data.append(key, file);
                model.push({ client_id: key, width: 200, annex_name: file.name });
                data.append('videojson', JSON.stringify(model));

                self._goAjax(toDom, '', EditMobileData.ajaxVideoUrl, data,
                    function (t) {
                        S(upIng).removeEle();
                        var result = eval('(' + t + ')');
                        console.log(result)
                        $(video).attr("src", result.data[0].video_url);
                        $(video).attr("data-url", result.data[0].data_url);
                        $(video).attr("video_image_url", result.data[0].video_image_url);
                    }, function (percent) {
                        upIng.children[0].innerHTML = percent + '%';
                        upIng.children[1].style.bottom = percent + '%';

                    }
                );

            } else {
                alert("请上传mp4或者mov格式的视频。"); return false;
            }
        },
        toShow: function () { },
        toEdit: function () { }
    },

    //str转Ele
    strToEle: function (s) { var d = document.createElement('div'), o; d.innerHTML = s; return d.firstChild; }
}

//http://api.gurucv.ms/v3/upload/base64

///////////////////////////////////////////////////////////编辑器类
function EditMobileClass(editor, initHtml, dataObj) {
    this.editor = editor;									//编辑器外层DIV
    this.stage = SS('.app-editor-content', this.editor);		//舞台
    this.tools = SS('.app-editor-tool', this.editor);		//工具    
    this.data = dataObj || EditMobileData;
    this.ajaxObj = {
        list: [],    //AJAX对象 [ {obj:xhr,statu:1,ele:ELE,total:0,loaded:0},{}] obj是XHR对象 ｜ statu: 0 发送但没开始 1上传中 2 完成 3 已取消 4 错误 ｜ ele: 产生AJAX的模块元素 | total: 总计大小 ｜ loaded:已经上传大小
        //total:0,    //一共有多大
        //loaded:0,   //已经上传多大
        uping: 0     //还有多少上正在上传        
    };
    this._initEditor(initHtml || '');
}

EditMobileClass.prototype = {

    init: function () {
        var self = this, i, l, toolType, eventName,
			tools = S('[data-edit-butype]', this.tools).t, o, it;

        //已经初始化过的，则不执行
        if (!!this.editor.dataset.editInit) return;
        this.editor.dataset.editInit = true;

        //------------对工具栏进行处理		
        for (i = 0, l = tools.length; i < l; i++) {
            toolType = tools[i].dataset.editButype;
            eventName = (tools[i].tagName == 'INPUT') ? 'change' : 'touchend';
            if (!!this.data[toolType]) {
                (function (t) {
                    S(tools[i]).on(eventName, function (e) { self.data[t].add(self, e) });
                })(toolType);
            }
        }

        //添加功能菜单
        o = {   //所有类型都有的功能
            begin: [
                {
                    title: '删除',
                    css: 'del',
                    fn: function (selEle, slideObj, eo) {
                        slideObj.menu.innerHTML = '';
                        S(selEle).removeEle();
                        self.abortAjax(selEle);
                    } //参数： selectorEle, SLIDEMenu对象，eo对象（注意是菜单点击的EO对象，不是slide的)
                },
                {
                    title: '上移',
                    touchkeep: true,
                    display: 0,
                    fn: function (t, so, eo) {
                        S(t).insertBefore(S(t).preEle().t);
                        so.menu.style.top = so._getTop(t);
                    }
                },
                {
                    title: '下移',
                    touchkeep: true,
                    display: '-1',
                    fn: function (t, so, eo) {
                        S(t).insertAfter(S(t).nextEle().t);
                        so.menu.style.top = so._getTop(t);
                    }
                }
            ]
        };
        for (it in this.data) { //各类型自定义的功能
            if (typeof this.data[it] == 'object' && !!this.data[it] && !!this.data[it].editFn && this.data[it].editFn.length > 0) o[it] = this.data[it].editFn;
        }
        //初始化对象
        var fnMenu = new SLIDEMenu(this.editor, '[data-edit-type]', o, 'editType');
    },

    //获取编辑器里的内容
    getHtml: function () {
        var html = this.stage.cloneNode(true),
            htmlc = html.children, htmlIt;
        for (var i = 0, l = htmlc.length; i < l; i++) {
            htmlIt = htmlc[i];
            this.data[htmlc[i].dataset.editType].toShow(htmlc[i], this);
            if (htmlIt != htmlc[i]) { i--; l--; }
        }
        S('[data-edit-onlyedit]', html).removeEle();
        return html.innerHTML;
    },

    _initEditor: function (html) {
        if (!!html) {
            this.stage.innerHTML = html;
            var it = this.stage.children, i, l;
            for (i = 0, l = it.length; i < l; i++) this.data[it[i].dataset.editType].toEdit(it[i], this)
        }
    },


    //----------------AJAX处理
    isAjaxEnd: function () {    //判断AJAX是否完成 true为是，false为否
        console.log(this.ajaxObj.uping);
        return this.ajaxObj.uping < 1;
    },
    abortAjax: function (ele) {    //取消AJAX, 可以传一个元素进来，则取消由该元素产生的所有AJAX,如果不传，则取消所有
        var list = this.ajaxObj.list, i, j, it, self = this;
        for (i = 0, l = list.length; i < l; i++) {
            if (list[i].statu < 2 && (ele === undefined || list[i].ele == ele)) {
                (function (i) { self._abortAjaxObj(i) })(i);
            }
        }
    },
    //---------AJAX内部
    _abortAjaxObj: function (ix) {
        this.ajaxObj.list[ix].obj.abort();
        this.ajaxObj.list[ix].statu = 3;
        this.ajaxObj.uping--;
    },
    _pushAjax: function (xhr, ajaxEle) {
        this.ajaxObj.list.push({ obj: xhr, statu: 0, ele: ajaxEle, total: 0, loaded: 0 });
        this.ajaxObj.uping++;
        return this.ajaxObj.list.length - 1;
    },

    _ajaxOnSuccess: function (id) {
        console.log(this.ajaxObj.list.length);
        this.ajaxObj.list[id].statu = 2;
        this.ajaxObj.list[id].loaded = this.ajaxObj.list[id].total;
        this.ajaxObj.uping--;
    },
    _ajaxOnProgress: function (id, loaded, total) {
        var it = this.ajaxObj.list[id];
        if (it.statu == 0) {
            it.total = total;
            this.ajaxObj.list[id].statu = 1;
        }
        it.loaded = loaded;
    },
    _ajaxOnError: function (id) {
        this.ajaxObj.list[id].statu = 4;
        this.ajaxObj.uping--;
    },

    _goAjax: function (ele, headStr, url, sendFd, upSuccess, upProgress, upError, imgO) {
        var self = this;
        ao = MSFILE.ajax(headStr, url, sendFd,
            function (t) {
                self._ajaxOnSuccess(ajaxId);
                console.log(self.ajaxObj);
                if (typeof (upSuccess) != 'undefined') upSuccess(t, imgO);
            },
            function (percent, loaded, total) {
                self._ajaxOnProgress(ajaxId, loaded, total);
                if (typeof (upProgress) != 'undefined') upProgress(percent, loaded, total, imgO);
            },
            function (s) {
                self._ajaxOnError(ajaxId);
                if (typeof (upError) != 'undefined') upError(s, imgO);
            }
        ),
    ajaxId = this._pushAjax(ao, ele);
    },


    //六个参数，后五个可选，依次是：文件，缩略及修正图尺寸， 刚添加的回调(o)， 上传成功的回调(t,o)， 上传中的回调(percent,o,loaded,total)，上传错误的回调(xhr.status,o)
    addImage: function (ele,f, picObj, add, upSuccess, upProgress, upError) {
        var self = this;
        MSFILE.getImageObj(f, function (o) {
            if (typeof (add) != 'undefined') add(o);
            var picdata = {
                "annex_name": o.info.name, "datetime": o.info.dateTime, "make": o.info.make, "make_mode": o.info.makeMode, "gps": o.info.gps, "exif": o.info.exif, "amends": [
                    {
                        "client_id": NEWGuid(),
                        "base64": o.amend.base64,
                        "type": o.amend.type,
                        "width": o.amend.width,
                        "height": o.amend.height
                    }],
                "previews": [
                {
                    "client_id": NEWGuid(),
                    "base64": o.preview.base64,
                    "type": o.preview.type,
                    "width": o.preview.width,
                    "height": o.preview.height
                }]
            };
            var data = "[" + JSON.stringify(picdata) + "]";
            //console.log(o.amend.base64);
            //console.log(o.preview.base64);
            //MSFILE.ajax("application/json", self.data.ajaxUrl, data,
			//		function (t) {
			//		    if (typeof (upSuccess) != 'undefined') upSuccess(t, o);
			//		}, function (percent, loaded, total) {
			//		    if (typeof (upProgress) != 'undefined') upProgress(percent, o, loaded, total);
			//		}, function (s) {
			//		    if (typeof (upError) != 'undefined') upError(s, o);
			//		}
			//);
            self._goAjax(ele, "application/json", self.data.ajaxUrl, data, upSuccess, upProgress, upError, o)
        }, picObj)
    }
}

