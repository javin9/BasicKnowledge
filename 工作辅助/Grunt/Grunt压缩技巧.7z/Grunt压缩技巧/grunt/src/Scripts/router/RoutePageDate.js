// JavaScript Document

var RoutePageDate = {

    global: {
        indexPage: 'pageOur',			//	默认的跳转页面	
        errorPage: 'pageError',		//	无效HASH跳转的页 相当于404	
        canLogoutPage: ['login', 'shareCheck', 'reg1', 'reg2', 'reg3', 'start', 'pageBackPwd1', 'pageBackPwd2'],          // 没有登录也能访问的页面 （在没有key的情况下)
        pageMark: '?',				//	路由间隔符	
        mainTit: "主标题",			//	整个页面的标题
        templet: 'templet-1',		//	默认的页面模板名
        animT: 9,
        hisRecCacheKey: 'hisRecCacheKey',	//	历史记录保存在缓存中的键名
        logTimeCacheKey: 'perLoginTime',		//	用户登陆时间
        htmlFileExt: 'html',				//	html页面默认的文件类型
        htmlPath: '/template/PAGENAME/', //页面文件存放的路径。其中PAGENAME为特殊字符，代表页面名称
        jsPath: '/template/PAGENAME/',
        cssPath: '/template/PAGENAME/',
        LoCacheVerUrl: '/PLATFORM/index/version',	//用于页面级文件版本号文件的AJAX地址 
        LoCacheVName: 'LocalCacheVersion',	//保存	页面级文件版本号 的对象名称			
        preLoad: [						//页面预加载的文件。需要写绝对路其中PAGENAME、PLATFORM为特殊字符，代表页面名称及平台。文件在装载之前载入并运行。若需缓存请在LoCacheVerUrl中配置版本号。
            { url: '/PLATFORM/tool/xzb', type: 'js' }, { url: '/template/preLoad/p.js' }
            , { url: '/Style/PLATFORM.css' }
        ]
    },

    reg1: {
        templet: "templet-1",	///-
        //jsFile: ["/template/reg1/reg.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行reg1.js
        jsFile: ["reg1.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行reg1.js
        cssFile: ["/template/reg1/reg.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "注册",		///改为必填
        uninsExc: ["reg1"],
        mainTit: "注册"
    },

    reg2: {
        templet: "templet-1",	///-
        jsFile: ["reg2.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/reg1/reg.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "注册",		///改为必填
        uninsExc: ["reg2"],
        mainTit: "注册"
    },

    reg3: {
        templet: "templet-1",	///-
        jsFile: ["reg3.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/reg1/reg.css", "/template/pageIndentity/pageIndentity.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "注册",		///改为必填
        uninsExc: ["reg3"],
        mainTit: "注册"
    },

    start: {
        templet: "templet-1",	///-
        jsFile: ["start.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: [],		//CSS文件名，此处为空表示没有文件
        pageTit: "欢迎您",		///改为必填
        uninsExc: ["start"],
        inPage: true

    },

    login: {
        templet: "templet-1",	///-
        jsFile: ["login.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/reg1/reg.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "登录",		///改为必填
        uninsExc: ["login"],
        mainTit: "登录"
    },

    pageCarList: {
        templet: "templet-1",	///-
        jsFile: ["pageCarList.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageCarList/pageCarList.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "名片",
        uninsExc: ["pageCarList", "pageCarPhone1", "pageCarPhone2", "pageCarPhone3"]
    },

    pageCarName: {
        templet: "templet-1",	///-
        jsFile: ["/template/pageCarList/pageCarList.js", "pageCarName.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageCarList/pageCarList.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "名片",
        uninsExc: ["pageCarList"]

    },

    pageCarCom: {
        templet: "templet-1",	///-
        jsFile: ["/template/pageCarList/pageCarList.js", "pageCarCom.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageCarList/pageCarList.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "名片",
        uninsExc: ["pageCarList"]

    },

    pageCarJob: {
        templet: "templet-1",	///-
        jsFile: ["/template/pageCarList/pageCarList.js", "pageCarJob.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageCarList/pageCarList.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "名片",
        uninsExc: ["pageCarList"]
    },

    pageCarMail: {
        templet: "templet-1",	///-
        jsFile: ["/template/pageCarList/pageCarList.js", "pageCarMail.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageCarList/pageCarList.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "名片",
        uninsExc: ["pageCarList"]
    },

    pageCarWX: {
        templet: "templet-1",	///-
        jsFile: ["/template/pageCarList/pageCarList.js", "pageCarWX.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageCarList/pageCarList.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "名片",
        uninsExc: ["pageCarList"]
    },

    pageCarTell: {
        templet: "templet-1",	///-
        jsFile: ["/template/pageCarList/pageCarList.js", "pageCarTell.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageCarList/pageCarList.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "名片",
        uninsExc: ["pageCarList"]
    },

    pageCarAddress: {
        templet: "templet-1",	///-
        jsFile: ["/template/pageCarList/pageCarList.js", "pageCarAddress.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageCarList/pageCarList.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "名片",
        uninsExc: ["pageCarList"]
    },

    pageCarPhone1: {
        templet: "templet-1",	///-
        jsFile: ["/template/pageCarList/pageCarList.js", "pageCarPhone1.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageCarList/pageCarList.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "名片",
        uninsExc: ["pageCarList", "pageCarPhone1", "pageCarPhone2", "pageCarPhone3"]

    },

    pageCarPhone2: {
        templet: "templet-1",	///-
        jsFile: ["/template/pageCarList/pageCarList.js", "pageCarPhone2.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageCarList/pageCarList.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "名片",
        uninsExc: ["pageCarList", "pageCarPhone1", "pageCarPhone2", "pageCarPhone3"]

    },

    pageCarPhone3: {
        templet: "templet-1",	///-
        jsFile: ["/template/pageCarList/pageCarList.js", "pageCarPhone3.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageCarList/pageCarList.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "名片",
        uninsExc: ["pageCarList", "pageCarPhone1", "pageCarPhone2", "pageCarPhone3"]

    },

    pageCarUserImg: {
        templet: "templet-1",	///-
        jsFile: ["/template/pageCarList/pageCarList.js", "/template/pageCarUserImg/CanvasCrop.js", "/template/pageCarUserImg/Hammer.js", "pageCarUserImg.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageCarList/pageCarList.css", "/template/pageCarUserImg/CanvasCrop.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "名片",
        uninsExc: ["pageCarList"]

    },
    pageCarCheng: {
        templet: "templet-1",	///-
        jsFile: ["pageCarCheng.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        hisPop: false,
        cssFile: ["/template/pageCarList/pageCarList.css", "pageCarTag.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "成就标签",
        uninsExc: ["pageCarList"]
    },
    pageCarNeng: {
        templet: "templet-1",	///-
        jsFile: ["pageCarNeng.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        hisPop: false,
        cssFile: ["/template/pageCarList/pageCarList.css", "/template/pageCarCheng/pageCarTag.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "能力标签",
        uninsExc: ["pageCarList"]
    },
    pageSpace: {
        templet: "templet-3",	///-
        jsFile: ["/Scripts/swiper/swiper_jquery_min.js", "pageSpace.js"],		//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/swiper/swiper_min.css", "/template/pageExper/pageExper.css", "/template/pageSpace/pageSpace.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "空间",		///改为必填
        mainTit: "空间",
        uninImmedi: true,
        uninsExc: ["pageSpace"]
    },
    pageSpaceBiog: {
        templet: "templet-1",	///-
        jsFile: ["/Scripts/photoSwipe/photoswipe_min.js", "pageSpaceBiog.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/editor/editor.css", "/template/pageSpaceBiog/pageSpaceBiog.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "传记",		///改为必填
        mainTit: "传记",	///改为必填
        uninsExc: ["pageSpaceBiog"]

    },
    pageLiuyan: {
        templet: "templet-1",	///-
        jsFile: ["pageLiuyan.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["pageLiuyan.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "留言",		///改为必填
        mainTit: "留言",
        uninsExc: ["pageLiuyan"]
    },
    pageIndAdd: {
        templet: "templet-1",	///-
        jsFile: ["pageIndAdd.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageIndentity/pageIndentity.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "身份管理",		///改为必填
        mainTit: "添加身份",
        uninsExc: ["pageIndAdd"]
    },
    pageIndentity: {
        templet: "templet-1",	///-
        jsFile: ["pageIndentity.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ['pageIndentity.css'],		//CSS文件名，此处为空表示没有文件
        pageTit: "名片设置",		///改为必填
        mainTit: "身管理份",
        uninsExc: ["pageIndentity"]
    },
    pageSelecter: {
        templet: "templet-1",	///-
        jsFile: ["pageSelecter.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ['/template/pageIndentity/pageIndentity.css'],		//CSS文件名，此处为空表示没有文件
        pageTit: "筛选",		///改为必填
        mainTit: "筛选",
        uninsExc: []
    },
    pageBackPwd1: {
        templet: "templet-1",
        jsFile: ["pageBackPwd1.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行reg1.js
        cssFile: ["/template/reg1/reg.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "修改密码",		///改为必填
        uninsExc: ["pageBackPwd1"],
        mainTit: "修改密码"

    },
    pageBackPwd2: {
        templet: "templet-1",
        jsFile: ["pageBackPwd2.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行reg1.js
        cssFile: ["/template/reg1/reg.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "修改密码",		///改为必填
        uninsExc: ["pageBackPwd1", "pageBackPwd2"],
        mainTit: "修改密码"
    },
    pageExperEditor: {
        templet: "templet-1",
        jsFile: ["/Scripts/mobileData/mobiscroll_date.js", "/Scripts/mobileData/mobiscroll.js", "/Scripts/photoSwipe/photoswipe_min.js", "/Scripts/editPro/MSFILE.js", "/Scripts/editPro/editMobile.js", "pageExperEditor.js"],	//为空表示只有一个page同名JS文件。可以是多个
        cssFile: ["/Scripts/mobileData/mobiscroll.css", "/Scripts/editor/editor.css", "/template/pageExperEditor/pageExperEditor.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "",		///改为必填pageExperSet
        mainTit: "添加经历",
        uninsExc: ['pageExperSet', 'pageBiogList', 'pageExperEditor', 'pageSelecter']

    },
    pageExperSet: {
        templet: "templet-1",
        jsFile: ["pageExperSet.js"],	//为空表示只有一个page同名JS文件。可以是多个
        cssFile: ["pageExperSet.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "",		///改为必填
        mainTit: "经历完成",
        hisPop: false,
        uninsExc: ['pageExperSet', 'pageBiogList', 'pageExperEditor', 'pageSelecter']

    },

    pageRaleList: {
        templet: "templet-1",	///-
        jsFile: ["pageRaleList.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageExperSet/pageExperSet.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "记忆列表",		///改为必填
        uninsExc: ["pageRaleList"],
        mainTit: "记忆列表"
    },

    pageFigure: {
        templet: "templet-1",	///-
        jsFile: ["/Scripts/swiper/swiper_jquery_min.js", "pageFigure.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/swiper/swiper_min.css", "/template/pageFigure/pageFigure.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "人物",		///改为必填
        mainTit: "人物列表",
        uninsExc: ["*"]
    },

    pageAbout: {
        templet: "templet-1",	///-
        jsFile: ["pageAbout.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["pageAbout.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "关于",		///改为必填
        mainTit: "关于",
        uninsExc: [],
        mainTit: "关于"
    },

    pageAboutWord: {
        templet: "templet-1",	///-
        jsFile: ["pageAboutWord.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: [],		//CSS文件名，此处为空表示没有文件
        pageTit: "关于文章",		///改为必填
        mainTit: "关于文章",
        uninsExc: [],
        mainTit: "关于文章"
    },
    pagePwdSet: {
        templet: "templet-1",	///-
        jsFile: ["pagePwdSet.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: [],		//CSS文件名，此处为空表示没有文件
        pageTit: "修改密码",		///改为必填
        mainTit: "修改密码",
        uninsExc: [],
        mainTit: "修改密码"
    },
    pageFeed: {
        templet: "templet-1",	///-
        jsFile: ["pageFeed.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/reg1/reg.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "意见反馈",		///改为必填
        mainTit: "意见反馈",
        uninsExc: []
    },
    pageExperSee: {
        templet: "templet-1",	///-
        jsFile: ["/Scripts/photoSwipe/photoswipe_min.js", "pageExperSee.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/editor/editor.css", "/template/pageExperEditor/pageExperEditor.css", "/template/pageLiuyan/pageLiuyan.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "经历查看",		///改为必填
        uninImmedi: true,
        uninsExc: ['pageExperSee']
    },
    pageExperWither: {
        templet: "templet-1",	///-
        jsFile: ["/Scripts/photoSwipe/photoswipe_min.js", "/Scripts/editPro/MSFILE.js", "/Scripts/editPro/editMobile.js", "pageExperWither.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/editor/editor.css", "/template/pageExperEditor/pageExperEditor.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "同行",		///改为必填
        hisPop: false,
        uninsExc: ["pageBiogSumEditor"]

    },

    pageThing: {
        templet: "templet-2",	///-
        jsFile: ["/Scripts/swiper/swiper_jquery_min.js", "pageThing.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/swiper/swiper_min.css", "/template/pageFigure/pageFigure.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "有事",		///改为必填
        uninsExc: ["*"]

    },
    pageBiog: {
        templet: "templet-1",	///-
        jsFile: ["pageBiog.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageBiog/pageBiog.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "人物传记",		///改为必填
        uninsExc: ["pageBiog"],
        mainTit: "人物概述"
    },
    pageBiogSumEditor: {
        templet: "templet-1",	///-
        jsFile: ["/Scripts/photoSwipe/photoswipe_min.js", "pageBiogSumEditor.js", "/Scripts/editPro/MSFILE.js", "/Scripts/editPro/editMobile.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/editor/editor.css", "/template/pageExperEditor/pageExperEditor.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "人物概述",		///改为必填
        uninsExc: ["pageBiogSumEditor"],
        mainTit: "人物概述"
    },
    pageBiogSet: {
        templet: "templet-1",	///-
        jsFile: ["pageBiogSet.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageExperSet/pageExperSet.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "传记设置",		///改为必填
        uninsExc: ["pageBiogSet"],
        mainTit: "传记设置"
    },
    pageBiogList: {
        templet: "templet-1",	///-
        jsFile: ["pageBiogList.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageExperSet/pageExperSet.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "传记列表",		///改为必填
        hisPop: false,
        uninsExc: ['pageExperSet', 'pageBiogList', 'pageExperEditor', 'pageSelecter']

    },


    pageExper: {
        templet: "templet-1",	///-
        jsFile: ["/Scripts/swiper/swiper_jquery_min.js", "pageExper.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/swiper/swiper_min.css", "/template/pageExper/pageExper.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "记忆",		///改为必填
        uninsExc: ["*"]

    },
    pageActivityEditor: {
        templet: "templet-1",	///-
        jsFile: ["/Scripts/mobileData/mobiscroll_date.js", "/Scripts/mobileData/mobiscroll.js", "/Scripts/photoSwipe/photoswipe_min.js", "/Scripts/editPro/MSFILE.js", "/Scripts/editPro/editMobile.js", "pageActivityEditor.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/mobileData/mobiscroll.css", "/Scripts/photoSwipe/photoswipe.css", "/Scripts/editor/editor.css", "/template/pageExperEditor/pageExperEditor.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "填写活动",		///改为必填
        uninsExc: ["pageActivity", 'pageActivitySet', 'pageSelecter']

    },

    pageActivitySet: {
        templet: "templet-1",	///-
        jsFile: ["pageActivitySet.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageExperSet/pageExperSet.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "活动设置",		///改为必填
        hisPop: false,
        uninsExc: ["pageActivity", 'pageActivitySet', 'pageSelecter']

    },
    pageActivitySee: {
        templet: "templet-1",	///-
        jsFile: ["/Scripts/photoSwipe/photoswipe_min.js", "pageActivitySee.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/editor/editor.css", "/template/pageExperEditor/pageExperEditor.css", "/template/pageLiuyan/pageLiuyan.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "活动查看",		///改为必填
        uninImmedi: true

    },

    pageThingEditor: {
        templet: "templet-1",	///-
        jsFile: ["/Scripts/mobileData/mobiscroll_date.js", "/Scripts/mobileData/mobiscroll.js", "/Scripts/photoSwipe/photoswipe_min.js", "/Scripts/editPro/MSFILE.js", "/Scripts/editPro/editMobile.js", "pageThingEditor.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/mobileData/mobiscroll.css", "/Scripts/photoSwipe/photoswipe.css", "/Scripts/editor/editor.css", "/template/pageExperEditor/pageExperEditor.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "发布事情",		///改为必填
        uninsExc: ["pageThingEditor", 'pageExperSet', 'pageThingTagSet', 'pageSelecter']

    },

    pageThingSet: {
        templet: "templet-1",	///-
        jsFile: ["pageThingSet.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageExperSet/pageExperSet.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "事情设置",		///改为必填
        hisPop: false,
        uninsExc: ["pageExperSet"]

    },

    pageThingTagSet: {
        templet: "templet-1",	///-
        jsFile: ["pageThingTagSet.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageThingTagSet/pageThingTagSet.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "醒目标签",		///改为必填
        uninsExc: ["pageThingEditor", 'pageExperSet', 'pageThingTagSet', 'pageSelecter']

    },
    pageThingSee: {
        templet: "templet-1",	///-
        jsFile: ["/Scripts/photoSwipe/photoswipe_min.js", "pageThingSee.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/editor/editor.css", "/template/pageExperEditor/pageExperEditor.css", "/template/pageLiuyan/pageLiuyan.css", "/template/pageSpace/pageSpace.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "事情查看",		///改为必填
        uninImmedi: true
    },

    pageOur: {
        templet: "templet-1",	///-
        jsFile: ["pageOur.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageOur/pageOurtmp.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "我的",		///改为必填
        uninsExc: ["*"]
    },
    pageBiogEditor: {
        templet: "templet-1",	///-
        jsFile: ["/Scripts/photoSwipe/photoswipe_min.js", "pageBiogEditor.js", "/Scripts/editPro/MSFILE.js", "/Scripts/editPro/editMobile.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/Scripts/photoSwipe/photoswipe.css", "/Scripts/editor/editor.css", "/template/pageExperEditor/pageExperEditor.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "发布事情",		///改为必填
        uninsExc: ["pageThingEditor"]
    },
    pageExperOrder: {
        templet: "templet-1",	///-
        jsFile: ["pageExperOrder.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageExperOrder/pageExperOrder.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "时刻",		///改为必填
        uninsExc: ["*"]

    },
    pageMessage: {
        templet: "templet-1",	///-
        jsFile: ["pageMessage.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageMessage/pageMessage.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "消息列表",		///改为必填
        uninsExc: ["pageMessage"]

    },
    pageMesCont: {
        templet: "templet-1",	///-
        jsFile: ["pageMesCont.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageMesCont/pageMesCont.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "消息详情",		///改为必填
        uninsExc: ["pageMesCont"]

    },
    pageError: {
        templet: "templet-1",	///-
        jsFile: ["pageError.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageError/pageError.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "",		///改为必填
        uninsExc: ["pageError"]

    },
    shareCheck: {
        templet: "templet-1",
        pageTit: "分享",		///改为必填
        hisPop: false

    },
    pageOrg: {
        templet: "templet-1",	///-
        jsFile: ["pageOrg.js"],	//为空表示只有一个page同名JS文件。可以是多个，多个则按顺序加载并运行
        cssFile: ["/template/pageOrg/pageOrg.css"],		//CSS文件名，此处为空表示没有文件
        pageTit: "组织",		///改为必填
        uninsExc: ["pageOrg"]

    }
}