// 页面级文件版本号

LocalCacheVersion = {
    //page1_js: 1.2,
    //pageExper_js: 1.0,
    //pageExper_css: 1.0,
    //pageExper_html: 1.0,
    //pageThing_js: 1.0,
    //pageThing_css: 1.0,
    //pageThing_html: 1.0,
    //pageFigure_js: 1.0,
    //pageFigure_css: 1.0,
    //pageFigure_html: 1.0
	}