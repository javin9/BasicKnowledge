/*jslint eqeq: true, sloppy: true*/
/* v0.78 修改了isMobile MSEvent中的一些小bug
0.6 SLIDEMenu  增加了验证this.type
0.5 整核了事件，事件暂时没有卸载机制禁用浏览器属性 添加了'self'参数值，卸载事件支持编号卸载及deep参数
0.4添加了卸载事件
 */

var S = function (s, p) {
    return new S.prototype.init(s, p);
},
	SS = function (s, p) {
	    return S(s, p).t;
	};
(function () {
    S.prototype = {
        /* class 操作类 */
        addClass: function (s) {
            this.eleEach(function (it) {
                it.classList.add(s);
            });
            return this;
        },
        // 移除calss
        delClass: function (s) {
            this.eleEach(function (it) {
                it.classList.remove(s);
            });
            return this;
        },
        // 切换calss
        togClass: function (s) {
            this.eleEach(function (it) {
                it.classList.toggle(s);
            });
            return this;
        },
        // 是否含有calss
        haveClass: function (s) {
            return this.t.classList.contains(s);
        },
        // 是否匹配calss
        matchClass: function (s) {
            var con = this.eleEach(function (it) {
                if (it.matchesSelector) {
                    return it.matchesSelector(s);
                } else if (it.msMatchesSelector) {
                    return it.msMatchesSelector(s);
                } else if (it.mozMatchesSelector) {
                    return it.mozMatchesSelector(s);
                } else if (it.webkitMatchesSelector) {
                    return it.webkitMatchesSelector(s);
                }
            });
            return con;
        },

        /* DOM 获取类 */

        //获取元素
        get: function () {
            return this.t;
        },

        //父元素
        parent: function () {
            if (this.type == 'ele') {
                this.t = this.t.parentNode;
            }
            return this;
        },

        //上一个元素
        preEle: function () {
            if (this.type == 'ele') {
                this.t = this.t.previousElementSibling;
            }
            return this;
        },

        //下一个元素
        nextEle: function () {
            if (this.type == 'ele') {
                this.t = this.t.nextElementSibling;
            }
            return this;
        },

        //子元素（仅返回nodeType=1)  | S().child() 所有子元素 | .child(0) 第一个子元素 ｜ .child(-1) 最后一个 ｜ .child(-2)从后往前数第2个
        child: function (i) {
            if (this.type != 'ele') {
                return;
            }
            var o = this.t.children;
            if (typeof (i) === 'undefined') {
                this.t = o;
            } else if (typeof (i) === 'number' && i < o.length) {
                if (i > -1) {
                    this.t = o[i];
                } else if (i <= o.length + i) {
                    this.t = o[o.length + i];
                }
            }
            return this;
        },

        //DOM 方法

        //删除元素；
        removeEle: function () {
            this.eleEach(function (it) {
                it.parentNode.removeChild(it);
            });
            return this;
        },
        //在某元素之前插入S.t   参数Ele元素之前
        insertBefore: function (ele) {
            this.eleEach(function (it) {
                ele.parentNode.insertBefore(it, ele);
            });
            return this;
        },
        //在某元素之后插入S.t   参数Ele元素之后
        insertAfter: function (ele) {
            this.eleEach(function (it) {
                var p = ele.parentNode;
                if (p.lastChild == ele) {
                    p.appendChild(it);
                } else {
                    p.insertBefore(it, ele.nextElementSibling);
                }
            });
            return this;
        },
        //遍历方法
        //通用操作方法
        /*事件方法*/
        on: function (evName, backFun, selector, paraObj) {
            this.eleEach(function (it) {
                MSEvent.add(it, evName, backFun, selector, paraObj);
            });
        },

        //其他方法
        eleEach: function (fn) {
            var c = true,
			i,
			l;
            if (this.type == 'eleArr') {
                for (i = 0, l = this.t.length; i < l; i++) {
                    if (fn(this.t[i]) === false)
                        c = false;
                }
            } else if (this.type == 'ele') {
                c = fn(this.t);
            }
            return c;

        },

        //AJAX方法

        init: function (s, cont) {
            var r = null,
			type = 'ele',
			p = cont || document;
            if (typeof s === 'string') {
                //如果是id
                if (!/[\:\s\.\+\~\=\>\[]/.test(s) && s.charAt(0) === '#') {
                    r = p.getElementById(s.substr(1));
                } else {
                    r = p.querySelectorAll(s);
                    if (r.length === 0) {
                        r = null;
                        type = '';
                    } else if (r.length === 1) {
                        r = r[0];
                    } else {
                        type = 'eleArr';
                    }
                }
            } else if (typeof s === 'object') {
                if (!!s && !!s.nodeType) {
                    r = s;
                } else {
                    r = null;
                }
            }
            this.t = r;
            this.type = type; // null:'', ele:'ele', [ele]:'eleArr'
        }

    };

    S.prototype.init.prototype = S.prototype;

    function each(o, Fn) {
        if (o === null)
            return;
        var c = true;
        if (!!o[0]) {
            for (var i = 0, l = o.length; i < l; i++) {
                if (Fn(o[i]) === false)
                    c = false;
            }
        } else {
            c = !!Fn(o);
        }
        return c;
    }

}());



/* 获得用户设备信息
* @return dev		设备信息：“PC","Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"
* @return os		操作系统信息
* @return wx		是否使用微信。如果不是返回false 如果是返回版本号
* @return brows	浏览器信息
*/
function GETUserDev() {
    var ua = navigator.userAgent,
		ua1 = ua.match(/\((\S| )+?\)/)[0], //第一个括号里面的	
		uA = ua1.split(';'),
		browReg = /(Firefox|QQBrowser|MQQBrowser|UCBrowser|Edge|Chrome|Safari)\/\d+(\.\d+)*/,
		devArr = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"),
		reg = /MicroMessenger\/\d+(\.\d+)+/,
		dev = "PC", os, wx, brows, i, l;
    for (i = 0, l = uA.length; i < l; i++) {
        uAit = uA[i].replace('(', '').replace(')', '');
        if (/^Windows/.test(uAit) || /Android \d\.\d(\.\d)?/.test(uAit)) {
            os = uAit;
        } else if (/OS \d_\d(_\d)? like Mac OS X/.test(uAit)) {
            os = uAit.replace('CPU ', '').replace(' like Mac OS X', '');
        }
    }
    for (i = 0, l = devArr.length; i < l; i++) {
        if (ua.indexOf(devArr[i]) > 0) {
            dev = devArr[i];
            break;
        }
    }
    brows = (browReg.test(ua)) ? ua.match(browReg)[0] : '';
    wx = (reg.test(ua)) ? ua.match(reg)[0].replace('MicroMessenger/', '') : false;
    return { dev: dev, os: os, wx: wx, brows: brows };
}
/* 用户是否使用移动设备 返回true false */
function IsMobile() { return (GETUserDev().dev == 'PC') ? false : true; }
function IsWeixin() { return GETUserDev().wx; }
var E = {
    Add: function (o, t, h, b) {
        if (o.addEventListener) {
            o.addEventListener(t, h, !!b);
        } else {
            o.attachEvent("on" + t, h);
        }
    },
    Remove: function (o, t, h) {
        if (o.removeEventListener) {
            o.removeEventListener(t, h, false);
        } else {
            o.detachEvent("on" + t, h);
        }
    },
    Target: function (e) {
        return e.target || e.srcElement;
    },
    Event: function (e) {
        return e ? e : window.event;
    },
    CancelAction: function (e) {
        if (e.preventDefault) {
            e.preventDefault();
        } else {
            e.returnValue = false;
        }
    },
    StopBub: function (e) {
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
    }
};

//生成Guid newGuid
function NEWGuid() {
    var guid = "";
    for (var i = 1; i <= 32; i++) {
        guid += Math.floor(Math.random() * 16.0).toString(16);
        if ((i == 8) || (i == 12) || (i == 16) || (i == 20))
            guid += "";
    }
    return guid;
}
function REPLACE(s, s1, s2) {
    if (!s)
        return false;
    if (!!s1) {
        while (s.indexOf(s1) > -1) {
            s = s.replace(s1, s2);
        }
    }
    return s;
}
function GetUrlPara(key, url) {
    var u = url || location.href,
	p = (u.lastIndexOf('?') > -1) ? u.substring(u.lastIndexOf('?') + 1) : '',
	a = p.split('&'),
	i,
	l;
    for (i = 0, l = a.length; i < l; i++) {
        if (a[i].indexOf('=') > -1) {
            if (key == a[i].substring(0, a[i].indexOf('='))) {
                return decodeURIComponent(a[i].substr(a[i].indexOf('=') + 1));
            }
        }
    }
    return '';
}
function RemoveUrlParam(key, url) {
    if (!key) return;
    var u = url || location.href,
	p = u.lastIndexOf('?'),//(u.lastIndexOf('?') > -1) ? u.substring(u.lastIndexOf('?') + 1) : '',
	ut, a, i, l;
    if (p === -1) { return u; }
    ut = u.substring(0, p + 1);
    p = u.substring(u.lastIndexOf('?') + 1);
    a = p.split('&');
    for (i = 0, l = a.length; i < l; i++) {
        if (a[i].indexOf('=') > -1 && key == a[i].substring(0, a[i].indexOf('='))) {
            a.splice(i, 1);
            i--;
            l--;
        }
    }
    ut += a.join('&');
    if (ut.charAt(ut.length - 1) === "?") { ut = ut.substr(0, ut.length - 1); }
    return ut;
}

function TRIM(s, t) {
    t = t || 0;
    if (!s)
        return "";
    return t == 1 && s.replace(/(^\s*)/g, "") || t == 2 && s.replace(/(\s*$)/g, "") || s.replace(/(^\s*)|(\s*$)/g, "");
}

/*
/////////////////////////////////////////////////////////////MsEvent PART1:MsTouchEvent  V1.2 2016/1/11////////////

///////////////////////////////////////////////////////////////////

///-----------------------------------------------------

 * add添加事件
 *  @ param deleEle Ele.是 为空则为：document
 *  @ param evName Str.是 longtouch touchend slide //touchstart
 *  @ param backFun Fun.是
 *  @ param selector Str.否 为空则 = delEle
 *  @ param moreParam Obj.否 有默认值
 * offDef 禁用浏览器 默认为true
 * canCap 事件支持捕获 默认为true
 * ingFn 过程中的函数（仅用于slide)
 * single 是否执行绑定在该元素上的其他事件 默认为true
 * direc 滑动产生作用的方向（仅用于slide)支持left(默认）、right、up、down，且后四个可以组合使用。例如：direc : 'left right', 表示左右滑动时触发
 *  @ return index Str 返回事件编号。
 *

 * remove 删除事件
 *  @ param deleEle Ele.是 为空则为：document
 *  @ param selector Str.否 为空则 = delEle
 *  @ return
 *

_Arr : {

_dEindex :
[
evName : evName, //Str 事件类型
backFun : backFun, //Fun 回调
selector : selector || '', //Str 事件选择器 符合CSS选择器 伪类除外
offDef : (typeof(moreParam.offDef) == 'undefined') ? 'self' : moreParam.offDef, //boo 是否禁用浏览器默认事件
canCap : (typeof(moreParam.canCap) == 'undefined') ? true : moreParam.canCap, // boo 是否可以冒泡
ingFn : moreParam.ingFn //Fun 回调，应用于滑动事件中move时的回调方法 (仅移动事件有)
]
deleEle : 委托的元素
},
}
 */
var MSEvent = {

    _mp: {
        ChangAnTime: 1000, //长按时间值
        tP1: 5, //阀值1   移动小于这个值，都算是点击
        tP2: 10, //阀值2   移动小于这个值，且时间小于tpt2才算点击，否则算滑动
        tPt2: 250, //时间阀值
        tPt3: 800 //超过这个时间，则不算是点击或者滑动（不含拖）
    },

    _p: {
        t1: {},
        x: 0,
        y: 0,
        changAnTime: {},
        stopMove: true
    },
    _mobileEventName: function (i) {
        var eName = [];
        if (IsMobile() && !!('ontouchstart' in document)) {
            eName[0] = "touchstart";
            eName[1] = "touchend";
            eName[2] = "touchmove";
        } else {
            eName[0] = "mousedown";
            eName[1] = "mouseup";
            eName[2] = "mousemove";
        }
        return eName[i];
    },
    _indexMobile: 0,
    _arrMobile: {}, //记录移动事件
    _indexOther: 0,
    _arrOther: {}, //记录非移动事件
    _singleEv: { //记录屏蔽其他事件的，boss事件
        Other: [],
        Mobile: [],
        id: 1
    },
    /*{
	Other:[{},{},{}],
	Mobile:[{},{},{}]
	} ele evName selector

	 */

    add: function (deleEle1, evName, backFun, selector, moreParam1) {
        if (!evName || typeof (backFun) != 'function')
            return;
        var deleEle = deleEle1 || document,
		evType = 'Mobile',
		dEindex,
		moreParam = moreParam1 || {},
		o = {
		    evName: evName,
		    backFun: backFun,
		    selector: selector || '',
		    offDef: (typeof (moreParam.offDef) == 'undefined') ? 'self' : moreParam.offDef,
		    canCap: (typeof (moreParam.canCap) == 'undefined') ? true : moreParam.canCap,
		    single: (typeof (moreParam.single) == 'undefined') ? false : moreParam.single,
		    ingFn: moreParam.ingFn
		};
        switch (evName) {
            case 'touchend':
                o.evName = '10';
                break;
            case 'longtouch':
                o.evName = '20';
                break;
            case 'slide':
                o.evName = '';
                if (!!moreParam.direc) {
                    moreParam.direc = moreParam.direc.toLowerCase();
                    o.evName += (!!moreParam.direc.match('left')) ? '31' : '';
                    o.evName += (!!moreParam.direc.match('right')) ? '32' : '';
                    o.evName += (!!moreParam.direc.match('up')) ? '33' : '';
                    o.evName += (!!moreParam.direc.match('down')) ? '34' : '';
                } else {
                    o.evName = '31';
                }
                break;
            default:
                evType = 'Other';
        }
        //添加事件，获取事件编号
        if (evType == 'Mobile') {
            for (var i = 0; i < 3; i++)
                deleEle.addEventListener(MSEvent._mobileEventName(i), MSEvent._touchHandle, false);
            dEindex = deleEle.dataset.mseventMobile || '_' + this._indexMobile++;
            //if ( !o.single ) deleEle.dataset.mseventSingleev = o.evName; //////////////////////////////////////////////////////////////////////////////////////
        } else {
            deleEle.addEventListener(evName, MSEvent._otherHandle, false);
            dEindex = deleEle.dataset.mseventOther || '_' + this._indexOther++;
            delete o.ingFn;
        }
        //处理数组
        if (typeof (this['_arr' + evType][dEindex]) == 'undefined') {
            this['_arr' + evType][dEindex] = [];
            this['_arr' + evType][dEindex].deleEle = deleEle;
            deleEle.dataset['msevent' + evType] = dEindex;
        }
        if (evType == 'Other') {
            if (typeof (this._arrOther[dEindex].eventList) == 'undefined')
                this._arrOther[dEindex].eventList = {};
            if (typeof (this._arrOther[dEindex].eventList[evName]) == 'undefined') {
                this._arrOther[dEindex].eventList[evName] = 1;
            } else {
                this._arrOther[dEindex].eventList[evName] += 1;
            }
        }
        this['_arr' + evType][dEindex].push(o);

        //用于添加顶级事件，这个事件会阻断其他事件的发生。
        if (!!o.single) {
            this._singleEv[evType].push({
                //                evT: evType,
                //                id: dEindex,
                //                eid: this['_arr' + evType][dEindex].length - 1,
                id: this._singleEv.id, //ID用于删除事件时方便索引
                ele: deleEle,
                evName: o.evName,
                selector: o.selector
            });
            o.single = this._singleEv.id++;
        }

        return evType + "|" + dEindex + "|" + (this['_arr' + evType][dEindex].length - 1);
    },
    /* remove 删除事件
	 * @param deleEle	Ele | str.	要删除事件的一个ELE，或者是一个事件编号。（事件编号由add时返回得到)。如果是一个事件编号，下面两个参数无效；
	 * @param selector	Str.	空	selector, 为空则删除该元素下的所有事件,传值时会删除该元素下的 符合CSS选择符的事件。
	 * @param deep		Boo.	否	是否将子元素也删除。注意，selector对子元素也起作用
	 * @return
	 */
    remove: function (deleEle, selector, deep) {
        var oa = [],
		o = {},
		it,
		a = [],
		ele;
        if (deleEle.nodeType != 1)
            return;
        this._removeOneMobile(deleEle, selector);
        this._removeOneOther(deleEle, selector);
        if (!!deep) { //遍历对象，只要是deleEle的子元素则
            o = this._arrMobile;
            for (it in o) {
                if (deleEle.contains(o[it].deleEle))
                    this._removeOneMobile(o[it].deleEle, selector);
            }
            o = this._arrOther;
            for (it in o) {
                if (deleEle.contains(o[it].deleEle))
                    this._removeOneOther(o[it].deleEle, selector);
            }
        }
        //}
    },
    _removeOneOther: function (deleEle, selector) {
        var dEindex = deleEle.dataset.mseventOther,
		o = {},
		i,
		l,
		it;
        if (!dEindex)
            return;
        o = this._arrOther[dEindex];
        if (!o)
            return;
        if (!!selector) {
            for (i = 0, l = o.length; i < l; i++) {
                if (o[i].selector == selector) {
                    o.eventList[o[i].evName] -= 1;
                    if (o.eventList[o[i].evName] === 0) {
                        deleEle.removeEventListener(o[i].evName, MSEvent._otherHandle, false);
                        delete o.eventList[o[i].evName];
                    }
                    o.splice(i, 1);
                    i--;
                    l--;
                }
            }
        } else {
            for (it in o.eventList) {
                deleEle.removeEventListener(it, MSEvent._otherHandle, false);
            }
        }
        if (!selector || o.length === 0) {
            delete this._arrOther[deleEle.dataset.mseventOther];
            delete deleEle.dataset.mseventOther;
        }
    },
    _removeOneMobile: function (deleEle, selector) {
        var dEindex = deleEle.dataset.mseventMobile,
		o = {},
		i;
        if (!dEindex)
            return;
        o = this._arrMobile[dEindex];
        if (!o)
            return;
        //if (!!selector) {
        for (i = 0, l = o.length; i < l; i++) {
            if (!selector || o[i].selector == selector) {
                if (!!o[i].single)
                    this._removeSingle('Mobile', o[i].single);
                o.splice(i, 1);
                i--;
                l--;
            }
        }
        //}
        if (o.length === 0) { //!selector || o.length == 0
            //delete this._arrMobile[deleEle.dataset.mseventMobile];
            delete deleEle.dataset.mseventMobile;
            for (i = 0; i < 3; i++)
                deleEle.removeEventListener(MSEvent._mobileEventName(i), MSEvent._touchHandle, false);
        }
    },
    //对于o.single属性为真的, 删除数组项
    _removeSingle: function (evType, index) {
        var a = this._singleEv[evType],
		i,
		l;
        for (i = 0, l = a.length; i < l; i++) {
            if (a[i].id == index) {
                a.splice(i, 1);
                return;
            }
        }
    },

    offDef: function (e, self, offDef, evType) {
        var t = e.target || e.srcElement;
        if (offDef === true || offDef == 'self' && self == t) {
            MSEvent._offDef(e);
            //log(e.type);
            //self.addEventListener(e.type, MSEvent._offDef, false);
            //if ( evType=='Mobile' ) self.addEventListener('click', MSEvent._offDef, false);
        } //else {
        //self.removeEventListener(e.type, MSEvent._offDef, false);
        //if ( evType=='Mobile' ) self.removeEventListener('click', MSEvent._offDef, false);
        //}
    },
    _offDef: function (e) {
        if (e.preventDefault) {
            e.preventDefault();
        } else {
            e.returnValue = false;
        }
    },

    _otherHandle: function (e) {
        var deleEle = e.currentTarget || this,
		target = e.target || e.srcElement,
		deleId = deleEle.dataset.mseventOther,
		self,
		eO = {},
		eArrO = {},
		i,
		l,
		o;
        if (MSEvent._arrOther[deleId] == 'undefined') {
            return;
        } else {
            eArrO = MSEvent._arrOther[deleId];
        }
        for (i = 0, l = eArrO.length; i < l; i++) {
            o = eArrO[i];
            self = MSEvent._eIs(target, o, eArrO.deleEle);
            if (self === false || (!o.canCap) && self != target)
                continue;
            //判断你级元素是否有single=false的事件。
            if (MSEvent._isParentSingleEv('Other', deleEle, target, o.evName))
                continue;
            MSEvent.offDef(e, self, o.offDef, 'Other'); //浏览器默认事件处理
            o.backFun(e, {
                target: target,
                self: self,
                dele: deleEle
            });
        }
    },

    _isParentSingleEv: function (evType, ele, target, evName) {
        var arr = MSEvent._singleEv[evType],
		i,
		j;
        for (i = 0, l = arr.length; i < l; i++) {
            if (MSEvent._eIs(target, {
                selector: arr[i].selector
            }, arr[i].ele) && ele != arr[i].ele && arr[i].evName == evName)
                return true;
        }
        return false;
    },

    _touchHandle: function (e) {
        var deleEle = e.currentTarget || this,
		self,
		eO = {},
		tt,
		diffX,
		diffY,
		t2 = {},
		target = e.target || e.srcElement,
		deleId = deleEle.dataset.mseventMobile,
		handle = function (o, f) {
		    t2 = new Date();
		    tt = t2.getTime() - MSEvent._p.t1.getTime();
		    diffX = ee.clientX - MSEvent._p.x;
		    diffY = ee.clientY - MSEvent._p.y;
		    if (!!o.evName.match(MSEvent._pd(tt, diffX, diffY))) {
		        if (o.evName != '10')
		            MSEvent._offDef(e);
		        eO.target = target;
		        eO.self = self;
		        eO.t = tt;
		        eO.eArr = o;
		        eO.x = ee.clientX;
		        eO.y = ee.clientY;
		        eO.diffX = diffX;
		        eO.diffY = diffY;
		        if (!!o[f])
		            o[f](e, eO);
		    }
		},
		eArrO = {},
		o = [],
		i,
		l,
		ee = e;

        if (MSEvent._arrMobile[deleId] == 'undefined') {
            return;
        } else {
            eArrO = MSEvent._arrMobile[deleId];
        }

        for (i = 0, l = eArrO.length; i < l; i++) {
            o = eArrO[i];
            self = MSEvent._eIs(target, o, eArrO.deleEle);

            if (self === false || (!o.canCap) && self != target)
                continue;

            //判断你级元素是否有single=false的事件。
            if (MSEvent._isParentSingleEv('Mobile', deleEle, target, o.evName))
                continue;
            //if ( !!self.dataset.dataRouteMustlogin) continue;

            //处理单指
            if (IsMobile()) {
                if (e.touches.length > 1) {
                    return;
                } else {
                    ee = e.changedTouches[0];
                }
            }

            //阻止浏览器默认事件
            switch (e.type) {
                case MSEvent._mobileEventName(0):
                    MSEvent.offDef(e, self, o.offDef, 'Mobile'); //浏览器默认事件处理
                    MSEvent._p.t1 = new Date();
                    MSEvent._p.x = ee.clientX;
                    MSEvent._p.y = ee.clientY;
                    MSEvent._p.stopMove = false;
                    if (o.evName == '20') { //如果设定的是长按，
                        (function (ii, ee, t, self, deleEle) {
                            MSEventChangAnTimer = setTimeout(function () {
                                eArrO[ii].backFun(e, {
                                    x: ee.clientX,
                                    y: ee.clientY,
                                    target: t,
                                    self: self,
                                    dele: deleEle
                                });
                            }, MSEvent._mp.ChangAnTime);
                        })(i, ee, target, self, deleEle);
                    }
                    break;
                case MSEvent._mobileEventName(1):
                    if (typeof (MSEventChangAnTimer) != 'undefined')
                        clearTimeout(MSEventChangAnTimer);
                    handle(o, 'backFun');
                    MSEvent._p.stopMove = true;
                    break;
                case MSEvent._mobileEventName(2):
                    if (MSEvent._p.stopMove)
                        break;
                    handle(o, 'ingFn');
                    if (((Math.abs(ee.clientX - MSEvent._p.x) > MSEvent._mp.tP2 || Math.abs(ee.clientY - MSEvent._p.y) > MSEvent._mp.tP2)) && !!MSEvent._p.changAnTimer) {
                        clearTimeout(MSEventChangAnTimer);
                    }
                    break;
            }
            if (!!o.single)
                break;
        }
    },

    _eIs: function (t, o, p) {
        if (o.selector === '')
            return p;
        while (!!t && t != p.parentNode) {
            if (S(t).matchClass(o.selector)) {
                return t;
            }
            t = t.parentNode;
        }
        return false;
    },

    //判断用户意图是点击，还是滑动的方法。返回一个数字型值。这里只检测5种：10-点击；20-长按；31-左拖；32-右拖;33-上拖；34-下拖
    _pd: function (t, x, y) {
        var dx = Math.abs(x),
		dy = Math.abs(y),
		dm = Math.max(dx, dy),
		r;
        if ((t < MSEvent._mp.tPt3 && dm < MSEvent._mp.tP1) || (dm < MSEvent._mp.tP2 && t < MSEvent._mp.tPt2)) {
            r = '10';
        } else {
            if (dx > dy) {
                r = (x < 0) ? '31' : '32';
            } else {
                r = (y < 0) ? '33' : '34';
            }
        }
        return r;
    }

};

/*
 * 滑动菜单插件 V0.1
 * @pEle     外层DIV元素，若有元素在页面中滚动，应该是滚动的那个元素
 * @selector CSS选择符，表示在pEle元素之下，在哪个元素下起作用
 * @dataArr  数据对象。对象中的每一个属性都是一个数组。数组中的每一项都是菜单的一个按钮。{
begin:[], //begin所有类型都会添加到前面
end:[],   //end所有类型都会添加到后面
//以下是自定义类型，这个类型会根据 pEle之下的，符合css选择符的元素的，dataset.slidemnType属性匹配
cus1: [],
cus2:
[{
title :　‘’，
css　：　‘’，
fn　：　Fun //传入参数： selectorEle, SLIDEMenu对象，eo对象（注意是菜单点击的EO对象，不是slide的)
},{
title :　‘’，
css　：　‘’，
fn　：　Fun
}
]

}
 * @htmlDatesetName dataArr中与HTML对应的dataset属性。选填，默认值为 data-slidemn-type
 */
//var SLIDEMenuEle = null;
var kkkkkk = 1;
function SLIDEMenu(pEle, selector, dataArr, htmlDatesetName) {
    if (!!pEle.dataset.SLIDEMenu) return;
    this.pEle = pEle || document;   //外层元素   
    this.tCss = selector;           //起作用的CSS选择符
    this.data = dataArr;            //数据对象
    //if (!SLIDEMenuEle) { SLIDEMenuEle = document.createElement('div'); SLIDEMenuEle.className = 'SLIDEMenu'; }
    S('.SLIDEMenu', pEle).removeEle();
    this.menu = document.createElement('div');
    this.menu.id = kkkkkk++;
    this.menu.className = 'SLIDEMenu';
    this.htmlDataName = htmlDatesetName || 'slidemnType';
    pEle.appendChild(this.menu);
    this.init();
    this.pEle.dataset.SLIDEMenu = true;
}

SLIDEMenu.prototype = {

    init: function () {
        var self = this;

        //添加滑动事件
        S(this.pEle).on('slide', function (e, eo) {
            //创建菜单
            delete self.menu.dataset.SLIDEMworking;
            if (eo.diffX < -40) { self.menu.style.width = self._menuWidth + 'px'; } else { self.menu.style.width = '0px'; }
        }, this.tCss, {
            direc: 'left',
            offDef: false,
            ingFn: function (e, eo) {
                if (!self.menu.dataset.SLIDEMworking) {
                    self._creatMenu(eo.self);
                    self.menu.dataset.SLIDEMworking = true;
                    self._getMenuWidth(eo.self);
                }
                if (-eo.diffx < self._menuWidth) self.menu.style.width = -eo.diffX + 'px';
            }
        });

        //添加关闭菜事件
        S(this.pEle).on('touchend', function (e, eo) {
            var t = E.Target(e);
            if (!self.menu.contains(t) || !t.dataset.touchkeep && !t.parentNode.dataset.touchkeep) self.menu.style.width = '0px';
        });
    },

    //记录当前菜单的按钮项
    _getMenuWidth: function (seleEle) {
        //var one = 56, list = S(this.menu).child().t, i, count = 0; for (i=list.length;i--;) { if (list[i].style.display != 'none' ) count++ }
        //this._menuWidth = one * count;
        this._menuWidth = seleEle.offsetWidth;
    },
    _menuWidth: 0,

    _creatMenu: function (t) { //text css fn        
        var eleItem, h = t.offsetHeight;
        this.menu.innerHTML = '';
        this._menuEleItem = [];
        if (!!this.data.begin) this._creatMenuOne('begin', t);
        if (!!t.dataset[this.htmlDataName] && !!this.data[t.dataset[this.htmlDataName]]) {
            this._creatMenuOne(t.dataset[this.htmlDataName], t);
        }
        if (!!this.data.end) this._creatMenuOne('end', t);
        this._itemDisplay(t);
        this.menu.style.height = h + 'px';
        this.menu.style.top = this._getTop(t);
    },

    _creatMenuOne: function (p, target) {
        var arr = this.data[p],
            slideObj = this, eleIt, i, l, it, classA, ci, cl;
        if (!arr) return;
        for (i = 0, l = arr.length; i < l; i++) {
            it = arr[i];
            eleIt = document.createElement('div');
            eleIt.innerHTML = '<span>' + it.title + '</span>';
            eleIt.className = 'SLIDEMenu-item';
            if (!!it.touchkeep) eleIt.dataset.touchkeep = 'true';
            if (it.display !== undefined) eleIt.dataset.display = it.display;
            if (!!it.css) {
                classA = it.css.split(' ');
                for (ci = 0, cl = classA.length; ci < cl; ci++) S(eleIt).addClass(classA[ci]);
            }
            this._menuEleItem.push(eleIt);
            (function (it, eleIt) {
                S(eleIt).on('touchend', function (e, eo) {
                    it.fn(target, slideObj, eo);
                    slideObj._itemDisplay(target);

                }, '', { offDef: false });
            })(it, eleIt);
            this.menu.appendChild(eleIt);
        }
    },

    _itemDisplay: function (seleEle) {
        var mList = S(this.menu).child().t,
            i, l, m, ix,
            so = S(this.tCss, this.pEle),
            sE = (so.type == 'ele') ? [so.t] : so.t;
        for (i = 0, l = mList.length; i < l; i++) {
            m = mList[i];
            ix = parseInt(m.dataset.display);
            if (!isNaN(ix) && sE[(ix < 0) ? sE.length + ix : ix] == seleEle) {
                m.style.display = 'none';
            } else {
                m.style.display = 'inline';
            }
        }
    },

    _getTop: function (t) { return t.getBoundingClientRect().top - this.pEle.getBoundingClientRect().top + this.pEle.scrollTop + 'px'; }

};