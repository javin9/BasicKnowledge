/*jslint devel: true, white: true, bitwise: true, continue: true, debug: true, eqeq: true, evil: true, forin: true, newcap: true, nomen: true, plusplus: true, regexp: true, unparam: true, sloppy: true, sub: true, vars: true, maxerr: 1000*/

/* R.js 路由
 *    version        :     V0.92 改了一系列小bug
 *    lastModTime    :    Jan.5, 2016

 *    更新说明        ：
 V0.85 配置分享和微信验证，改了init。 修改了版本控制文件缓存key写死了的bug
V0.75 配置文件里添加了uninImmedi （立即卸载) 值为true | false
V0.73 本地缓存文件请求，加了时间戳
V0.72
改变了安卓端的渲染逻辑，反应速度可能再次提升。
V0.71
修正了R.to（-1）时历史记录的bug
V0.7
优化了模板页的删除逻辑； 增加了 R._isSwitching 以判断页面切换是否完成，避免快速乱点会报错的情况。
V0.6
switchPage 换了机制： 将页面模板复制一份到对应page元素的上方，加载的HTML直接载入page。执行完init后，显示page，删除模板的副本。
这样做解决了原来不能在init中初始化元素的问题。
优化渲染时序： 现在区分安卓和苹果系统。由于安卓CSS渲染太慢，还会受到JS阻塞，在安卓中统一取消了动画，并且渲染时出现等待页面，一定程度解决点后没反应的问题
将切页后动作之后的回调强制滞后，以保证先执行CSS渲染，再执行回调。setTimeout方法，苹果中为0MS，安卓设为50MS。
将preLoad改为半异步（AJAX异步，exec同步）。 改善安卓端原来同步AJAX方式，在网络请求时带来的CSS渲染阻塞。
0.55：更新了事件程序
0.54：增加了JS文件已运行的标识。这个标识记录在R._execFile.jsAlreadRun，当页面卸载时清除标识，即：可以再运行。 上次更新：1、在主页body加载前，增加了框架级文件请求方法； 2、卸载机制增强；）

 *    Author        :    MacroSage JingyingYu

 */

function LOG(s) {
    SS('title').innerHTML = s;
}

function SLOG(s) {
    console.log(s);
    s = REPLACE(s, '&', ' and ');
    if (location.host.indexOf('.com') > -1) {
        R._ajax('/ruc/tool/log?msg=R: ' + s, 'get', null, true, function (t) { });
    }
}
document.onclick = function () { };
(function () {

    if (!window.history || !history.pushState) {
        alert("浏览器不支持HTML5 History API");
    }

    var userLoginTime = new Date(),
	ANIMClass = function (aType) {
	    var outClass,
		inClass;
	    switch (aType) {
	        case 5:
	            outClass = 'pt-page-fade';
	            inClass = 'pt-page-moveFromRight pt-page-ontop';
	            break;
	        case 9:
	            outClass = 'pt-page-moveToLeftFade';
	            inClass = 'pt-page-moveFromRightFade';
	            break;
	        case 10:
	            outClass = 'pt-page-moveToRightFade';
	            inClass = 'pt-page-moveFromLeftFade';
	            break;
	        case 27:
	            outClass = 'pt-page-scaleDownCenter';
	            inClass = 'pt-page-scaleUpCenter pt-page-delay400';
	            break;
	        case 54:
	            outClass = 'pt-page-rotateRoomLeftOut pt-page-ontop';
	            inClass = 'pt-page-rotateRoomLeftIn';
	            break;
	        default:
	            outClass = false;
	            inClass = false;
	    }
	    return {
	        'outClass': outClass,
	        'inClass': inClass
	    };
	},
	ANIMBack = function (aType) {
	    if (!aType) {
	        return 0;
	    }
	    switch (aType) {
	        case 5:
	            return 9;
	        case 9:
	            return 10;
	        case 27:
	            return 27;
	        case 54:
	            return 54;
	        default:
	            return 0;
	    }
	};

    window.R = {

        /*	属性currPage 与 prePage 存储当前页及上一页的基本信息 */
        currPage: {
            name: 'start',
            endUrl: '',
            formType: 'url',
            hisPop: false,
            ele: SS('[data-route="page-start"]') || null
        },
        prePage: {
            name: '',
            endUrl: '',
            formType: '',
            hisPop: true,
            ele: null
        },

        /*	属性返回系统信息
		* @return dev		设备信息：“PC","Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod"
		* @return os		操作系统信息
		* @return wx		是否使用微信。如果不是返回false 如果是返回版本号
		* @return brows	浏览器信息
		*/
        os: GETUserDev(),

        /* 属性    info 存储page配置文件 */
        info: RoutePageDate,

        /*   属性返回系统信息，返回值有："PC"，"Android", "iPhone", "iPad", "SymbianOS", "Windows Phone", "iPod"  */
        _isSwitching: false,

        /*	属性    history 与浏览器历史记录同步存储。以数组+指针的形式 */
        history: {
            recordList: [],
            animList: [],
            recordCurr: 0
        },

        /* 属性    history 与浏览器历史记录同步存储。以数组+指针的形式 */
        gobalAfterPageInto: function (cPage) {
            RMenuHandle(cPage);
        },

        /*    -------------------------------------------------------------------------------
		 *    私有属性    _paraVal 记录页面间post传值
		 */
        _paraVal: {},

        /*    -------------------------------------------------------------------------------
		 *    方法    setPara 页面传参-设置参数    V0.1    Date:15.12.5    Author:Yu
		 * @param h    : str.    页面名称。将在R._paraVal下创建子对象
		 * @param o    : obj.    要传递的参数对象。例如：{ key1:val1, key2:val2 }
		 * @param t    : str.    选填，默认为覆盖，也可传入"add"。当值为"add"时表示参数将往原对象中追加属性
		 * @return    无
		 */
        setPara: function (h, o, t) {
            var it;
            if (!R.info[h]) {
                throw "setPara 页面名称不正确";
            }
            if (t === "add") {
                for (it in o) {
                    R._paraVal[h][it] = o[it];
                }
            } else {
                R._paraVal[h] = o;
            }
        },

        /*     -------------------------------------------------------------------------------
		 *    方法    getPara    获取页面传参    V0.1    Date:15.12.5    Author:Yu
		 *                本方法可获取get及post方法传递的参数。
		 *    @param     h    :     str.    页面名称。表示要获取的R._paraVal子对象
		 *     @param     key    :     str.    选填。要获取的参数名称。 若不传，返回整个页面参数子对象
		 *     @return    某页面全部参数 / 某页面特定参数的值
		 */
        getPara: function (h, key) {
            var o = R._paraVal[h] || {},
			gp = R.getUrl().para,
			gpa = [],
			i,
			j;
            if (!!gp) {
                gpa = gp.split('&');
                for (i = 0, l = gpa.length; i < l; i++)
                    o[gpa[i].split('=')[0]] = decodeURIComponent(gpa[i].split('=')[1]);
            }
            return (typeof (key) == 'undefined') ? o : o[key] || '';
        },

        /*    -------------------------------------------------------------------------------
		 *    方法    delPara     删除页面post参数    V0.1    Date:15.12.5    Author:Yu
		 *    @param     h    :     str.    页面名称。将在R._paraVal下创建子对象
		 *     @param     key    :     str.    选填。要获取的参数名称。
		 *     @return    无
		 */
        delPara: function (h, key) {
            if (!R.info[h])
                throw "setPara 页面名称不正确";
            if (typeof (key) == 'undefined') {
                delete R._paraVal[h];
            } else {
                delete R._paraVal[h][key];
            }
        },

        /*
		 *    方法    to     页面跳转方法    V0.1    Date:15.12.6    Author:Yu
		 *    @param     h    :     str.｜-1｜1    可以传入页面名称，表示跳转到相应页面；-1等同于浏览器后退按钮，1表示浏览器前进按钮
		 *     @param     postPara: obj.    选填。此参数为跳转时传递的post参数对象
		 *     @return    无
		 */
        to: function (h, animT, postPara, hisPop) {
            var pn = '';
            if (typeof (postPara) == "object")
                R.setPara(h, postPara);
            if (typeof (h) === 'number') {
                if (h === -1 || h === 1) {
                    history.go(h);
                    return;
                } else {
                    pn = R.history.recordList[R.history.recordCurr + h];
                }
            } else {
                pn = h;
            }
            R._process("rto", pn, animT, hisPop);
        },

        /*
		 *    方法    on     事件方法    V0.1    Date:15.12.6    Author:Yu
		 *    @param
		 *     @return    无
		 */
        on: function (deleEle, selector, evName, backFun, paraObj) {
            MSEvent.add(deleEle, evName, backFun, selector, paraObj);
        },

        /*    -------------------------------------------------------------------------------
		 *     方法 getUrl 获取URL相关信息    V0.5    Date:15.10.20    Author:Yu
		 *    @param     p         : 选填。不传此参数则根据浏览器地址栏计算返回值。该参数不能带前辍URL。只能为 pageName?a=1&b=2
		 *     @return    obj        : 返回一系列URL相关属性。  完整的URL（location.href)= url+路由标识符+cPage+para = = url+路由标识符+endUrl
		 * 下面返回值结果，以此为例：如http://www.gurucv.com/acad/ruc/index.html?pageName?para1=1&para2=2
		 *         obj.preUrl    : 返回域名。http://www.gurucv.com/
		 *        obj.url        : 截止至 路由标识符之前的URL。 如http://www.gurucv.com/acad/ruc/index.html
		 *        obj.endUrl    : HASH+参数 如：pageName?para1=1&para2=2
		 *        obj.cPage    : HASH名称,不含R.pageMark,不含get参数 如：pageName
		 *        obj.para    : get参数字符串。不含首字符？ 如：para1=1&para2=2
		 */
        getUrl: function (p) {
            var preUrl = location.protocol + "//" + location.host + location.pathname,
			_endUrl = (!!p) ? p : location.href.replace(preUrl, ""),
			endUrl = (_endUrl.charAt(0) == R.info.global.pageMark) ? _endUrl.substr(1) : _endUrl,
			_pos = endUrl.indexOf('?'),
			cPage,
			para;
            if (_pos == -1) {
                cPage = endUrl;
                para = "";
            } else {
                cPage = endUrl.substr(0, _pos);
                para = endUrl.substr(_pos + 1);
            }
            return {
                preUrl: location.protocol + "//" + location.host + "/",
                url: preUrl,
                endUrl: endUrl,
                cPage: cPage,
                para: para
            };
        },

        /*    (STEP 2)    -------------------------------------------------------------------
		 *    方法    switchPage     生成用于动画切换的临时页，并插入到目标页面div中  V0.1    Date:15.12.4    Author:Yu
		 *    @param     h    :     str.    页面名称
		 *     @return    无
		 */
        switchPage: function (h) {
            var a = null,
			o = R.info[h],
			templet = o.templet || R.info.global.templet,
			oDom = SS('[data-route="' + templet + '"]').cloneNode(true),
			pT = SS('[data-route="navbar-inner"]', oDom);
            S('.RouteTempletForSwitch', SS('[data-route="views"]')).removeEle();
            oDom.classList.add('RouteTempletForSwitch');
            if (!!pT) {
                pT.innerHTML = o.pageTit;
            } //写页面标题
            S(oDom).insertBefore(SS('[data-route="page-' + h + '"]'));
            return oDom;
        },

        /*    (STEP 3)    -------------------------------------------------------------------
		 *     方法 pageHandler    处理currPage、 prePage 过程,并将卸载属性非*的页推入等卸载数组(R.uninPage.waitUnin)     V0.4    Date:15.12.6    Author:Yu
		 *     @param     uh : 新的页面URL后半端 （ pageName+get参数 )
		 *     @return    无
		 */
        pageHandler: function (t, endUrl, h) {
            if (!!R.prePage.name && R.prePage.name != h)
                R.uninPage.insert(R.prePage.name, R.info[R.prePage.name].uninsExc, R.currPage.name);
            R.prePage = {}; //断开prePage对象的原型指向。以免因下方prePage重赋值而影响R.uninPage的卸载。
            for (var it in R.currPage)
                R.prePage[it] = R.currPage[it];
            R.currPage = {
                name: h,
                endUrl: endUrl,
                formType: t,
                hisPop: (typeof (R.info[h].hisPop) != 'undefined') ? R.info[h].hisPop : true,
                ele: S('[data-route="page-' + h + '"]').t
            };
        },

        /*    (STEP 4)    -------------------------------------------------------------------
		 *    对象    ANIM    动画对象    V0.3    Date:15.12.6    Author:Yu
		 *     @方法 go     : 新的页面URL后半端 （ pageName+get参数 )
		 *        @param cPage    Ele. 要切出的页面元素
		 *        @param nPage    Ele. 要切入的页面元素
		 *        @param aType    Num. 动画类型，参见上方ANIMClass中定义的类型。0代表无动画。
		 *        @param afterAnima    Fun. 选填。动画执行完成后的回调。
		 *     @return    无
		 */
        ANIM: {
            _isAniming: false,
            _currEnd: false,
            _nextEnd: false,
            afterAnima: null,
            _onEndEName: '',
            onEndAnima: function (cPage, nPage, outClass, inClass) {
                this._currEnd = false;
                this._nextEnd = false;
                S(cPage).delClass(outClass);
                S(nPage).delClass(inClass);
                if (typeof (this.afterAnima) === 'function')
                    this.afterAnima();
                this._isAniming = false;
                this.afterAnima = null;
            },
            go: function (cPage, nPage, aType, afterAnima) {
                if (aType === 0) {
                    afterAnima();
                    return;
                }
                var outClass = '',
				inClass = '',
				aT = ANIMClass(aType);
                if (!R.ANIM._onEndEName) {
                    R.ANIM._onEndEName = (function () { //动画结束名称
                        var t,
						aNs = {
						    'WebkitAnimation': 'webkitAnimationEnd',
						    'OAnimation': 'oAnimationEnd',
						    'msAnimation': 'MSAnimationEnd',
						    'animation': 'animationend'
						};
                        for (t in aNs) {
                            if (document.body.style[t] !== undefined) {
                                return aNs[t];
                            }
                        }
                    })();
                }
                if (R.ANIM._isAniming) { return false; }
                R.ANIM._isAniming = true;
                if (typeof (afterAnima) === 'function') { R.ANIM.afterAnima = afterAnima; }
                S(cPage).addClass(aT.outClass);
                E.Add(cPage, R.ANIM._onEndEName, currPageAnim);
                function currPageAnim() {
                    E.Remove(cPage, R.ANIM._onEndEName, currPageAnim);
                    R.ANIM._currEnd = true;
                    if (R.ANIM._nextEnd) { R.ANIM.onEndAnima(cPage, nPage, aT.outClass, aT.inClass); }
                }
                S(nPage).addClass(aT.inClass);
                E.Add(nPage, R.ANIM._onEndEName, nextPageAnim);
                function nextPageAnim() {
                    E.Remove(nPage, R.ANIM._onEndEName, nextPageAnim);
                    R.ANIM._nextEnd = true;
                    if (R.ANIM._currEnd) {
                        R.ANIM.onEndAnima(cPage, nPage, aT.outClass, aT.inClass);
                    }
                }
            }
        },

        /*    (STEP 4_0)    -------------------------------------------------------------------
		 *     方法 goAnim    自动调用ANIM对象     V0.1    Date:15.12.6    Author:Yu
		 *     @param     cp         : 上一页元素
		 *     @param     np         : 下一页元素
		 *     @param     animT     : 动画类型
		 *     @param     backFn     : 动画完成的回调
		 *     @return    无
		 */
        goAnim: function (cp, np, animT, backFn) {
            var animCP,
			animNP,
			animParentDiff;
            //LOG(4);		
            if (!np.parentNode.dataset.currpage) { np.parentNode.dataset.currpage = true; }
            np.dataset.currpage = true;
            //LOG(4.5);			//setTimeout( function(){
            if (!!cp) { //没有前一页，则不执行动画，直接显示
                if (cp.parentNode == np.parentNode) {
                    animCP = cp;
                    animNP = np;
                    animParentDiff = false;
                } else {
                    animCP = cp.parentNode;
                    animNP = np.parentNode;
                    animParentDiff = true;
                }
                R.ANIM.go(animCP, animNP, animT, function () {
                    if (cp != np) {
                        delete cp.dataset.currpage;
                        if (animParentDiff && !!cp.parentNode.dataset.currpage) { delete cp.parentNode.dataset.currpage; }
                    }
                    backFn();
                });
            } else {
                backFn();
            }
            //}, delaytime );
        },

        /*    (STEP 5)    -------------------------------------------------------------------
		 *    方法    hisHandler    处理历史记录  V0.3    Date:15.12.8    Author:Yu （在R.history中增加了动画数组，用于计算反向动画）
		 *                文件隐藏请求、加载、运行的程序
		 *    @param     h :     str.    要加载的页面名称
		 *    @param     t :     str.    页面跳转来的类型
		 *     @return    无
		 */
        hisHandler: function (h, t, animT, hisPop) {
            var hisKey = R.info.global.hisRecCacheKey,
			logKey = R.info.global.logTimeCacheKey,
			ti = userLoginTime,
			hTitle = R.info[R.getUrl(h).cPage].pageTit;
            if (t === 'url') {
                R.history = {
                    recordList: [h],
                    animList: [animT],
                    recordCurr: 0
                };
                //检查用户行为缓存键是否存在，如果存在则上传至服务器
                if (!!localStorage.getItem(logKey) && typeof (updateUserAction) === 'function') {
                    updateUserAction(localStorage.getItem(logKey), localStorage.getItem(hisKey));
                }
                localStorage.setItem(logKey, [ti.getFullYear(), ti.getMonth() + 1, ti.getDate(), ti.getHours(), ti.getMinutes(), ti.getSeconds(), ti.getDay()].join(','));
                localStorage.setItem(hisKey, hTitle);
            } else if (t === 'back') {
                if (R.history.recordCurr > 0) {
                    R.history.recordCurr--;
                    localStorage.setItem(hisKey, localStorage.getItem(hisKey) + ',' + hTitle);
                }
            } else if (t === 'forward') {
                if (R.history.recordCurr > 0) {
                    R.history.recordCurr++;
                    localStorage.setItem(hisKey, localStorage.getItem(hisKey) + ',' + hTitle);
                }
            } else {
                if (R.history.recordCurr != R.history.recordList.length - 1) {
                    R.history.recordList.length = R.history.recordCurr + 1;
                    R.history.animList.length = R.history.recordCurr + 1;
                }
                if (hisPop === false) {
                    R.history.recordList.pop();
                    R.history.animList.pop();
                    R.history.recordList.push(h);
                    R.history.animList.push(animT);
                } else {
                    R.history.recordList.push(h);
                    R.history.animList.push(animT);
                    R.history.recordCurr = R.history.recordList.length - 1;
                }
                localStorage.setItem(hisKey, localStorage.getItem(hisKey) + ',' + hTitle);
            }
        },


        /*    (STEP 7)    -------------------------------------------------------------------
		 *    对象    uninPage    卸载页面对象    V0.3    Date:15.12.9    Author:Yu （更新了CSS卸载方式，现在以计数式卸载，以防止不同页引用同一个CSS的情况）
		 *     @属性 waitUnin     : 储存待删除页面的数组
		 *     @属性 waitUninName : 待删除页面名称的数组，用于避免多重循环。快速检测页是否在数组中。
		 *     @方法 insert     : 插入待卸载的页面
		 *        @param pageName             要卸载页面的名称
		 *        @param pageUninExcep    要卸载页面的排除页（page.uninsExc)
		 *        @param nextPageName        下一页的名称
		 *     @方法 unin         : 处理waitUnin列表。决定是否对列表中的页进行删除(_uninOne)
		 *     @方法 uninOne     : 卸载一个页面
		 *        @param pageName             要卸载页面的名称
		 */
        uninPage: {
            waitUnin: [],
            waitUninName: [], //待删除页面名称的字符串，用于避免多重循环。
            insert: function (pageName, pageUninExcep, nextPageName) {
                if (pageUninExcep == '*' || R.uninPage.waitUninName.indexOf(pageName) > -1 || !R.info[pageName].inPage)
                    return;//如果为记不卸载，或待删除列表中已存在这个页面, 或此页面inPage为false(已经卸载),则忽略
                var o = {
                    name: pageName,
                    uninExcept: pageUninExcep || [],
                    nextPage: nextPageName,
                    relation: []
                };
                R.uninPage.waitUnin.push(o);
                R.uninPage.waitUninName.push(o.name);
            },
            unin: function () {
                var a = R.uninPage.waitUnin,
				aN = R.uninPage.waitUninName,
				o,
				index;
                for (var i = 0, l = a.length; i < l; i++) {
                    o = a[i];
                    if (o.uninExcept.indexOf(o.nextPage) == -1 || S('[data-route="page-' + o.nextPage + '"]').t.innerHTML === "") {  //如果
                        for (var i1 = 0, l1 = o.relation.length; i1 < l1; i1++)
                            R.uninPage.uninOne(o.relation[i1]);
                        R.uninPage.uninOne(o.name);
                        a.splice(i, 1);
                        aN.splice(i, 1);
                        i--;
                        l--;
                    } else {
                        index = aN.indexOf(o.nextPage);
                        if (index > -1) {
                            a[index].relation = a[index].relation.concat(a[i].name, a[i].relation);
                            a.splice(i, 1);
                            aN.splice(i, 1);
                            i--;
                            l--;
                        }
                    }
                }
            },
            /*			immedi : function (prePage, currPage) {
                            if (!prePage || !R.info[prePage].uninImmedi)
                                return;
                            var uninsExc = R.info[prePage].uninsExc,
                            uniList = (uninsExc instanceof Array) ? uninsExc : false;
                            if (!(!!uniList && uniList.indexOf(currPage) > -1)) {
                                R.uninPage.uninOne(prePage);
                            }
                        },*/
            uninOne: function (pageName) {
                var cssList = R.info[pageName].cssFile,
				jsList = R.info[pageName].jsFile || pageName + '.js', //如果没有定义，则自动补充同名的JS文件
				ele = S('[data-route="page-' + pageName + '"]').t,
				i,
				l,
				eStr,
				e,
				jsFname;
                //卸载事件
                MSEvent.remove(ele, '', true);
                //卸载CSS
                if (!!cssList) {
                    for (i = 0, l = cssList.length; i < l; i++) {
                        eStr = '#pageCss_' + cssList[i].substring(cssList[i].lastIndexOf('/') + 1, cssList[i].indexOf('.'));
                        e = S(eStr).t;
                        if (!e)
                            continue;
                        if (e.dataset.cssCount == "0") {
                            S(eStr).removeEle();
                        } else {
                            e.dataset.cssCount = parseInt(e.dataset.cssCount) - 1;
                        }
                    }
                }
                //卸载JS运行标识 （记录在R._execFile.jsAlreadRun)中
                for (i = 0, l = jsList.length; i < l; i++) {
                    jsFname = jsList[i];
                    jsFname = jsFname.substring(jsFname.lastIndexOf('/') + 1, jsFname.indexOf('.'));
                    delete R._execFile.jsAlreadRun[jsFname]; //从已经运行的JS列表中清除这个JS文件名项。
                }
                //清空DIV
                ele.innerHTML = "";
                //将页面JS对象清空
                window[pageName] = null;
                //清除页面参数
                R.delPara(pageName);
                //将页面标识为已卸载
                R.info[pageName].inPage = false;
            }
        },

        /*    (STEP 8)    -------------------------------------------------------------------
		 *    方法    loadPage     页面加载方法  V0.2    Date:15.12.5    Author:Yu
		 *                文件隐藏请求、加载、运行的程序
		 *    @param     h :     str.    要加载的页面名称
		 *    @param    bFn:    fun.    完成后的回调
		 *     @return    无
		 */
        loadPage: function (h, bFn) {
            var fileList = [],
			xhr = null,
			i = 0,
			l = 0,
			fileUrl,
			fUrl,
			fLocalKey,
			fType,
			idHead,
			fillFileCount = 0,
			cacheVerMark = '//|',
			globInfo = R.info.global,
			pageInfo = R.info[h],
			filePath = {
			    'html': R._replacePath(globInfo.htmlPath, h), //REPLACE(globInfo.htmlPath, 'PAGENAME', h),
			    'js': R._replacePath(globInfo.jsPath, h), //REPLACE(globInfo.jsPath, 'PAGENAME', h),
			    'css': R._replacePath(globInfo.cssPath, h) //REPLACE(globInfo.cssPath, 'PAGENAME', h)
			},
			getFileName = function (s) {
			    return s.substring(s.lastIndexOf('/') + 1, s.lastIndexOf('.'));
			};

            //////////组建请求队列，顺序严格。插入队列的顺序也是执行的顺序
            if (!!pageInfo.cssFile) { //1.插入CSS
                for (i = 0, l = pageInfo.cssFile.length; i < l; i++) {
                    fileUrl = (pageInfo.cssFile[i].indexOf('/') == -1) ? filePath.css + pageInfo.cssFile[i] : pageInfo.cssFile[i];
                    fileList.push({
                        'url': fileUrl,
                        'name': getFileName(fileUrl),
                        'type': 'css',
                        'text': ''
                    });
                }
            } //2.插入html

            fileList.push({
                'url': filePath.html + h + "." + globInfo.htmlFileExt,
                'name': h,
                'type': 'html',
                'text': ''
            });

            if (!!pageInfo.jsFile) { //3.插入JS
                for (i = 0, l = pageInfo.jsFile.length; i < l; i++) {
                    fileUrl = (pageInfo.jsFile[i].indexOf('/') == -1) ? filePath.js + pageInfo.jsFile[i] : pageInfo.jsFile[i];
                    fileList.push({
                        'url': fileUrl,
                        'name': getFileName(fileUrl),
                        'type': 'js',
                        'text': ''
                    });
                }
            } else {
                fileList.push({
                    'url': filePath.js + h + '.js',
                    'name': h,
                    'type': 'js',
                    'text': ''
                });
            }

            //////////创建页面JS对象，并继承方法
            R._extPageObj(h);
            //////////异步请求数据
            for (i = 0, l = fileList.length; i < l; i++) {
                fUrl = fLocalKey = fileList[i].url;
                fType = fileList[i].type;
                idHead = (fType == 'css') && 'pageCss_' || (fType == 'html') && 'pageTemp_' || '';
                (function (i, fType, idHead, fUrl) {
                    R._loadFileFormCache(fUrl, fLocalKey, fileList[i].name, fType, function (t) {
                        fileList[i].text = t;
                        fileList[i].idStr = (fType == 'html') && h || idHead + fUrl.substring(fUrl.lastIndexOf('/') + 1, fUrl.indexOf('.'));
                        fillFileCount++;
                        runBfn();
                    });
                })(i, fType, idHead, fUrl);
            }

            function runBfn() {
                if (fillFileCount != fileList.length)
                    return;
                for (i = 0, l = fileList.length; i < l; i++)
                    R._execFile[fileList[i].type](fileList[i].text, fileList[i].idStr);
                if (typeof (bFn) == 'function')
                    setTimeout(function () {
                        bFn();
                    }, 100);
            }

        },

        /*    (STEP 8_1)    -------------------------------------------------------------------
		 *    方法    _extPageObj  为页面对象继承方法  V0.1    Date:15.12.4    Author:Yu
		 *    @param     h :     str.    对象名称（页面名称）
		 *     @return    无
		 */
        _extPageObj: function (h) {
            if (typeof (window[h]) !== 'object' || window[h] === null)
                window[h] = {};
            var o = window[h];
            o.getParam = function (key) {
                return R.getPara(h, key);
            };
            o.on = function (t, et, cFn, obj) {
                R.on(S('[data-route="page-' + h + '"]').t, t, et, cFn, obj);
            };
        },

        /*    -------------------------------------------------------------------------------
		 *     方法 _process 流程控制过程    V0.4    Date:15.12.29    Author:Yu (更新的对页面是否已经加载的判断和处理）
		 *    @param     t         : 跳转产生的动作类型
		 *     @param     endUrl     : 要跳转页的URL后半段 （ pageName+get传参 )
		 *     @param     o         : 更多参数的对象
		 *     @return    无
		 */
        _process: function (t, endUrl1, animT, hisPOP) {
            if (R._isSwitching) return;
            var endUrl = R.getUrl(endUrl1).endUrl,
			h = R.getUrl(endUrl).cPage,
			hisPop = R.currPage.hisPop,
			tempPage = null,
			canToThisPage, temp1; //页面是否有进入此页面的权限
            //SLOG('[_process] 进入_process流程， endUrl:' + endUrl);
            if (!R._getCVId()) {
                canToThisPage = R.share.canShare(endUrl);
                if (!canToThisPage.can) {
                    if (canToThisPage.info === 'deepStop') {
                        R.to('login');
                        return;
                    } else if (canToThisPage.info === 'noShareData') {
                        R.to('login');
                        return;
                    } else if (canToThisPage.info === 'shareError') {
                        return;
                    }
                }
            }
            //SLOG('[_process] 通过了页面判断， 执行页面跳转到:' + endUrl);
            if (!R.info[h]) {
                throw h + "页面未注册";
            }

            R._isSwitching = true;
            // STEP 写主页面标题
            S('title').t.innerHTML = R.info[h].mainTit || R.info.global.mainTit;

            // STEP 处理R.currPage
            R.pageHandler(t, endUrl, h);

            // STEP 生成初始页 | 并处理动画参数
            //tempPage = (!!R.info[h].inPage) ? R.currPage.ele : R.switchPage(h);
            if (R.os.dev == 'Android') {
                tempPage = R.switchPage(h);
                animT = 0;
            } else {
                tempPage = (!!R.info[h].inPage) ? R.currPage.ele : R.switchPage(h);
                animT = parseInt(animT);
                if (animT !== 0)
                    animT = (ANIMClass(animT).outClass === false) ? R.info.global.animT : animT;
            }
            //LOG(2);
            // STEP 执行动画
            R.goAnim(R.prePage.ele, tempPage, animT, function () {
                setTimeout(_setp2, 0);
            });

            function _setp2() {
                //LOG(5);
                // STEP 处理R.history
                R.hisHandler(endUrl, t, animT, hisPop);

                // STEP 卸载页面方法
                //处理立即卸载面
                temp1 = R.info[R.prePage.name];
                if (!!R.prePage.name && !!temp1.uninImmedi &&
                    (!(temp1.uninsExc instanceof Array) || temp1.uninsExc.indexOf(R.currPage.name) == -1)) {
                    R.uninPage.insert(R.prePage.name, R.info[R.prePage.name].uninsExc, R.currPage.name);
                }
                R.uninPage.unin();
                //R.uninPage.immedi(R.prePage.name, R.currPage.name);
                // STEP 处理URL
                if (t !== 'back' && t !== 'forword') {
                    if (hisPop === false) {
                        history.replaceState('', '', R.getUrl().url + R.info.global.pageMark + endUrl);
                    } else {
                        history.pushState('', '', R.getUrl().url + R.info.global.pageMark + endUrl);
                    }
                }
                if (!R.info[h].inPage) { //如果页面没有卸载，则不执行8~1
                    //LOG(6);
                    //  8:加载CSS、JS、HTML文件
                    R.loadPage(h, function () {
                        //LOG(7);					
                        R._isSwitching = false;
                        //  9:执行init
                        R._runFu(h, 'init');
                        //  10:将隐藏DIV中的innerHTML替换到页面DIV中，并将隐藏DIV删除
                        //LOG(7.1);				
                        R.currPage.ele.dataset.currpage = 'true';
                        S(R.currPage.ele.previousElementSibling).removeEle();
                        //    10.5 :执行onPageLoadInit()回调。
                        //LOG(7.5);			
                        R._runFu(h, 'onPageLoadInit');
                        //执行后续的
                        //LOG(8);					
                        _setp3();
                    });
                } else {
                    R._isSwitching = false;
                    if (R.os.dev == 'Android') {
                        //LOG(8.1);						
                        R.currPage.ele.dataset.currpage = 'true';
                        S(R.currPage.ele.previousElementSibling).removeEle();
                        //LOG(8.5);					
                    }
                    _setp3();
                }
            }

            function _setp3() {
                R.info[h].inPage = true;
                //  改写URL

                //  11:执行用户定义的 onPageLoad()方法
                R._runFu(h, 'onPageLoad');
                //LOG(9);
                //  执行通用方法
                R.gobalAfterPageInto(h);
            }

        },

        _runFu: function (obj, fun) {
            if (typeof (window[obj]) != "object")
                return;
            if (typeof (window[obj][fun]) === "function")
                window[obj][fun]();
        },

        /*    -------------------------------------------------------------------------------
		 *    私有方法    _ajax 请求方法。  此方法只支持新型浏览器。  V0.1     Date:15.12.5    Author:Yu
		 *     @param     url        AJAX请求地址
		 *     @param     gp        "GET | POST " 请求方式
		 *     @param     gpP        请求时发送的参数
		 *     @param     asyn    是否异步
		 *     @param     sFn        成功的回调函数（传入一个参数 xhr.responseText)
		 *     @param     eFn        请求失败的回调函数    (传入一个参数 xhr.status)
		 *     @return    读取的文件内容
		 */
        _ajax: function (url, gp, gpP, asyn, sFn, eFn) {
            var xhr = new XMLHttpRequest();
            xhr.open(gp, url, asyn);
            if (gp === 'POST') { xhr.setRequestHeader("Content-Type", "application/json"); }
            xhr.send(gpP);
            if (asyn) {
                xhr.onreadystatechange = function (e) {
                    if (xhr.readyState == 4) {
                        if (xhr.status >= 200 && xhr.status < 300 || xhr.status == 304) {
                            if (typeof (sFn) === 'function')
                                sFn(xhr.responseXML || xhr.responseText);
                        } else {
                            if (!!eFn) {
                                if (typeof (eFn) === 'function')
                                    eFn(xhr.status);
                            }
                        }
                    }
                };
            } else {
                if (xhr.status >= 200 && xhr.status < 300 || xhr.status == 304) {
                    if (typeof (sFn) === 'function')
                        sFn(xhr.responseText);
                } else {
                    if (typeof (eFn) === 'function')
                        eFn(xhr.status);
                }
            }
        },

        /*    -------------------------------------------------------------------------------
		 *    私有方法    _loadFileFormCache 请服务器请求，或者从缓存读取 V0.1     Date:15.12.5    Author:Yu
		 *     @param     url        AJAX请求地址
		 *     @param     key        本地缓存键名
		 *     @param     fName    文件名
		 *     @param     fType    文件类型
		 *    @param  bFn        成功的回调（传入文本）
		 *     @param    errorFn    失败的回调
		 *     @return    读取的文件内容
		 */
        _loadFileFormCache: function (url, key, fName, fType, bFn, errorFn, asyn) {
            var verMark = {
                html: {
                    s: "<!--LocalCacheVersion:",
                    e: "-->"
                },
                js: {
                    s: "/*LocalCacheVersion:",
                    e: "*/"
                },
                css: {
                    s: "/*LocalCacheVersion:",
                    e: "*/"
                }
            },
			re = localStorage.getItem(key),
			obj = window[R.info.global.LoCacheVName][fName + "_" + fType],
			cv,
			con = false,
			rT = new Date(),
			url2 = url + '?requestTime=' + rT.getTime();
            if (!!re && !!obj) { //仅当 缓存与服务器版本号都存在，且一致时，才读缓存
                cv = re.substring(re.indexOf(verMark[fType].s) + verMark[fType].s.length, re.indexOf(verMark[fType].e));
                if (cv == obj)
                    con = true;
            }
            if (!con) { //否则： 清缓存、AJAX请求、（如果服务定义了版本号）存缓存
                localStorage.removeItem(key);
                R._ajax(url2, "GET", null, (typeof asyn != 'undefined') ? asyn : true, function (t) {
                    re = t;
                    if (!!obj)
                        localStorage.setItem(key, verMark[fType].s + obj + verMark[fType].e + re);
                    bFn(re);
                }, function () {
                    if (typeof (errorFn) === "function")
                        errorFn(re);
                });
            } else {
                bFn(re);
            }
        },

        /*    -------------------------------------------------------------------------------
		 *    私有对象    _execFile 运行html、js、 css文件的方法。HTML、CSS将检测页面中有没有 V0.1     Date:15.12.5    Author:Yu
		 *     @方法 css     : 将一个CSS文件加载到head的最后一行。实现重复加载时更变计数
		 *        @param text        CSS文件内容
		 *        @param idStr    加载到页面后的ID
		 *        @return 无
		 *     @方法 css     : 运行一个JS文件
		 *        @param text        JS文件内容
		 *        @return 无
		 *     @方法 html     : 将一个HTML文件加载页面的一个隐藏DIV中。这个DIV将插到到body最后
		 *        @param text        HTML文件内容
		 *        @param idStr    加载到页面后的ID
		 *        @return 无
		 */
        _execFile: {
            jsAlreadRun: {}, //用于记录哪些JS已经运行。当页面卸载的时候清除.一项为：pagejs_文件名:1
            css: function (text, idStr) {
                var e = S('#' + idStr).t;
                if (!!e) { //如果CSS已经加载过，则计数+1
                    e.dataset.cssCount = parseInt(e.dataset.cssCount) + 1;
                    return;
                } //否则则插入CSS
                document.head.insertAdjacentHTML("beforeEnd", '<style id=' + idStr + '>' + text + '</style>');
                S('#' + idStr).t.dataset.cssCount = "0";
            },
            js: function (text, idStr) {
                if (!!R._execFile.jsAlreadRun[idStr])
                    return; //如果已经运行，则不运行
                if (window.execScript) {
                    window.execScript(text);
                } else {
                    window.eval(text);
                }
                R._execFile.jsAlreadRun[idStr] = 1; //标识为已运行；
            },
            html: function (text, idStr) {
                SS('[data-route="page-' + idStr + '"]').innerHTML = text;
            }
        },

        /*    -------------------------------------------------------------------------------
		 *    私有方法    _getPageFileVer 建立本地缓存版本号对象。用于更新缓存。从R.info.global中获取请求地址和文件名 V0.2     Date:16.1.15    Author:Yu
		 *     @param     无
		 *     @return    无
		 */
        _getPageFileVer: function () {
            var url = R._replacePath(R.info.global.LoCacheVerUrl),
			ajaxUrl = url + '?cv=' + R._getCVId(),
			cache = localStorage.getItem(url),
			ajaxRun;
            if (!!cache) {
                R._execFile.js(cache, url);
            } else {
                window[R.info.global.LoCacheVName] = {};
            }
            if (!url)
                return;
            //如果联网则
            R._ajax(ajaxUrl, "GET", null, true, function (t) {
                ajaxRun = (!!t) ? 'var LocalCacheVersion=' + t : 'var LocalCacheVersion={}';
                R._execFile.js(ajaxRun, url);
                localStorage.setItem(url, ajaxRun);
            });
        },

        /* 获取GURUCV号 */
        _getCVId: function (keyT) {
            var c = document.cookie,
			a,
			i,
			l,
            keyTitle = keyT || 'CvNumber',
			key = keyTitle + R.info.global.platform;
            if (c.length === 0)
                return '';
            a = c.split((!!c.match('; ')) ? '; ' : ';');
            for (i = 0, l = a.length; i < l; i++) {
                aa = a[i].split('=');
                if (aa[0] == key)
                    return aa[1] || '';
            }
            return '';
        },

        /*    -------------------------------------------------------------------------------
		 *    私有方法    _urlAdjust 处理URL跳转。专门处理cPage对不对，不对跳转哪个页面的问题 V0.1     Date:15.12.5    Author:Yu
		 *    @param url    用户输入的原始URL
		 *    @return    处理后正确的 end  Url
		 */
        _urlAdjust: function (url) {
            //SLOG("传过来的额URL" + url);
            var urlO = R.getUrl(url),
			h = urlO.cPage,
			endUrl = urlO.endUrl;
            SLOG('endUrl=' + endUrl + "h=" + h);
            if (!!endUrl && h.length < 18) {
                //index?code=sdfdsfdsdf
                return (!!R.info[h]) ? endUrl : R.info.global.errorPage;
            } else {
                return R.info.global.indexPage;
            }
        },

        /*    -------------------------------------------------------------------------------
		 *    私有方法    _replacePath 处理URL地址。能将一些定义在R.info.global中的路径，存在的替换符换掉  V0.1     Date:15.12.10    Author:Yu
		 *    @param url    需要替换的URL
		 *    @param h    选填，需要将PAGENAME替换为哪个页面名称。若不传，出现PAGENAME则替换为当前地址栏中的cPage.
		 *    @return    处理后正确的 endUrl
		 */
        _replacePath: function (url, h1) {
            var h = h1 || R.getUrl().cPage;
            return REPLACE(REPLACE(url, 'PAGENAME', h), 'PLATFORM', R.info.global.platform);
        },

        /*    -------------------------------------------------------------------------------
		 *    私有方法    _preLoad  loadFileFormCache中AJAX要加同步异步参数
		在页面载入之前，预加载文件。文件配置在RoutePageDate.global.preLoad中。仅支持.js  .css .html文件。若需缓存请在RoutePageDate.global。LoCacheVerUrl文件中配置版本号。
		 *                    V0.2     Date:16.1.12    Author:Yu
		 *     @param     无
		 *     @return    无
		 */
        _preLoad: function () {
            var idHead,
			list = R.info.global.preLoad,
			i,
			l,
			url,
			name,
			type,
            temp1, temp2;
            if (!list.length)
                return;
            for (i = 0, l = list.length; i < l; i++) {
                url = R._replacePath(list[i].url);
                //eg: url =  /Style/ruc.css
                type = list[i].type || url.substr(url.lastIndexOf('.') + 1);
                temp1 = url.lastIndexOf('/');
                temp2 = url.lastIndexOf('.');
                name = (temp1 < temp2) ? url.substring(temp1 + 1, temp2) : url.substr(temp1 + 1)
                //name = url.substring(url.lastIndexOf('/') + 1, url.lastIndexOf('.'));
                //eg: name = ruc 
                idHead = (type == 'css') && 'pageCss_' || (type == 'html') && 'pageTemp_' || '';
                R._loadFileFormCache(url, url, name, type, function (t) {
                    R._execFile[type](t, idHead + name);
                }, null, false);
            }
        },

        share: {
            allow: true,
            data: null,
            init: function () {
                var key = GetUrlPara('key'),
				g = R.info.global,
				noKeyTo = g.indexPage, //没有key时跳转的页
				havaKeyTo = 'shareCheck?key=' + key; //有key时跳转的页
                if (!!R.share.canShare.can) {
                    //SLOG('[share.init] 返回跳转页：' + R._urlAdjust());
                    return R._urlAdjust();
                } else if (!!key) {
                    //SLOG('[share.init] 页面含有shareKey（key=' + key + '），返回跳转页：' + havaKeyTo);
                    S(document.body).on('touchend', function () {
                        R.to('login?' + R.getUrl().cPage + ((!!R.getUrl().para) ? '&' + R.getUrl().para : ''));
                    }, '[data-route-mustlogin]', {
                        offDef: true,
                        single: true
                    });
                    return havaKeyTo;
                } else {
                    //SLOG('[share.init] 页面没有shareKey' + '，返回跳转页：' + noKeyTo);
                    return noKeyTo;
                }
            },
            //判断页面是否有进入的权限（不管cookies） 返回一个对象{can:Boo, info:Str} can表示能否进入，info表示为什么
            //当can为true时，info值有：share（分享来的）canLogoutPage（该页在页面配置中列为 免登录页）； can为false时，info值有：deepStop（分享的，但deep值超出） noShareData （不是分享来的）
            canShare: function (endUrl) {
                endUrl = endUrl || R.getUrl().endUrl;
                if (!!R.share.data) { //这一步在分享进入的第一次时不执行，因为此时R.share.data为null
                    if (!!GetUrlPara('key') && R.getUrl().cPage != 'shareCheck') { // 有key只能是分享第一次进行的URL，或者是之后点浏览器返回。此处是处理返回的情况
                        //SLOG('[share.canShare] can: false, info: shareError, 在分享的页面上点返回，程序阻止');
                        return {
                            can: false,
                            info: 'shareError'
                        };
                    } else if (R.getUrl().endUrl == R.share.data.formUrl) {
                        R.share.data.nowDeep = 0;
                        //SLOG('[share.canShare] can: true, info: share, deep:' + R.share.data.nowDeep + ' endUrl:' + endUrl);
                        return {
                            can: true,
                            info: 'share'
                        };
                    } else if (R.share.data.nowDeep <= R.share.data.maxDeep) {
                        R.share.data.nowDeep++;
                        //SLOG('[share.canShare] can: true, info: share, deep:' + R.share.data.nowDeep + ' endUrl:' + endUrl);
                        return {
                            can: true,
                            info: 'share'
                        };
                    } else {
                        //SLOG('[share.canShare] can: false, info: deepStop, endUrl:' + endUrl);
                        return {
                            can: false,
                            info: 'deepStop'
                        }; //alert('没有权限访问此页面');
                    }
                } else if (!!R.info.global.canLogoutPage && R.info.global.canLogoutPage.indexOf(R.getUrl(endUrl).cPage) > -1) {
                    //SLOG('[share.canShare] can: true, info: canLogoutPage, endUrl:' + endUrl);
                    return {
                        can: true,
                        info: 'canLogoutPage'
                    };
                } else {
                    //SLOG('[share.canShare] can: false, info: noShareData, endUrl:' + endUrl);
                    return {
                        can: false,
                        info: 'noShareData'
                    };
                }
            },
            //登录或者注册成功后需要执行此方法
            off: function () {
                R.share.data = null;
                MSEvent.remove(document.body, '[data-route-mustlogin]');
            }
        },

        /*    -------------------------------------------------------------------------------
		 *    私有方法    _init 初始化，添加事件  V0.3     Date:15.12.9    Author:Yu （更新了Route-to属性的”back"支持； 执行框架级文件加载 R._preLoad() )
		 */
        _init: function () {

            var urlAdjust = R._urlAdjust(),
			platform1 = location.pathname.substr(1); //平台名称

            //获取对象级文件版本对象
            R.info.global.platform = (!!platform1) ? platform1.substring(0, platform1.indexOf("/")) : '';

            //创建本地缓存对象
            R._getPageFileVer();

            //加载preLoad文件
            R._preLoad();

            SLOG("[_init:]当前URL：" + location.href);
            //情况判断
            if (!!R._getCVId()) {
                //SLOG('[_init] 已登录,准备跳转：' + urlAdjust);
                if ((!R._getCVId('Regstate') || R._getCVId('Regstate') == '0') && !(!!R.info.global.canLogoutPage && R.info.global.canLogoutPage.indexOf(R.getUrl().cPage) > -1)) {
                    R.prePage.name = 'login';
                    R._initStep2('reg3');   //如果没有走过注册第三步
                } else {
                    R._initStep2(urlAdjust);
                }

            } else if (!!IsWeixin() && location.host.indexOf('.com') > -1) {
                //SLOG('[_init] 是微信');
                R._weixinLoginHandle();
            } else {
                //SLOG('[_init] 未登录,将进入R.share.init流程');
                R._initStep2(R.share.init());
            }

        },

        _weixinLoginHandle: function () {
            var src1 = '/' + R.info.global.platform + '/wx/getauth?platUrl=' + R.info.global.platform,
			code = GetUrlPara('code'),
			src2 = R.getUrl().preUrl + R.info.global.platform + '/wx/index?pName=' + R.info.global.platform + '&code=' + code,
			ifr = document.createElement('iframe'),
			winxinBack = function (e) {
			    SLOG('[_weixinLoginHandle] ifr postMessage ' + e.data);
			    var url = (e.data) ? R._urlAdjust() : R.share.init();
			    SLOG('[_weixinLH] 微信验证后准备跳转：' + url);
			    E.Remove(window, 'message', winxinBack);
			    SLOG('[_weixinLH] 1111111111111：' + url);
			    S(ifr).removeEle();
			    SLOG('[_weixinLH] 22222222222：' + url);
			    R._initStep2(url);
			};
            SLOG('[_weixinLoginHandle] 进入微信验证流程code: ' + (code || '空'));
            ifr.style.display = 'none';
            document.body.appendChild(ifr);
            if (!code) {
                SLOG('[_weixinLoginHandle] 没有code. AJAXurl: ' + src1);
                R._ajax(src1, 'POST', JSON.stringify({ "url": location.href }), true, function (t) {
                    t = JSON.parse(t);
                    SLOG('[_weixinLoginHandle] 没有微信t.url:' + t.url);
                    if (!t.wxConfig || t.wxConfig === 'false') {
                        SLOG('[_weixinLoginHandle] 没有微信APPID:直接走R.share.init');
                        R._initStep2(R.share.init());
                        return;
                    }
                    if (R.os.dev == 'Android') {
                        SLOG('[_weixinLoginHandle] (Android) 页面将跳转 ' + t);
                        window.location.href = t.url;
                    } else {
                        ifr.src = t.url;
                        SLOG('[_weixinLoginHandle] (iphone) 没有code. AJAX返回ifr.src: ' + t);
                    }
                }, function (e) {
                    SLOG("访问出错");
                });
            } else {
                SLOG('[_weixinLoginHandle] 有了code. ifr.src: ' + src2);
                E.Add(window, 'message', winxinBack);
                ifr.src = src2;
            }
        },

        _initStep2: function (url) {
            //添加点击事件
            S(document.body).on('touchend', function (e, eo) {
                var t = eo.self,
				formType = 'dom',
				u = t.dataset.routeTo,
				aT = t.dataset.routeType,
				reCurr,
                nowEndurl = R.getUrl().endUrl;
                if (u == 'back') {
                    history.go(-1);
                    setTimeout(function () {
                        if (R.getUrl().endUrl == nowEndurl)
                            R.to(R.info.global.indexPage);
                    }, 200);
                    return;
                }
                if (R.getUrl(t.dataset.routeTo).cPage == R.getUrl().cPage)
                    return;
                if (R.ANIM._isAniming === true)
                    return;
                R._process('dom', u, aT);
            }, '[data-route-to]', {
                offDef: true
            });

            //添加浏览器前进后退按钮点击事件
            E.Add(window, 'popstate', function () {
                var url;
                if (R.getUrl().endUrl == R.history.recordList[R.history.recordCurr + 1]) {
                    R._process(
						(R.history.recordCurr < R.history.recordList.length) ? 'forword' : 'url',
						R.history.recordList[R.history.recordCurr + 1],
						R.history.animList[R.history.recordCurr + 1] || 0);
                } else {
                    if (R.getUrl().cPage == R.currPage.name) { history.go(-1); R.history.recordCurr--; return; }
                    R._process(
						(R.history.recordCurr > 0) ? 'back' : 'url',
						R.history.recordList[R.history.recordCurr - 1],
						ANIMBack(R.history.animList[R.history.recordCurr]) || 0);
                }
            });
            //delete SS('[data-route=page-start]').dataset.currpage;
            //delete SS('[data-route=page-start]').parentNode.dataset.currpage;
            //SLOG('[_initStep2] 页面准备跳转：' + url);
            R._process('url', url, 0, false);
        }
    };

    window.onload = R._init;

    //记录用户浏览行为，及服务器数据交互
    function updateUserAction(loginTime, history) { }

    //菜单处理
    function RMenuHandle(cPage) {
        var menu = SS('#footerBar-nav'),
		curr = SS('[data-route-to="' + cPage + '"]', menu),
		currClass = 'current';
        S('[data-route-to]', menu).delClass(currClass);
        if (!!curr)
            S('[data-route-to="' + cPage + '"]', menu).addClass(currClass);
    }

})();