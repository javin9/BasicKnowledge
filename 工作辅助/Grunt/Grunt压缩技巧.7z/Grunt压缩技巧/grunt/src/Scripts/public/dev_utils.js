﻿//========================================
//   Desc： 去掉首尾空格
//  Author：Cupid
//  Date:2015-8-21 
//========================================
String.prototype.trim = function () {
    return this.replace(/(^\s*)|(\s*$)/g, "");
}


var clickEventName = {
    touchstart: (IsMobile() && ('ontouchstart' in document)) ? 'touchstart' : 'click',
    touchend: (IsMobile() && ('ontouchstart' in document)) ? 'touchend' : 'click'
};

//========================================
//  Author：刘建伟
//  Date:2015-9-17 17:39:31
/*
Desc： 判断某一个值是否为 null，‘null’,'undefined' ,'','   '
判断类型：(1):null，                 结果：true
                  (2):'null',                   结果：true
                  (3):'undefined'        结果：true
                  (4):'undefined' ,      结果：true
                  (5):''                          结果：true
                  (6):'   '   任意空格    结果：true
                  (7):0   任意空格    结果：true
                  (8):'0'   任意空格    结果：true
结果返回true，false
*/
//========================================


function isNull(val) {
    var type = typeof val;
    if (type == 'string') {
        val = val.trim();
        return val == 'null' || val == 'undefined' || /^\s+$/g.test(val) || val == '';
    } else {
        return type == 'undefined' || val == null;
    }
}


//========================================
//   Desc：  jsrender绑定方法 参数obj
//  Author：fyp
//  Date:2015-8-21 
//========================================
function jsRenderBinding(obj) {
    var tempId = obj.page.split('.');
    var templateid = '';
    if (tempId.length == 2) { templateid = tempId[1]; }
    var j, t, json; json = obj.json; if ((typeof json).toLowerCase() === 'string') {
        j = JSON.parse(json);
    } else { j = json; }
    var $tempObj = $('#' + templateid);
    //如果是ID
    if ($tempObj.length) { t = $tempObj.first(); } else { alert('模板不存在。'); }
    return t.render(j);
}
/* EmojiBM 字符编码  能将文本中的表情转为unicode编码  By yu 12.15
*	@param s 	要转换的字符串
*	@return Str.转好的字符串。 仅转换表情，其他文本不动。
*/
function EmojiBM(s) {
    ///////////////第一行的正则用于检测表情。是借用别人的。 不是很好，IPHONE下不能完全识别。需要做升级。
    ///////////////这个正则是检测UTF16的。但是测试发现IPOHONE中的 “心”、“手掌”等图标，只是简单的UTF8,没被转换。（为什么存入数据库再显示也不行？）解决办法只能是摸清这些表情的编码范围。完善这个正则
    if (typeof s === 'string') {
        s = s || '';
        return s.replace(/[\ud800-\udbff][\udc00-\udfff]/gm, function (str) {
            var r = []; for (var i = 0; i < str.length; i++) r[i] = ("00" + str.charCodeAt(i).toString(16)).slice(-4);
            return "\\u" + r.join("\\u")
        });
    }
    return s;
}
/* EmojiJM 字符解码  能将文本中的unicode编码转为字符  By yu 12.15
*	@param s 	要转换的字符串
*	@return Str.转好的字符串。
*/
function EmojiJM(s) {
    if (typeof s === 'string') {
        s = s || ''; return s.replace(/\\u[a-z|0-9]{4}/gm, function (t) { return unescape(t.replace(/\\/g, "%")) });
    }
    return s;
}

//========================================
//   Desc：  ajax 异步请求访问方法封装
//  Author：fyp
//  Date:2015-8-21 
//========================================

var ajaxTool = {
    options: {
        ajaxLoading: function (over) {
            // console.log(over ? "加载完毕" : "正在加载...");
        },
        ajaxTip: function (msg, error) {
            //  console.log((error ? '错误提示' : '成功提示') + msg);
        },
        checknet: false
    },
    init: function (options) {
        $.extend(options, this.options);
        if (this.options.checknet) {
            ajaxTool.netUtil.addHandler(window, "online", function () {
                console.log("您当前在线");
            });
            ajaxTool.netUtil.addHandler(window, "offline", function () {
                console.log("您当前离线了");
            });
        }
    },
    ajaxPost: function (url, callback) {
        this.ajaxPost(url, null, callback, null, true);
    },
    ajaxPost: function (url, data, callback, before, async) {
        this.ajaxSubmit(url, 'post', data, callback, before, async);
    },
    ajaxGet: function (url, callback) {
        this.ajaxGet(url, null, callback, null, true);
    },
    ajaxGet: function (url, data, callback, before, async) {
        this.ajaxSubmit(url, 'get', data, callback, before, async);
    },
    ajaxSubmit: function (url, type, data, callback, before, async) {
        if (!window.navigator.onLine) { alert("当前没有网络"); return false; }
        if (url.indexOf('?') == -1) { url += "?r=" + Math.random(); }
        $.ajax({
            url: url,
            data: data || null,
            type: type,
            async: typeof async === 'undefined' ? true : !!async,
            beforeSend: before ? before() : function () {
                ajaxTool.options.ajaxLoading();
            },
            success: function (json) {
                ajaxTool.options.ajaxLoading(true);
                if (typeof callback === 'function') {
                    var j;
                    if (typeof json == 'string') {
                        j = ajaxTool.stringToJSON(json);
                    } else {
                        j = json;
                    }
                    callback(j);
                }
            },
            error: function (err) {
                ajaxTool.options.ajaxTip(err, true);
            }
        });
    },
    stringToJSON: function (jsonStr) {
        try {
            var j = null;
            if (JSON) {
                j = JSON.parse(jsonStr);
            } else {
                j = eval("(" + jsonStr + ")");
            }
            return j;
        } catch (e) {
            return null;
        }
    },
    netUtil: {
        addHandler: function (element, type, handler) {
            if (element.addEventListener) {
                element.addEventListener(type, handler, false);
            } else if (element.attachEvent) {
                element.attachEvent("on" + type, handler);
            } else {
                element["on" + type] = handler;
            }
        }
    }
};

//时间格式化字符串,解决ie不能正常显示
Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() == "00" ? 12 : this.getMonth() + 1, //月份   
        "d+": this.getDate(), //日   
        "h+": this.getHours(), //小时   
        "m+": this.getMinutes(), //分   
        "s+": this.getSeconds(), //秒   
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度   
        "S": this.getMilliseconds() //毫秒   
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (o[k]));
    return fmt;
};
//========================================
//   Desc:js的format格式字符串
//  Author：Cupid
//  Date:2015-8-21 
//========================================
String.prototype.format1 = function () {
    var s = this, i = arguments.length; //获取参数个数
    while (i--) {
        s = s.replace(new RegExp('\\{' + i + '\\}', 'gm'), arguments[i]);
    }
    return s;
};
//替换字符串
String.prototype.Replace = function (oldValue, newValue) {
    var reg = new RegExp(oldValue, "g");
    return this.replace(reg, newValue);
};
//========================================
//   Desc:js的format格式字符串
//  Author：Cupid
//  Date:2015-8-21 
//========================================
String.prototype.format = function (obj) {
    var that = this;
    if (typeof obj == "object") {
        for (var attr in obj) {
            var regAttr = eval("/\\{" + attr + "\\}/ig");
            that = that.replace(regAttr, obj[attr]);
        }
    } else {
        //把参数放到数组里面 slice() 方法可从已有的数组中返回选定的元素。
        var arr = [].slice.call(arguments, 1)
        //调用自己
        return that.format(that, arr);
    }
    return that;
};
//========================================
//   Desc:js的format格式字符串
//  Author：Cupid
//  Date:2015-8-21 
//========================================
function format(str, obj) {
    if (typeof obj == "object") {
        for (var attr in obj) {
            str = str.replace("{" + attr + "}", obj[attr]);
        }
    } else {
        //把参数放到数组里面 slice() 方法可从已有的数组中返回选定的元素。
        var arr = [].slice.call(arguments, 1);
        //调用自己
        format(str, arr);
    }
    return str;
}
function IsWeiXin() {
    var ua = navigator.userAgent.toLowerCase();
    if (ua.match(/MicroMessenger/i) == "micromessenger") {
        return true;
    } else {
        return false;
    }
}
//========================================
//   Desc:发送验证码
//  Author：Cupid
//  Date:2015-8-22
//========================================
function SendCode(options) {
    var defaultOpt = {
        mobile: '',
        callback: function (json) {
            if (json.result == 10000) {
                console.log("发送验证码成功");
            } else {
                app.alert(json.msg);
            }
        },//成功回调函数
        bsFunc: function () {
        },
        errorCallBack: function () {
        },//失败回调函数
        id: '',//按钮的id 
        className: 'disabled',//按钮的一个class样式，用来判断是否删除
        text: ''
    }

    options = $.extend(defaultOpt, options);

    $.ajax({
        type: "post",
        url: appUrl("sendcode"),
        beforeSend: options.bsFunc,
        data: { mobile: options.mobile },
        success: function (json) {
            if (typeof options.callback == "function") {
                var result = typeof json == 'string' ? (JSON ? JSON.parse(json) : eval("(" + json + ")")) : json;
                options.callback(result, options.mobile);
            }
            changeState({ id: options.id, className: options.className, text: options.text });
        }, error: function () {
            options.errorCallBack();
            changeState({ id: options.id, className: options.className, text: options.text });
        }
    });
}

//========================================
//   Desc:检验验证码
//  Author：Cupid
//  Date:2015-8-22
//========================================
function CheckCode(options) {
    var defaultOpt = {//默认参数对象
        mobile: '',
        code: '',
        callback: function () {
        },
        bsFunc: function () {
        },
        errorCallBack: function () {
        },
        id: '',//按钮的id名称
        className: 'btn-disabled',//按钮的一个class样式，用来判断是否删除
        text: ''
    };

    options = $.extend(defaultStatus, options);//整合参数

    $.ajax({
        type: 'post',
        url: appUrl("checkcode"),
        beforeSend: options.bsFunc,
        data: { mobile: options.mobile, code: options.code },
        success: function (json) {
            if (typeof options.callback == "function") {
                var result = typeof json == 'string' ? (JSON ? JSON.parse(json) : eval("(" + json + ")")) : json;
                options.callback(result);
            }
            //changeState({ id: options.id, className: options.className, text: options.text });
        }, error: function () {
            options.errorCallBack();
            changeState({ id: options.id, className: options.className, text: options.text });
        }
    });
}

//========================================
//   Desc:检验手机号是否存在
//  Author：Cupid
//  Date:2015-8-22
//========================================
function CheckMobileIsExist(options) {
    var defaultOpt = {//默认参数对象
        mobile: '',
        callback: function () {
        },
        bsFunc: function () {
        },
        errorCallBack: function () {
        },
        id: '',//按钮的id 
        className: 'btn-disabled',//按钮的一个class样式，用来判断是否删除
        text: ''
    };

    options = $.extend(defaultStatus, options);//整合参数

    $.ajax({
        type: 'post',
        url: appUrl("check"),
        beforeSend: options.bsFunc(options.mobile),
        data: { mobile: options.mobile },
        success: function (json) {
            if (typeof options.callback == "function") {
                var result = typeof json == 'string' ? (JSON ? JSON.parse(json) : eval("(" + json + ")")) : json;
                options.callback(result);
            }
            changeState({ id: options.id, className: options.className, text: options.text });
        }, error: function () {
            changeState({ id: options.id, className: options.className, text: options.text });
            options.errorCallBack();
        }
    });
}


function changeState(options) {
    var defalutOpts = {
        id: '',
        className: '',
        text: ''
    }
    options = $.extend(defaultStatus, options);//整合参数
    if (options.id) {
        var targetObj = $(options.id);
        targetObj.removeClass('' + options.className + '');
        options.text && targetObj.text(options.text);
    }
}
//========================================
//   Desc:发送验证码和重新发送验证码
//  Author：Cupid
//  Date:2015-8-22
//========================================
function resendClick(options) { //点击重新发送
    var defaultOpt = {
        btnId: '',//验证码外层元素的id
        callback: ''
    }

    options = $.extend(defaultStatus, options);//整合参数

    var that = $(options.btnId);
    if (!that.hasClass("disabled")) {
        that.addClass("disabled");

        var numWapper = that.find(".num-wapper");
        numWapper.show();

        resendNumTimer = setInterval(function () {
            resend(numWapper, resendNumTimer, options.btnId);
        }, 1000);
        //回调函数
        if (typeof options.callback == "function") {
            options.callback();
        }
    }
};
function resend(numWapper, timer, btnId, time) { //按钮倒计时方法
    var num = numWapper.find(".num"),
        numText = parseInt(num.text());

    if (numText > 0) {
        --numText;
        num.text(numText);
    } else {
        num.text(60);//88
        numWapper.hide().parents(btnId).removeClass("disabled");
        clearInterval(timer);
    }
}

function htmlEncode(str) {
    var s = str;
    if (str.length == 0) return "";
    //s = str.replace(/&/g, "&gt;");
    s = s.replace(/</g, "&lt;");
    s = s.replace(/>/g, "&gt;");
    // s = s.replace(/ /g, "&nbsp;");
    // s = s.replace(/\'/g, "&#39;");
    // s = s.replace(/\"/g, "&quot;");
    // s = s.replace(/\n/g, "");
    return s;
}

//========================================
//   Desc:IPhone手机失去焦点
//  Author：Cupid
//  Date:2015-8-27
//========================================
function hideKeyboard() {
    if (navigator.userAgent.toUpperCase().indexOf('IPHONE') != -1 || !IsMobile()) {
        document.activeElement.blur();
        var inputs = document.querySelectorAll('input');
        for (var i = 0; i < inputs.length; i++) {
            inputs[i].blur();
        }
    }
};

document.addEventListener(clickEventName.touchstart, function (e) {
    if (navigator.userAgent.toUpperCase().indexOf('IPHONE') != -1 || !IsMobile()) {
        if (!isTextInput(e.target) && isTextInput(document.activeElement)) {
            document.activeElement.blur();
        }
    }
}, false);
//document.addEventListener(clickEventName.touchend, function (e) {
//    if (navigator.userAgent.toUpperCase().indexOf('IPHONE') != -1) {
//        if (!isTextInput(e.target) && isTextInput(document.activeElement)) {
//            document.activeElement.blur();
//        }
//    }
//}, false);

function isTextInput(node) {
    if (node.id == 'chart_title') {
        return false;
    } else {
        return ['INPUT', 'TEXTAREA'].indexOf(node.nodeName) !== -1;
    }
}


/*
// wsa 
//时间转换函数(需要什么格式自己可以添加，但是方面名称不能改变.......)
*/
var arrMonth = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

function DateTime(id, type) {
    var result;
    var myDate = new Date(id);
    var yaer = myDate.getYear();        //获取当前年份(2位)
    var fullyaer = myDate.getFullYear();    //获取完整的年份(4位,1970-????)
    var month = (myDate.getMonth() + 1);       //获取当前月份(0-11,0代表1月)
    var date = myDate.getDate();        //获取当前日(1-31)
    var day = myDate.getDay();         //获取当前星期X(0-6,0代表星期天)
    //var time = myDate.getTime();        //获取当前时间(从1970.1.1开始的毫秒数)
    var hours = myDate.getHours();       //获取当前小时数(0-23)
    var minutes = myDate.getMinutes();     //获取当前分钟数(0-59)
    var seconds = myDate.getSeconds();     //获取当前秒数(0-59)
    var milliseconds = myDate.getMilliseconds();    //获取当前毫秒数(0-999)
    switch (type) {
        case 0:
            result = fullyaer.toString() + "/" + month + "/" + date;
            break;
        case 1://15/3/7
            result = fullyaer.toString().substring(2) + "/" + month + "/" + date;
            break;
        case 2://2015.3.7
            result = fullyaer + "." + month + "." + date;
            break;
        case 3: //July 25, 2015 20点
            result = arrMonth[month - 1] + " " + date + ",  " + fullyaer + " " + hours + "点"
            break;
        case 4://个性化时间... 几分钟 、几小时前......
            result = GetDateDiff(id);
            break;
    }
    return result;
}

//个性化时间
function GetDateDiff(id, style) {
    style = style || 4;
    var minute = 1000 * 60;
    var hour = minute * 60;
    var day = hour * 24;
    var halfamonth = day * 15;
    var month = day * 30;
    var now = Date.parse(new Date());
    var diffValue = now - (typeof id === 'number' ? id : Date.parse(id));
    if (diffValue < 0) {
        //alert("结束日期不能小于开始日期！");
    }
    var monthC = diffValue / month;
    var weekC = diffValue / (7 * day);
    var dayC = diffValue / day;
    var hourC = diffValue / hour;
    var minC = diffValue / minute;
    var result;
    if (monthC >= 1) {
        return DateTime(id, 1);
    } else if (weekC >= 1) {
        result = parseInt(weekC) + "星期前";
    } else if (dayC >= 1) {
        result = parseInt(dayC) + "天前";
    } else if (hourC >= 1) {
        result = parseInt(hourC) + "小时前";
    } else if (minC >= 1) {
        result = parseInt(minC) + "分钟前";
    } else
        result = "刚刚";
    return result;
};
/* 时间转换函数 end  */

//========================================
//   Desc:Guid
//  Author：Cupid
//  Date:2015-8-28
//========================================  
$.Guid = function () {
    var s4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return (s4() + s4() + s4() + s4() + s4() + s4() + s4() + s4());
};

$.Guid2 = function () {
    var s4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return (s4() + s4() + "-" + s4() + "-" + s4() + "-" + s4() + "-" + s4() + s4() + s4());
};

//========================================
//  Desc:点击人物，查看某人空间传值
//  Author：fyp
//  Date:2015-9-16
//========================================  
var pubFigure = {
    saveNumber: function (no) {
        envObj.SaveLocals('pubFigure_userCvNumber', no);
    },
    getCvNumber: function () {
        var no = envObj.GetLocals('pubFigure_userCvNumber');
        if (no) { return no; } else { this.saveNumber(rucUserInfo.cvnumber); return this.getCvNumber(); }
    },
    setFigureSearchOptions: function (str) {
        envObj.SaveLocals('pageSelecter_UserSearch', str);
    },
    getFigureSearchOptions: function () {
        var option = envObj.GetLocals('pageSelecter_UserSearch');
        if (option) {
            return option;
        }
        return "";
    },
    hasSearchOptions: function () {
        var option = envObj.GetLocals('pageSelecter_UserSearch_hasOptions');
        if (option == null || option == 'true') { return true; } return false;
    },
    hasSearchOptionsChanged: function () {
        var option = envObj.GetLocals('pageSelecter_UserSearch_optionsChanged');
        if (option == 'true') { return true; } return false;
    },
    removeFigureSearchOptions: function () {
        envObj.RemoveLocals('pageSelecter_UserSearch');
    },
    removeMycollectfigureItem: function (cvnumber) { //删除收藏缓存
        if (pageFigure.removeMycollectfigureItem) {
            pageFigure.removeMycollectfigureItem(cvnumber);
        }
    },
    collect: function (cvnumber, collectCvNumber, iscollect, callback) {
        ajaxTool.ajaxPost(appUrl('user/collect'), {
            cvnumber: cvnumber, collectCvNumber: collectCvNumber, iscollect: iscollect
        }, function (result) {
            if (result.result == 10000) {
                callback();
            } else {
                app.alert('收藏失败，请点击重试');
            }
        });
    },
    iscollect: function (cvnumber, collectCvNumber, callback) {
        ajaxTool.ajaxGet(appUrl('user/iscollect'), { cvnumber: cvnumber, collectCvNumber: collectCvNumber }, function (result) {
            if (result.result == 10000) {
                callback(result.data.collect);
            }
        })
    },
    hasNewMsg: function (cv, callback) {
        callback({ msg: true });
    }
};
var pubArticle = {
    saveNumber: function (no) {
        envObj.SaveLocals('pubArticle_userCvNumber', no);
    },
    getCvNumber: function () {
        var no = envObj.GetLocals('pubArticle_userCvNumber');
        if (no) { return no; } else { this.saveNumber(rucUserInfo.cvnumber); return this.getCvNumber(); }
    }
};
//头像统一替换
function appReplaceImg(serverUrl, img) {
    serverUrl = serverUrl || appConfig.imgUrl;
    if (img) {
        var newImg = img.toLowerCase();
        if (newImg.indexOf('http') > -1) {
            return img;
        }
        return serverUrl + img;
    }
    return 'http://acad.rucslhr.gurucv.com/Imgaes/userImg.jpg';
}

//========================================
//  Desc:足迹列表 时间显示格式化
//  Author：Cupid
//  Date:2015-9-17 16:32:12
//========================================  
/*
type:类型，
date:时间
*/
function dateFunc(type, date) {
    if (!isNull(type) && !isNull(date)) {
        var dateformat, arr;
        if (typeof date == 'number' || /\d{13}/.test(date)) {
            date = new Date(date).toLocaleString().replace(/[\u4e00-\u9fa5]/g, ' ');
        }
        var reg = date.indexOf('-') > -1 ? /-|\s+|:/g : /\/|\s+|:/;
        arr = date.split(reg);
        switch (parseInt(type)) {
            case 0:
                dateformat = '{0}';
                break;
            case 1:
                dateformat = '{0}.{1}';
                break;
            case 2:
                dateformat = '{0}.{1}.{2}';
                break;
            case 3:/*没用*/
                dateformat = '{0}.{1}.{2}';
                break;
            case 4:
                dateformat = '{0}.{1}.{2} {3}:{4}';
                break;
        }
        return dateformat.format(arr);
    } else {
        return ''
    }


}
/*
stype:开始时间类型，
startTime:开始时间,
etype:结束时间类型,
etime:结束时间
*/
function dateSEFunc(stype, stime, etype, etime) {
    var startTime = dateFunc(stype, stime),
        endTime;
    if (!isNull(etime) && !isNull(etype)) {
        endTime = dateFunc(etype, etime);
        return '{0}-{1}'.format([startTime, endTime]);
    }
    return startTime;
}
//========================================
//  Desc:判断是否是合法的url，判断Url是否带有http,如果没有http，自动加上，返回结果
//  Author：Cupid
//  Date:2015-9-17 16:32:12
//========================================  
function IsUrl(url) {
    url = url.trim();
    var reg = /^(http:\/\/|https:\/\/)?[A-Za-z0-9-_]+\.[A-Za-z0-9]+\.[A-Za-z0-9-_%#&\?\/.=]+$/, result = {};
    if (reg.test(url)) {
        result.url = (url.indexOf("http://", 0) == 0 || url.indexOf("https://", 0) == 0) ? url : "http://" + url;
        result.isUrl = true;
    } else {
        result.url = url;
        result.isUrl = false;
    }
    return result;
}

function getTitles(title1, title2, title3) {
    var str = "";
    if (title1 != "") {
        str = title1;
    }
    if (title2 != "") {
        str = str + " " + title2;
    }
    if (title3 != "") {
        str = str + " " + title3;
    }
    return str;
}

//======================================
//  Desc:Jsrender 自定义方法
//  Author：Cupid
//  Date:2015-9-17 16:32:12
//========================================  
$.views.helpers({
    dateSEFunc: function (stype, stime, etype, etime) {//足迹列表 时间显示格式化 
        return dateSEFunc(stype, stime, etype, etime);
    },
    bindBioSum: function (contents) {
        if (!isNull(contents)) {
            return contents.replace(/<[^>]+>/g, "");
        } else {
            return "该用户很懒，没有留下任何人物概述···"
        }

    },
    ImgUrl: function (url) {
        return appReplaceImg(appConfig.imgUrl, url);
    },
    EmojiJM: function (contents) {
        if (!isNull(contents)) {
            return EmojiJM(contents).replace(/<[^>]+>/g, "");
        } else {
            return "该用户很懒，没有留下任何内容···"
        }
    },
    EmojiJMWithHtml: function (contents) {
        return EmojiJM(contents);
    }
})

//客户端写cookie
$.setCookie = function (name, value, days, doamin, path) {
    path = path || '/';
    doamin = doamin || '';
    var expires;
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toGMTString();
    } else {
        expires = "";
    }
    expires = name + "=" + value + expires + "; path=" + path;
    if (doamin.length > 0) {
        expires = expires + "; domain=" + doamin;
    }
    document.cookie = expires;
};
//客户端读cookie
$.getCookie = function (name) {
    var nameEq = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i].trim();
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEq) == 0) return c.substring(nameEq.length, c.length);
    }
    return null;
};
//客户端移除cookie
$.deleteCookie = function (name) {
    $.setCookie(name, "", -10);
};
//判断是否联网
$.onLine = function () {
    $.ajaxSetup({
        timeout: 1, // 1秒超时
        error: function (request, status, maybe_an_exception_object) {
            if (status == 'timeout')
                app.alert("请检查网络连接");
        }
    });
}

/*
微信分享封装，调用方法
   wxShare.init({
        url: 'http://acad.rucslhr.gurucv.com/share/space?cv=' + (pageSpace.userCvNumber || pubFigure.getCvNumber()),
        title: '劳人记忆人物空间',
        desc:'',
        imgUrl: appReplaceImg('', rucUserInfo.headphotos)
    });
*/
var wxShare = {
    config: {
        pageSpace: { deep: 1 },
        pageActivitySee: { deep: 1 },
        pageExperSee: { deep: 1 },
        pageThingSee: { deep: 1 }
    },
    isLoad: false,
    options: {
        page: '',
        title: '',
        desc: '',
        imgUrl: '',
        url: ''
    },
    init: function (options) {
        $.extend(this.options, options);
        if (IsWeiXin()) {
            try {
                this.initWxShare();
            } catch (e) {
                app.alert(e.name + ": " + e.message);
            }
        } else {
            console.log("非微信客户端,不执行相应的分享初始化操作");
        }
    },
    handleDesc: function (desc) {
        if (desc) {
            desc = desc.replace(/<[^>]+>/g, "");//去除html
            desc = desc.replace(/{[^}]+}/g, "");//去除大括号img
            if (desc.length > 50) {
                return desc.substr(0, 50);
            }
            return desc || '来看看我的经历和故事吧';
        }
        return '';
    },
    initWxShare: function () {
        var oldUrl = location.href;
        this.options.url = R.getUrl().endUrl;
        history.replaceState('', '', R.getUrl().url);
        SLOG('开始执行微信分享');
        this.getWXShard(window.location.href, function () {
            var shareKey = wxShare.getMD5Key(wxShare.options.url);
            wx.ready(function () {
                SLOG("wx。Ready生成的shareKey=" + shareKey);
                var url = '';
                if (wxShare.options.url.indexOf('?') > -1) {
                    url = oldUrl + '&key=' + shareKey;
                } else {
                    url = oldUrl + '?key=' + shareKey;
                }
                SLOG("微信分享生成的key为：" + url);
                var shareData = {
                    title: wxShare.options.title,
                    link: url,
                    desc: wxShare.handleDesc(wxShare.options.desc),
                    imgUrl: wxShare.options.imgUrl,
                    trigger: function (res) {
                        SLOG('用户点击了分享到朋友圈');
                        //alert('用户点击分享到朋友圈');
                    },
                    success: function (res) {
                        SLOG('已经分享');
                    },
                    cancel: function (res) {
                        SLOG('用户取消了分享');
                    },
                    fail: function (res) {
                        SLOG('分享失败了');
                    }
                };
                wx.onMenuShareTimeline(shareData);
                wx.onMenuShareAppMessage(shareData);
                //最后在将当前的url改回来
                history.replaceState('', '', oldUrl);
            });
            //最后添加shareKey数据
            wxShare.addShareData(wxShare.options.page, shareKey, function () { });
        });
    },
    getWXShard: function (url, callback) {
        //if (typeof R.wxKey !== 'undefined') {
        //    if (R.wxKey) {
        //        SLOG("R.wxKey不为空 appid:" + R.wxKey.appid + ' signature=' + R.wxKey.signature);
        //        wx.config({
        //            //debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
        //            appId: R.wxKey.appid, // 必填，公众号的唯一标识
        //            timestamp: R.wxKey.timestamp, // 必填，生成签名的时间戳
        //            nonceStr: R.wxKey.noncestr, // 必填，生成签名的随机串
        //            signature: R.wxKey.signature,// 必填，签名，见附录1
        //            jsApiList: ['checkJsApi', 'onMenuShareTimeline', 'onMenuShareAppMessage'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
        //        });
        //        SLOG("执行callback方法");
        //        callback();
        //    } 
        //}
      
        if (this.isLoad) { callback(); } else {
            ajaxTool.ajaxPost(appUrl('/tool/getsign'), { url: url }, function (result) {
                wx.config({
                    //debug: true, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
                    appId: result.appid, // 必填，公众号的唯一标识
                    timestamp: result.timestamp, // 必填，生成签名的时间戳
                    nonceStr: result.noncestr, // 必填，生成签名的随机串
                    signature: result.signature,// 必填，签名，见附录1
                    jsApiList: ['checkJsApi', 'onMenuShareTimeline', 'onMenuShareAppMessage'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
                });
                SLOG('分享的appid：' + result.appid + ' signature=' + result.signature);
                callback();
                wxShare.isLoad = true;
            }, function () {

            });
        }

    },
    addShareData: function (page,shareKey, callback) {
        page = page || this.options.page;//取options的page
        var urlObj = R.getUrl();
        var url = this.options.url;
        var domain = urlObj.url;
        var deep = this.config[page] ? this.config[page].deep : 0;
        var data = {
            url: url,
            fullurl: domain + '?' + url,
            deep: deep,
            cvnumber: (getCurrentCV() || 0),
            shareKey:shareKey
        };
        ajaxTool.ajaxPost(appUrl('/user/share'), data, function (result) {
            if (result.result == 10000) {
                var key = result.msg;
                if (typeof callback === 'function') {
                    callback(key);
                }
            } else {
                app.alert('生成分享url失败，请重试！');
            }
        });
    },
    getMD5Key:function(url){
        var cv = getCurrentCV() || 0;
        var date = (new Date()).getTime();
        var str = url + cv.toString() + date.toString();
        var md5 = MD5(str);
        console.log("生成 的md5：" + md5);
        return md5;
    },
    getShareInfo: function (key, callback) {
        ajaxTool.ajaxGet(appUrl('/user/sharekey'), { key: key }, function (result) {
            log(result);
            if (result.result == 10000) {
                if (typeof callback === 'function') {
                    callback(result.data[0]);
                }
            } else {
                app.alert('获取分享url失败，请重试');
            }
        })
    }
}
var hex_chr = "0123456789abcdef";
function rhex(num) 
{ 
    str = ""; 
    for(j = 0; j <= 3; j++) 
        str += hex_chr.charAt((num >> (j * 8 + 4)) & 0x0F) + 
        hex_chr.charAt((num >> (j * 8)) & 0x0F); 
    return str; 
} 
function str2blks_MD5(str) 
{ 
    nblk = ((str.length + 8) >> 6) + 1; 
    blks = new Array(nblk * 16); 
    for(i = 0; i < nblk * 16; i++) blks[i] = 0; 
    for(i = 0; i < str.length; i++) 
        blks[i >> 2] |= str.charCodeAt(i) << ((i % 4) * 8); 
    blks[i >> 2] |= 0x80 << ((i % 4) * 8); 
    blks[nblk * 16 - 2] = str.length * 8; 
    return blks; 
} 
function add(x, y) 
{ 
    var lsw = (x & 0xFFFF) + (y & 0xFFFF); 
    var msw = (x >> 16) + (y >> 16) + (lsw >> 16); 
    return (msw << 16) | (lsw & 0xFFFF); 
} 
function rol(num, cnt) 
{ 
    return (num << cnt) | (num >>> (32 - cnt)); 
} 
function cmn(q, a, b, x, s, t) 
{ 
    return add(rol(add(add(a, q), add(x, t)), s), b); 
} 
function ff(a, b, c, d, x, s, t) 
{ 
    return cmn((b & c) | ((~b) & d), a, b, x, s, t); 
} 
function gg(a, b, c, d, x, s, t) 
{ 
    return cmn((b & d) | (c & (~d)), a, b, x, s, t); 
} 
function hh(a, b, c, d, x, s, t) 
{ 
    return cmn(b ^ c ^ d, a, b, x, s, t); 
} 
function ii(a, b, c, d, x, s, t) 
{ 
    return cmn(c ^ (b | (~d)), a, b, x, s, t); 
} 
function MD5(str) 
{ 
    x = str2blks_MD5(str); 
    var a = 1732584193; 
    var b = -271733879; 
    var c = -1732584194; 
    var d = 271733878; 
    for(i = 0; i < x.length; i += 16) 
    { 
        var olda = a; 
        var oldb = b; 
        var oldc = c; 
        var oldd = d; 
        a = ff(a, b, c, d, x[i+ 0], 7 , -680876936); 
        d = ff(d, a, b, c, x[i+ 1], 12, -389564586); 
        c = ff(c, d, a, b, x[i+ 2], 17, 606105819); 
        b = ff(b, c, d, a, x[i+ 3], 22, -1044525330); 
        a = ff(a, b, c, d, x[i+ 4], 7 , -176418897); 
        d = ff(d, a, b, c, x[i+ 5], 12, 1200080426); 
        c = ff(c, d, a, b, x[i+ 6], 17, -1473231341); 
        b = ff(b, c, d, a, x[i+ 7], 22, -45705983); 
        a = ff(a, b, c, d, x[i+ 8], 7 , 1770035416); 
        d = ff(d, a, b, c, x[i+ 9], 12, -1958414417); 
        c = ff(c, d, a, b, x[i+10], 17, -42063); 
        b = ff(b, c, d, a, x[i+11], 22, -1990404162); 
        a = ff(a, b, c, d, x[i+12], 7 , 1804603682); 
        d = ff(d, a, b, c, x[i+13], 12, -40341101); 
        c = ff(c, d, a, b, x[i+14], 17, -1502002290); 
        b = ff(b, c, d, a, x[i+15], 22, 1236535329); 
        a = gg(a, b, c, d, x[i+ 1], 5 , -165796510); 
        d = gg(d, a, b, c, x[i+ 6], 9 , -1069501632); 
        c = gg(c, d, a, b, x[i+11], 14, 643717713); 
        b = gg(b, c, d, a, x[i+ 0], 20, -373897302); 
        a = gg(a, b, c, d, x[i+ 5], 5 , -701558691); 
        d = gg(d, a, b, c, x[i+10], 9 , 38016083); 
        c = gg(c, d, a, b, x[i+15], 14, -660478335); 
        b = gg(b, c, d, a, x[i+ 4], 20, -405537848); 
        a = gg(a, b, c, d, x[i+ 9], 5 , 568446438); 
        d = gg(d, a, b, c, x[i+14], 9 , -1019803690); 
        c = gg(c, d, a, b, x[i+ 3], 14, -187363961); 
        b = gg(b, c, d, a, x[i+ 8], 20, 1163531501); 
        a = gg(a, b, c, d, x[i+13], 5 , -1444681467); 
        d = gg(d, a, b, c, x[i+ 2], 9 , -51403784); 
        c = gg(c, d, a, b, x[i+ 7], 14, 1735328473); 
        b = gg(b, c, d, a, x[i+12], 20, -1926607734); 
        a = hh(a, b, c, d, x[i+ 5], 4 , -378558); 
        d = hh(d, a, b, c, x[i+ 8], 11, -2022574463); 
        c = hh(c, d, a, b, x[i+11], 16, 1839030562); 
        b = hh(b, c, d, a, x[i+14], 23, -35309556); 
        a = hh(a, b, c, d, x[i+ 1], 4 , -1530992060); 
        d = hh(d, a, b, c, x[i+ 4], 11, 1272893353); 
        c = hh(c, d, a, b, x[i+ 7], 16, -155497632); 
        b = hh(b, c, d, a, x[i+10], 23, -1094730640); 
        a = hh(a, b, c, d, x[i+13], 4 , 681279174); 
        d = hh(d, a, b, c, x[i+ 0], 11, -358537222); 
        c = hh(c, d, a, b, x[i+ 3], 16, -722521979); 
        b = hh(b, c, d, a, x[i+ 6], 23, 76029189); 
        a = hh(a, b, c, d, x[i+ 9], 4 , -640364487); 
        d = hh(d, a, b, c, x[i+12], 11, -421815835); 
        c = hh(c, d, a, b, x[i+15], 16, 530742520); 
        b = hh(b, c, d, a, x[i+ 2], 23, -995338651); 
        a = ii(a, b, c, d, x[i+ 0], 6 , -198630844); 
        d = ii(d, a, b, c, x[i+ 7], 10, 1126891415); 
        c = ii(c, d, a, b, x[i+14], 15, -1416354905); 
        b = ii(b, c, d, a, x[i+ 5], 21, -57434055); 
        a = ii(a, b, c, d, x[i+12], 6 , 1700485571); 
        d = ii(d, a, b, c, x[i+ 3], 10, -1894986606); 
        c = ii(c, d, a, b, x[i+10], 15, -1051523); 
        b = ii(b, c, d, a, x[i+ 1], 21, -2054922799); 
        a = ii(a, b, c, d, x[i+ 8], 6 , 1873313359); 
        d = ii(d, a, b, c, x[i+15], 10, -30611744); 
        c = ii(c, d, a, b, x[i+ 6], 15, -1560198380); 
        b = ii(b, c, d, a, x[i+13], 21, 1309151649); 
        a = ii(a, b, c, d, x[i+ 4], 6 , -145523070); 
        d = ii(d, a, b, c, x[i+11], 10, -1120210379); 
        c = ii(c, d, a, b, x[i+ 2], 15, 718787259); 
        b = ii(b, c, d, a, x[i+ 9], 21, -343485551); 
        a = add(a, olda); 
        b = add(b, oldb); 
        c = add(c, oldc); 
        d = add(d, oldd); 
    } 
    return rhex(a) + rhex(b) + rhex(c) + rhex(d); 
} 


var appUserIdentity = {
    flag: {
        e: 1,//阶段
        p: 2,//职能
        x: 3,//系
        z: 4,//专业
        b: 5,//班级
        y: 8 //年份
    },
    data: [],
    get: function (cv, callback) {
        this.getid(cv, function (data) {
            appUserIdentity.data = data;
            var t = appUserIdentity.getResult();
            callback(t);
        });
    },
    getid: function (cv, callback) {
        ajaxTool.ajaxGet(appUrl('user/identity'), { cvnumber: cv, pid: 0 }, function (result) {
            if (result.result == 10000) {
                callback(result.data);
            }
        });
    },
    //根据flag获取相应的数据
    handle: function (f) {
        var json = this.data;
        var id = $.grep(json, function (item, i) {
            return item.flag == f
        });
        return id;
    },
    handleText: function (g,id) {
        var json = this.data;
        var j = $.grep(json, function (item, i) {
            return item.flag == 0 && item.jid == g && item.GroupId == id;
        });
        if (j.length) {
            return ' ' + j[0].id_name;
        }
        return '';
    },
    handleGroup: function (f, g) {
        f = parseInt(f);
        var json = this.data;
        var id = $.grep(json, function (item, i) {
            return item.flag == f && item.GroupId == g;
        });
        if (id.length) {
            return id[0];
        } else {
            return { id_name: '', title: '' };
        }
    },
    detail: function (i) {
        var json = this.data;
        var id = $.grep(json, function (item, i) {
            return item.groupid == i;
        });
        return id;
    },
    getResult: function () {
        var identities = this.handle(9);//获取身份信息，第一级别
        var result = [];
        for (var i = 0; i < identities.length; i++) {
            var item = {
                id: identities[i].id,
                name: identities[i].id_name,
                flag: identities[i].flag,
                jid: identities[i].jid
            };
            var titles = '';
            var detail = this.detail(item.id);

            switch (item.jid) {
                case 4://职工
                   // item.name = '教职工';
                    var x = this.handleGroup(this.flag.x, item.id);
                    var allI = xzbTool.data.allIDSelected();
                    var id = $.grep(allI, function (it, i) {
                        return it.RegId == item.jid;
                    });
                    var po = '';
                    if (id.length) {
                        var text = $.grep(id, function (item, i) {
                            return parseInt(item.Operation) == 0;
                        });
                        if (text.length) {
                            po = this.handleText(text[0].ColumnId, item.id);
                        }
                    }
                    titles = x.id_name + '  ' + po;
                    break;
                case 3://老师
                    //item.name = '教职工';
                    titles = this.handleGroup(this.flag.x, item.id).id_name + '  ' + this.handleGroup(this.flag.p, item.id).id_name;
                    break;
                case 2://校友
                    //item.name = '校友';
                    titles = this.handleGroup(this.flag.y, item.id).id_name + this.handleGroup(this.flag.e, item.id).id_name + '  ' + this.handleGroup(this.flag.b, item.id).id_name;
                    break;
                case 1://学生
                    //item.name = '在校生';
                    titles = this.handleGroup(this.flag.y, item.id).id_name + this.handleGroup(this.flag.e, item.id).id_name + '  ' + this.handleGroup(this.flag.b, item.id).id_name;
                    break;
                default://其他
                    var allI = xzbTool.data.allIDSelected();
                    var id = $.grep(allI, function (it, i) {
                        return it.RegId == item.jid;
                    });
                    if (id.length) {
                        var selected = $.grep(id, function (item, i) {
                            return parseInt(item.Operation) > 0;
                        });
                        var text = $.grep(id, function (item, i) {
                            return parseInt(item.Operation) == 0;
                        });
                        if (selected.length) {
                            titles = this.handleGroup(selected[0].DataId, item.id).id_name;
                            if (text.length) {
                                titles += this.handleText(text[0].ColumnId,item.id);
                            }
                        } else {
                            if (text.length) {
                                switch (text.length) {
                                    case 1:
                                        titles = this.handleText(text[0].ColumnId,item.id);
                                        break;
                                    case 2:
                                        titles = this.handleText(text[0].ColumnId,item.id) + ',' + this.handleText(text[1].ColumnId,item.id);
                                        break;
                                }
                               
                            }
                        }

                    }
                    break;
            }
            item.titles = titles;
            result.push(item);
        }
        //得到结果需要在遍历一遍，这里写死
        var idLast = {};
        for (var i = 0; i < result.length; i++) {
            if (!idLast[result[i].jid]) {
                idLast[result[i].jid] = [];
            }
            //这里会存储多个身份
            idLast[result[i].jid].push(result[i]);
        }
        var allI = xzbTool.data.allI();
        var t = [];
        for (var i = 0; i < allI.length; i++) {
            if (idLast[allI[i].id]) {
                t.push({ name: allI[i].name, titles: idLast[allI[i].id.toString()] });
            }
        }
        return t;
    },
}

var appUser = {
    gettag: function (cvnumber, tag, success) {
        this.db.open(function () {
            appUser.db.get(cvnumber, function (result) {
                if (result != undefined) {
                    if (typeof result != 'object') {
                        result = JSON.parse(result);
                    }
                    var tags = tag == 1 ? result.ability_tag : result.achieve_tag;
                    success(tags);
                }
            });
        });
    },
    getid: function (cvnumber, success) {
        this.db.open(function () {
            appUser.db.get(cvnumber, function (result) {
                if (result != undefined) {
                    var user = appUser.data.handleId(result);
                    success(user);
                } else {
                    appUser.set({ cvnumber: cvnumber, pid: 0 }, function (result) {
                        appUser.db.get(cvnumber, function (result) {
                            if (result != undefined) {
                                var user = appUser.data.handleId(result);
                                success(user);
                            }
                        });
                    });
                }
            });
        });
    },
    getfromServer: function (cvnumber, success) {
        var url = appUrl('user/info')
        var data = { cvnumber: cvnumber };
        ajaxTool.ajaxGet(url, data, function (result) {
            log(result);
        });
    },
    get: function (cvnumber, success, error) {
        this.db.open(function () {
            appUser.db.get(cvnumber, function (result) {
                if (result != undefined) {
                    var user = appUser.data.handle(result);
                    success(user);
                } else {
                    appUser.set({ cvnumber: cvnumber, pid: 0 }, function (result) {
                        appUser.db.get(cvnumber, function (result) {
                            if (result != undefined) {
                                var user = appUser.data.handle(result);
                                success(user);
                            }
                        });
                    });
                }
            });
        });
    },
    set: function (info, success) {
        this.db.open(function () {
            appUser.db.add(info, success)
        });
    },
    update: function (cvnumber, name, value, success, error) {
        this.db.open(function () {
            appUser.db.update(cvnumber, name, value, success, error);
        });
    },
    db: {
        name: 'AppUserBaseInfo',
        key: 'cvnumber',
        url: '/user/info',
        updateUrl: '/user/edit',
        open: function (callback) {
            IndexDB.openDB(this.name, [{ name: this.name, id: this.key }], callback, 1);
        },
        add: function (data, success) {
            // LoadData 获取并添加到库里  
            var url = '/' + R.info.global.platform + this.url;
            IndexDB.LoadData(this.name, url, data, false, success);
        },
        get: function (cvnumber, callback) {
            IndexDB.Select(this.name, cvnumber, callback)
        },
        toServer: function () {
            IndexDB.toServer(this.name, this.key, function (data) {
                log(data);
            });
        },
        update: function (key, name, value, success, error) {
            //(tbName, indexId, url, upfun, success, db)
            var url = '/' + R.info.global.platform + this.updateUrl;
            IndexDB.editData(this.name, key, url, function (result) {
                if (typeof result != 'object') {
                    result = eval("(" + result + ")");
                }
                var user = appUser.data.handle(result);
                result.info[0][name] = value;
                if (name == 'ability_tag' || name == 'achieve_tag') {
                    // IsUpdateTag TagType
                    user.isupdatetag = true;
                    user.tagtype = name == 'ability_tag' ? 1 : 2;//1能力 2 成就
                    //更新result的value
                    if (name == 'ability_tag') {
                        result.ability_tag = [];
                        var arr = value.split('|');
                        for (var i = 0; i < arr.length; i++) {
                            result.ability_tag.push({
                                id: 0, name: arr[i]
                            });
                        }
                        user.ability_tag = value;
                    }
                    if (name == 'achieve_tag') {
                        result.achieve_tag = [];
                        var arr = value.split('|');
                        for (var i = 0; i < arr.length; i++) {
                            result.achieve_tag.push({
                                id: 0, name: arr[i]
                            });
                        }
                        user.achieve_tag = value;
                    }
                } else {
                    user[name] = EmojiBM(value);//表情编码
                }
                return {
                    ajaxParam: user,//ajax参数 list  
                    dbParam: result//保存到本地数据库的内容
                };
            }, function () {
                log('修改' + key + '的值为 ' + value + ' 成功');
                if (typeof success === 'function') {
                    success();
                }

            });
        },
        deletedb: function () {
            indexedDB.deleteDatabase(this.name + R.info.global.platform);
        }
    },
    data: {
        handleId: function (result) {
            if (typeof result != "object") {
                result = eval("(" + result + ")");
            }
            return result.identity;
        },
        handle: function (result) {
            if (typeof result != "object") {
                result = eval("(" + result + ")");
            }
            var user = {};
            var ability = ''
            var achieve = '';
            $.each(result.achieve_tag, function (i, item) {
                achieve += item.name;
                if (i != result.achieve_tag.length - 1) {
                    achieve += ',';
                }
            });
            $.each(result.ability_tag, function (i, item) {
                ability += item.name;
                if (i != result.ability_tag.length - 1) {
                    ability += ',';
                }
            });
            user = result.info.length ? result.info[0] : {};
            user.ability_tag = ability;
            user.achieve_tag = achieve;
            return user;
        }
    }
};

//======================================
//  Desc: 去掉html
//  Author：Cupid
//  Date:2015-10-13 11:14:39
//========================================  
function dropHtml(val) {
    //return val.replace(/(<span([^>]+)>)/ig, '')
    //                   .replace(/<\/span>/ig, "").replace(/(<img([^>]+)>)/ig, "")
    //                   .replace(/<div><\/div>/ig, '')
    //                   .replace(/(<div([^>]+)>)/ig, "<p>")
    //                   .replace(/<\/div>/ig, "</p>")
    //                   .replace(/<p><\/p>/ig, '')
    //                   .replace(/}<\/p><p>{/ig, "}{");
    return val.replace(/<[^>]+>/g, "");
}
//======================================
//  Desc: 生成随机数Guid
//  Author：zx
//  Date:2015-10-14 15:39:21
//========================================  
function guidGenerator() {
    var S4 = function () {
        return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
    };
    return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
}

//======================================
//  Desc: url生成
//  Author：url生成
//  Date:2015-12-10 18:25:00
/*
效果 url("login")   ===>/ruc/login
*/
//========================================  
function appUrl(url) {
    if (!isNull(url)) {
        return '/' + R.info.global.platform + '/' + url;
    }
}
//======================================
//  Desc:localStorage操作方法
//  Author：赵晓
//  Date:2015-12-11 16:31:09
//========================================  
var envObj = {
    SaveLocals: function (name, data) {
        localStorage.setItem(name, data);
    },
    GetLocals: function (name) {
        return localStorage.getItem(name);
    },
    RemoveLocals: function (name) {
        localStorage.removeItem(name);
    }
}
//======================================
//  Desc:切换身份选项卡
//  Author：Cupid
//  Date:2015-12-15 11:17:17
/*
e:时间对象
selectId：身份选择外层的div的id；
*/
//========================================  
function switchIdentity(e, selectId, selectList) {
    var that = $(e.target),
        data = xzbTool.data.alltemplateType(),
        tageIndex = that.attr("data-type"),
        topSelectId = $(selectId).find("#tag" + tageIndex);

    if (that.hasClass("shenfen-curent")) return false;
    that.addClass("shenfen-curent").siblings("span").removeClass("shenfen-curent");
    topSelectId.addClass('show').show().siblings().removeClass('show').hide();
}

function showSelect(obj, parentID) {
    var pThat = $(parentID).find('div.show'),
       pEle = pThat['selector'];
    obj.on(".selectobj", "touchend", function (e, ev) {
        var that = $(e.target),
            selectid = that.attr('data-selectid'),
            listCroll = pEle + " #list" + selectid,
            oSelecter = that.parents('.table-view').next('.selecter');
        $(".modal-over-back").addClass("modal-overlay-visible");
        oSelecter.addClass('selecter-in');
        app.iscroll(listCroll);
        if (parseInt(selectid) == 5) {
            app.iscroll(pEle + " #class-name-list");
        }
    });
    selectClassChanged(obj, parentID);
}

//选择
function selectIdentity(obj, selectId) {
    obj.on(".btn-checkbox", "touchend", function (e, ev) {
        var that = $(ev.self),
            text = that.text();
        that.parents('.selecter-in').prev('ul').find('span.navigate-right').text(text);

        if (that.hasClass('on')) {
            $(".selecter-in").removeClass("selecter-in");
            $(".modal-over-back").removeClass("modal-overlay-visible");
            return false;
        } else {
            var span = that.parent(".table-view-cell").siblings('.table-view-cell').find("span.on");
            if (span.length > 0) {
                span.next("input[type=hidden]").val("off");
                span.removeClass('on');
            }

            that.addClass('on').next("input[type=hidden]").val("on");
            $(".selecter-in").removeClass("selecter-in");
            $(".modal-over-back").removeClass("modal-overlay-visible");
        }
    });
}
//班级条件变化
function selectClassChanged(obj, parentID) {
    var that = $(parentID).find('div.show'),
        ele = that['selector'] + " #banji";
    //年级
    obj.on('.selecter-left-list>ul>li', 'touchend', function (e, ev) {
        var $this = $(ev.self);
        $this.addClass('current').siblings().removeClass('current');
        var r = getCurrentYE(obj, parentID);
        log(r);
        xzbTool.bind.bindClass(ele, r);
    });
    //阶段
    obj.on('.selecter-right-title>span', 'touchend', function (e, ev) {
        var $this = $(ev.self);
        $this.addClass('current').siblings().removeClass('current');
        var r = getCurrentYE(obj, parentID);
        log(r);
        xzbTool.bind.bindClass(ele, r);
    });
}
//获取当前选中条件
function getCurrentYE(obj, parentID) {
    var that = $(parentID).find('div.show');
    var year = that.find('#list5').find("ul").find('li.current');
    var eid = that.find("div.selecter-right").find("div.selecter-right-title").find('span.current');
    log(eid);
    var r = {
        year: year.length ? year.data('joinid') : 0,
        eid: eid.length ? eid.data('joinid') : 0
    }
    return r;

}


//IndexDB
var IndexDB = {
    dataDB: window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB,
    _pageDB: { dbName: "", tabNames: "", db: null, version: 1 },

    /*	-------------------------------------------------------------------------------
*	方法	openDB 	//链接数据库 --创建 或者打开	Date:15.12.5	Author:zhao
*	@param 	dbName	: 	str.	本地数据库名称
* 	@param 	tbNames	: 	数组.	表名数据 一个裤下面 可以有多个 表 同时创建 [{name:"",id:""},{name:"",id:""}]
* 	@param 	success	: 	function 回调函数 成功打开数据库后 调用
* 	@return	无
*/
    openDB: function (dbName, tbNames, success, version) {
        if (is_weixin()) { // 加！才对
            var dbName = dbName + R.info.global.platform;
            try {
                IndexDB._pageDB.db = window.openDatabase(dbName, version, dbName, 5 * 1024 * 1024);
            } catch (e) {
                console.log(e);
                // 这里开始异常处理 . 
            }
            if (!IndexDB._pageDB.db) {
                return false;
            }
            IndexDB._pageDB.db.transaction(function (context) {
                $.each(tbNames, function (i, item) {
                    context.executeSql('CREATE TABLE IF NOT EXISTS ' + item.name + ' (cvnumber REAL UNIQUE, data)', [], function () {
                        console.log('创建表成功');
                    }, function (tx, error) {
                        console.log('创建表失败:' + error.message);
                    });
                });
            }, function (e) {
                console.log(e);
            }, function () {
                IndexDB._pageDB.dbName = dbName;
                IndexDB._pageDB.tabNames = tbNames;
                if (success != undefined) {
                    success();
                }
            });

        } else {
            var dbName = dbName + R.info.global.platform;
            var version = version || 1;
            var isIndex = isIndex || false;
            var request = IndexDB.dataDB.open(dbName, version);
            request.onerror = function (e) {
                console.log(e.currentTarget.error.message);
            };
            request.onsuccess = function (e) {
                IndexDB._pageDB.db = e.target.result;
                IndexDB._pageDB.dbName = dbName;
                IndexDB._pageDB.tabNames = tbNames;
                if (success != undefined) {
                    success();
                }
            };
            request.onupgradeneeded = function (e) {
                var db = e.target.result;
                $.each(tbNames, function (i, item) {
                    if (!db.objectStoreNames.contains(item.name)) {
                        var store = db.createObjectStore(item.name, { keyPath: item.id });
                        //if (isIndex) { //索引后完善
                        //    store.createIndex('idIndex', ['id', 'cvnumber'], { unique: false });
                        //}
                    }
                });
            };
        }
    },

    /*	-------------------------------------------------------------------------------
*	方法	LoadData 	//将数据集同步到数据库 （先清表 再获取）	Date:15.12.5	Author:zhao
*	@param 	tbName	: 	str.	要操作的表名
* 	@param 	url	: 	str 要获取数据的 后台方法路径
*	@param 	data	: 	{}  ajax 参数
*	@param 	isListData	: 	bool  ajax 获取的是 列表还是 单个数据
*	@param 	success	: 	function  成功回调函数
    @param 	db	: 	要操作的 裤的对象 一般不用传
* 	@return	无
*/
    LoadData: function (tbName, url, data, isListData, success, db) {
        var db = db || IndexDB._pageDB.db;
        if (is_weixin()) {// 加！才对
            //先清空表
            db.transaction(function (tx) {
                tx.executeSql("delete from " + tbName, [], function () {
                    //成功后 添加数据
                    $.ajax({
                        url: url,
                        data: data,
                        type: "Get",
                        dataType: 'json',
                        success: function (result) {
                            var json = result
                            if (json.result == 10000) {
                                var obj = json.data;
                                if (isListData) {
                                    for (var i = 0; i < obj.length; i++) {
                                        db.transaction(function (tx) {
                                            tx.executeSql(
                                                "INSERT INTO " + tbName + " (cvnumber, data) values(?, ?)",
                                                [obj[i].cvnumber, JSON.stringify(obj[i])],
                                                function () {
                                                    if (success != undefined) {
                                                        success();
                                                    }
                                                },
                                                function (tx, error) { console.log(error); }
                                            );
                                        });
                                    }
                                } else {
                                    db.transaction(function (tx) {
                                        tx.executeSql(
                                            "INSERT INTO " + tbName + " (cvnumber, data) values(?, ?)",
                                            [obj.cvnumber, JSON.stringify(obj)],
                                            function () {
                                                if (success != undefined) {
                                                    success();
                                                }
                                            },
                                            function (tx, error) { console.log(error); }
                                        );
                                    });
                                }
                            }
                        },
                        error: function (er) {
                            console.log("服务器获取失败");
                        }
                    });
                }, function (e, error) {
                    console.log("清空表失败");
                });
            });
        } else {
            //先清除旧数据
            var transaction = db.transaction(tbName, 'readwrite');
            var store = transaction.objectStore(tbName);
            var clearRequest = store.clear();
            clearRequest.onsuccess = function () {
                $.ajax({
                    url: url,
                    data: data,
                    type: "Get",
                    dataType: 'json',
                    success: function (result) {
                        var json = result
                        if (json.result == 10000) {
                            var transaction = db.transaction(tbName, 'readwrite');
                            var objectStore = transaction.objectStore(tbName);
                            var obj = json.data;
                            var addRequest = null;
                            if (isListData) {
                                for (var i = 0; i < obj.length; i++) {
                                    addRequest = objectStore.put(obj[i]);
                                }
                            } else {
                                addRequest = objectStore.put(obj);
                            }
                            addRequest.onsuccess = function () {
                                if (success != undefined) {
                                    success();
                                }
                            };
                            addRequest.onerror = function (e) {
                                console.log("添加失败");
                                console.log(e);
                            }
                        }
                    },
                    error: function (er) {
                        console.log("服务器获取失败");
                    }
                });
            };
            clearRequest.onerror = function (e) {
                console.log("清表失败");
                console.log(e);
            }
        }
    },

    /*	-------------------------------------------------------------------------------
*	方法	AddOne 	    //新添加一条数据	Date:15.12.5	Author:zhao
*	@param 	tbName	: 	str.	要操作的表名
* 	@param 	url	: 	str 要获取数据的 后台方法路径
*	@param 	newdata	: 	{}  ajax 参数
*	@param 	success	: 	function  成功回调函数
@param 	db	: 	要操作的 裤的对象 一般不用传
* 	@return	无
*/
    AddOne: function (tbName, newdata, url, success, db) {
        var db = db || IndexDB._pageDB.db;
        if (is_weixin()) {// 加！才对
            db.transaction(function (tx) {
                newdata.isDirty = true;
                db.transaction(function (tx) {
                    tx.executeSql("INSERT INTO student (cvnumber, data) values(?, ?)",
                    [newdata.cvnumber, JSON.stringify(newdata)],
                    function () {
                        if (success != undefined) {
                            success();
                        }
                        IndexDB.toServerOne(url, { list: [newdata], pid: R.info.global.platform }, false);
                    },
                    function (tx, error) { console.log(error); }
                );
                });
            });
        } else {
            var transaction = db.transaction(tbName, "readwrite");
            var objectStore = transaction.objectStore(tbName);
            newdata.isDirty = true;
            var request = objectStore.put(newdata);
            request.onsuccess = function (event) {
                if (success != undefined) { success(); }
                IndexDB.toServerOne(url, { list: [newdata], pid: R.info.global.platform }, false);
            };
            request.onerror = function (e) {
                console.log("添加失败");
                console.log(e.value);
            };
        }
    },

    /*	-------------------------------------------------------------------------------
*	方法	editData 	       //修改一条数据	Date:15.12.5	Author:zhao
*	@param 	tbName	: 	str.	要操作的表名
* 	@param 	url	: 	str 要获取数据的 后台方法路径
*	@param 	indexId	:  	修改数据的 主见 值
*	@param 	upfun（obj）	: 	function  修改方法 传对象 修改完 传回对象
*	@param 	success	: 	function  成功回调函数
*   @param 	db	: 	要操作的 裤的对象 一般不用传
* 	@return	无
*/
    editData: function (tbName, indexId, url, upfun, success, db) {
        var db = db || IndexDB._pageDB.db;
        if (is_weixin()) {// 加！才对
            //先获取
            db.transaction(function (tx) {
                tx.executeSql("select * from " + tbName + " where cvnumber=?",
                [parseInt(indexId)],
                function (tx, result) {
                    var contact = null;
                    var rows = result.rows, length = rows.length, i = 0;
                    if (length > 0) {
                        for (i; i < length; i++) {
                            contact = rows.item(i);
                            contact.data = JSON.parse(contact.data);
                        }
                    } else {
                        contact = undefined;
                    }
                    if (typeof contact != 'object') {
                        contact = eval("(" + contact + ")");
                    }
                    var newcontact = upfun(contact.data);
                    newcontact.dbParam.isDirty = true;
                    db.transaction(function (tx) {
                        tx.executeSql("update " + tbName + " set data=? where cvnumber=?", [JSON.stringify(newcontact.dbParam), indexId], function (tx, result) {
                            if (success != undefined) {
                                success();
                            }
                            if (url != null) {
                                IndexDB.toServerOne(url, { list: [newcontact.ajaxParam], pid: R.info.global.platform }, false);
                            }
                        }, function (tx, error) {
                            console.log('更新失败: ' + error.message);
                        })
                    })

                },
                function (tx, error) { console.log(error); }
            );
            });
        } else {
            var transaction = db.transaction(tbName, "readwrite");
            var objectStore = transaction.objectStore(tbName);
            var getRequest = objectStore.get(parseInt(indexId));
            getRequest.onsuccess = function (event) {
                var contact = event.target.result;
                //修改新数据
                var newcontact = upfun(contact);
                newcontact.dbParam.isDirty = true;
                console.log(newcontact.dbParam);
                //把更新后的数据写入表中
                var addRequest = objectStore.put(newcontact.dbParam);
                addRequest.onsuccess = function (event) {
                    if (success != undefined) {
                        success();
                    }
                    if (url != null) {
                        IndexDB.toServerOne(url, { list: [newcontact.ajaxParam], pid: R.info.global.platform }, false);
                    }
                };

                addRequest.onerror = function (e) {
                    console.log(e.value);
                };
            };
            getRequest.onerror = function (e) {
                console.log(e.value);
            };
        }
    },

    //跟新本地数据库 无请求版
    update: function (name, data, indexId, success, type, db) {
        var db = db || IndexDB._pageDB.db;
        if (is_weixin()) {//加！才对
            db.transaction(function (tx) {
                tx.executeSql("update " + name + " set data=? where cvnumber=?", [JSON.stringify(data), indexId], function (tx, result) {
                    if (success != undefined) {
                        success(data, type);
                    }
                }, function (tx, error) {
                    console.log('更新失败: ' + error.message);
                })
            })
        } else {
            var tbName = name;
            var transaction = db.transaction(tbName, "readwrite");
            var objectStore = transaction.objectStore(tbName);
            var getRequest = objectStore.get(indexId);
            getRequest.onsuccess = function (event) {
                var contact = event.target.result;
                //修改新数据
                var newcontact = data;
                newcontact.isDirty = true;
                //把更新后的数据写入表中
                var addRequest = objectStore.put(newcontact);
                addRequest.onsuccess = function (event) {
                    if (success != undefined) {
                        success(newcontact, type);
                    }
                };

                addRequest.onerror = function (e) {
                    console.log(e.value);
                };
            };
            getRequest.onerror = function (e) {
                console.log(e.value);
            };
        }
    },
    /*	-------------------------------------------------------------------------------
*	方法	delData 	        //删除数据（本地数据库假删除）	Date:15.12.5	Author:zhao
*	@param 	tbName	: 	str.	要操作的表名
* 	@param 	url	: 	str 要获取数据的 后台方法路径
*	@param 	indexIds	:  	要删除数据的主键  {list:{id,id,id},pid: R.info.global.platform}
*	@param 	success	: 	function  成功回调函数
*   @param 	db	: 	要操作的 裤的对象 一般不用传
* 	@return	无
*/
    delData: function (tbName, indexIds, url, success, db) {
        var db = db || IndexDB._pageDB.db;
        if (is_weixin()) {//加！才对
            db.transaction(function (tx) {
                $.each(indexIds.list, function (i, item) {
                    //直接删
                    tx.executeSql("delete from " + tbName + " where cvnumber= ?", [item], function () { console.log("删除成功"); }, function (tx, error) { console.log(error); });
                });
            });
        } else {
            var transaction = db.transaction(tbName, "readwrite");
            var objectStore = transaction.objectStore(tbName);
            $.each(indexIds.list, function (i, item) {
                var getRequest = objectStore.get(parseInt(item));
                getRequest.onsuccess = function (event) {
                    var contact = event.target.result;
                    //删除数据
                    contact.isDirty = true;
                    contact.isDeleted = true;
                    //把更新后的数据写入表中
                    var addRequest = objectStore.put(contact);
                    addRequest.onsuccess = function (event) {
                        if (success != undefined) {
                            success();
                        }
                    };
                    addRequest.onerror = function (e) {
                        console.log(e.value);
                    };

                };

                getRequest.onerror = function (e) {
                    console.log(e.value);
                };
            });
        }
        IndexDB.toServerOne(url, indexIds);
    },

    /*	-------------------------------------------------------------------------------
*	方法	Select 	       //获取一条数据	Date:15.12.5	Author:zhao
*	@param 	tbName	: 	str.	要操作的表名
*	@param 	indexId	:  	要删除数据的主键值
*	@param 	success	: 	function  成功回调函数
*   @param 	db	: 	要操作的 裤的对象 一般不用传
* 	@return	无
*/
    Select: function (tbName, indexId, success, db) {
        var db = db || IndexDB._pageDB.db;
        if (!indexId) { success(undefined); return; }
        if (is_weixin()) {//加！才对
            db.transaction(function (tx) {
                tx.executeSql("select * from " + tbName + " where cvnumber=?",
                [parseInt(indexId)],
                function (tx, result) {
                    var resultdata = null;
                    var rows = result.rows, length = rows.length, i = 0;
                    if (length > 0) {
                        for (i; i < length; i++) {
                            resultdata = rows.item(i);
                            resultdata.data = JSON.parse(resultdata.data);
                        }
                    } else {
                        resultdata = undefined;
                    }
                    if (resultdata != undefined) {
                        if (typeof resultdata != 'object') {
                            resultdata = eval("(" + resultdata + ")");
                        }
                        if (success != undefined) {
                            var rutData = resultdata.data;
                            if (rutData.isDeleted) {
                                rutData = undefined;
                            }
                            success(rutData);
                        }
                    } else {
                        if (success != undefined) {
                            success(resultdata);
                        }
                    }
                },
                function (tx, error) { console.log(error); }
            );
            });
        } else {
            var transaction = db.transaction(tbName, 'readwrite');
            var store = transaction.objectStore(tbName);
            if (!store) {
                return;
            }
            var request = store.get(indexId);
            request.onsuccess = function (e) {
                var data = e.target.result;
                if (data != undefined) {
                    if (success != undefined) {
                        var rutData = data;
                        if (data.isDeleted) {
                            rutData = undefined;
                        }
                        success(rutData);
                    }
                } else {
                    success(data);
                }
            };
        }
    },


    /*	-------------------------------------------------------------------------------
    *	方法	toServerOne 	//联网交互服务器  Date:15.12.5	Author:zhao
    *	@param 	url	: 	str.	ajax 路径
    *	@param 	data	:  ajax 参数 {list:[dd]}
    * 	@return	无
    */
    toServerOne: function (url, data) {
        var datap = data;
        if (true) {//联网状态
            $.ajax({
                url: url,
                data: datap,
                type: "POST",
                dataType: 'json',
                success: function (result) {
                    var data = result;
                    if (data.result == 10000) {
                    } else { //失败添加到 特殊裤里面
                        ToUnOnlinDB(url, datap);
                    }
                },
                error: function (er) {
                    //错误 添加到特殊库里面
                    ToUnOnlinDB(url, datap);
                }
            });
        } else {//没联网状态
            //添加到特殊库
            ToUnOnlinDB(url, datap);
        }
        //"url" { list: [data1,data2] } {list: [data3,data4]}
        function ToUnOnlinDB(url, data) {
            var tbName = "OnlinDB";
            var dbName = "OnlinDB_" + R.info.global.platform;
            if (is_weixin()) { //加！才对
                var db = openDatabase(dbName, version, dbName, 2 * 1024 * 1024);
                if (!db) {
                    alert("不支持webSQL");
                    return false;
                }
                db.transaction(function (tx) {
                    tx.executeSql('CREATE TABLE IF NOT EXISTS ' + tbName + ' (url REAL UNIQUE, data TEXT)', [], function () {
                        db.transaction(function (tx) {
                            //要添加数据了
                            //先根据url 获取 以前的数据
                            tx.executeSql("select * from " + tbName + " where url=?", [url], function (tx, result) {
                                var rows = result.rows, length = rows.length;
                                var contact = rows.item(0);
                                contact.data = JSON.parse(contact.data);
                                if (typeof contact != 'object') {
                                    contact = eval("(" + contact + ")");
                                }
                                var newcontact = null;
                                if (length > 0) {//以前有数据
                                    var old = contact.data;
                                    var newd = data.list;
                                    contact.url = url;
                                    for (var i = 0; i < newd.length; i++) {
                                        if (!unique(newd[i], old.list)) {
                                            old.list.push(newd[i]);
                                        }
                                    }
                                    contact.data = old;
                                    newcontact = contact;
                                } else { //以前没有数据
                                    newcontact = { url: url, data: data };
                                }
                                if (length > 0) {//更新
                                    db.transaction(function (tx) {
                                        tx.executeSql("update " + tbName + " set data = ? where url= ?", [Json.stringify(newcontact), url], function (tx, result) {
                                        }, function (tx, error) {
                                            console.log("ToUnOnlinDB-添加失败");
                                        })
                                    })
                                } else {//添加
                                    db.transaction(function (tx) {
                                        tx.executeSql("insert into stu (url, data) values(?, ?)", [url, Json.stringify(newcontact)], function () {
                                        }, function (tx, error) {
                                            console.log("ToUnOnlinDB-添加失败");
                                        })
                                    })
                                }
                            }, function (tx, error) {

                            });
                        }, function (tx, e) {
                            console.log(e);
                        });
                    }, function (tx, e) {
                        console.log(e);
                    });
                }, function (e) {
                    console.log("事物失败");
                }, function () {
                    console.log("事物成功");
                });
            } else {
                var request = IndexDB.dataDB.open(dbName, 1);
                request.onerror = function (e) {
                    console.log(e.currentTarget.error.message);
                };
                request.onsuccess = function (e) {
                    var db = e.target.result;
                    //添加一条数据
                    var transaction = db.transaction(tbName, "readwrite");
                    var objectStore = transaction.objectStore(tbName);
                    var getRequest = objectStore.get(url);
                    getRequest.onsuccess = function (event) {
                        var contact = event.target.result;
                        var newcontact = null;
                        if (contact != undefined) { //原来已经有了
                            var old = contact.data;
                            var newd = data.list;
                            contact.url = url;
                            for (var i = 0; i < newd.length; i++) {
                                if (!unique(newd[i], old.list)) {
                                    old.list.push(newd[i]);
                                }
                            }
                            contact.data = old;
                            newcontact = contact;
                        } else {//原来没有
                            newcontact = { url: url, data: data };
                        }
                        //把更新后的数据写入表中
                        var addRequest = objectStore.put(newcontact);
                        addRequest.onsuccess = function (event) {
                            console.log("ToUnOnlinDB-添加成功");
                        };
                        addRequest.onerror = function (e) {
                            console.log("ToUnOnlinDB-添加失败");
                            console.log(e.value);
                        };
                    };
                    getRequest.onerror = function (e) {
                        console.log("ToUnOnlinDB-获取失败");
                        console.log(e.value);
                    };
                };
                request.onupgradeneeded = function (e) {
                    console.log("ToUnOnlinDB-onupgradeneeded");
                    var db = e.target.result;
                    if (!db.objectStoreNames.contains(tbName)) {
                        var store = db.createObjectStore(tbName, { keyPath: "url" });
                    }
                };
            }
        }
        //判断两个对象是否相等
        function isObjectValueEqual(a, b) {
            // Of course, we can do it use for in
            // Create arrays of property names
            var aProps = Object.getOwnPropertyNames(a);
            var bProps = Object.getOwnPropertyNames(b);

            // If number of properties is different,
            // objects are not equivalent
            if (aProps.length != bProps.length) {
                return false;
            }

            for (var i = 0; i < aProps.length; i++) {
                var propName = aProps[i];

                // If values of same property are not equal,
                // objects are not equivalent
                if (a[propName] !== b[propName]) {
                    return false;
                }
            }

            // If we made it this far, objects
            // are considered equivalent
            return true;
        }
        //去重
        function unique(n, arr) {
            for (var i = 0; i < arr.length; i++) {
                if (isObjectValueEqual(n, arr[i])) {
                    return true;
                }
            }
            return false;
        }
    },

    /*	-------------------------------------------------------------------------------
*	方法	toServer 	//不联网产生的数据 在联网时 调用 批量交互服务器之后  Date:15.12.5	Author:zhao
* 	@return	无
*/
    toServer: function () {
        var dbName = "OnlinDB_" + R.info.global.platform;
        var tbName = "OnlinDB";
        var request = window.indexedDB.open(dbName, 1);
        request.onerror = function (e) {
            console.log("toServerOpen-error");
            console.log(e.currentTarget.error.message);
        };
        request.onsuccess = function () {
            var db = e.target.result;
            var data = new Array();
            var transaction = db.transaction(tbName);
            var objectStore = transaction.objectStore(tbName);
            var cursorRequest = objectStore.openCursor();//打开游标
            cursorRequest.onsuccess = function (evt) {
                var cursor = evt.target.result;
                if (cursor) {
                    var isDirty = cursor.value.isDirty;
                    if (isDirty) { //判断是否是修改过的数据
                        data[data.length] = cursor.value;
                    }
                    cursor.continue();//移动游标 查看下一条数据
                } else {
                    //游标循环完后
                    //记录操作类型个数
                    var del = new Array();
                    var add = new Array();
                    var edit = new Array();
                    //遍历data数组
                    $.each(data, function (i, item) {
                        IndexDB.toServerOne(item.url, item)
                    });
                }
                //完成之后 清表
                objectStore.clear();
            }
        }
        request.onupgradeneeded = function (e) {
            var db = e.target.result;
            if (!db.objectStoreNames.contains(tbName)) {
                var store = db.createObjectStore(tbName, { keyPath: "url" });
            }
        }
    }

}

//==================
//判读是否是微信
//==================
function is_weixin() {
    var ua = navigator.userAgent.toLowerCase();
    if (ua.match(/MicroMessenger/i) == "micromessenger") {
        return true;
    } else {
        return false;
    }
}

//======================================
//  Desc:获取当前平台的cvNumber
//  Author：Cupid
//  Date:2015-12-21 12:11:27
//========================================  
function getCurrentCV() {
    if (!isNull(R.info.global.platform)) {
        var key = "CvNumber" + R.info.global.platform;
        var page = R.currPage.name || '';
        var result = $.getCookie(key);
        if (!isNull(result)) {
            return parseInt(result);
        } else {
            return 0;
        }
    } else {
        return 0;
    }
}
//======================================
//  Desc:删除当前平台的cvNumber
//  Author：Cupid
//  Date:2015-12-21 12:11:27
//========================================  
function deleteCurrentCv() {
    var name = 'CvNumber' + R.info.global.platform;
    $.deleteCookie(name);
}

//======================================
//  Desc:获取当前身份信息
//  Author：Cupid
//  Date:2015-12-21 12:11:27
//========================================  
function createParam(parameters, id) {
    var defaultParam = {
        name: '',
        hasName: 1,
        cvNumber: getCurrentCV(),
        regid: 0,
        arrObj: '',
        arrStr: ''
    }

    parameters = $.extend(defaultParam, parameters);
    console.log(parameters);
    var showDiv = $(id).find("div.show");
    var arrSelecter = showDiv.find("div.selecter");
    var templateStr = '{"CvNumber":"{0}","Title":"{1}","Contents":"{2}","Flag":"{3}","IsSys":"1","OtherId":"SOtherId","IsTxt":"{4}","ColumnId":"{5}"}';
    var arrObj = [], arrStr = [];
    var istext = true;
    /*文本框*/
    var arrTxt = showDiv.find('input.customtxt');
    if (arrTxt.length > 0) {

        $(arrTxt).each(function () {
            var $this = $(this),
                  value = $this.val(),
                  typeName = $this.attr("data-name"),
            columnId = $this.attr("data-columnId");

            if (/^\s*$/.test(value)) {
                app.alert('请填写' + typeName);
                istext = false;
            } else {
                arrStr = arrStr.concat([templateStr.format([parameters.cvNumber, typeName, value, parameters.regid, 1, columnId])]);
            }
        });
    }
    var isselect = true;
    /*选择框*/
    if (arrSelecter.length > 0) {

        $(arrSelecter).each(function () {
            var $this = $(this),
            template = parseInt($this.attr('data-template'));

            if (template == 1) {
                /*单选*/
                var $span = $this.find("span.on"),
                      typeName = $this.attr('data-typeName'),
                      content = $span.text();
                if ($span.length <= 0) {
                    app.alert('请选择' + $this.attr('data-typeName'));
                    isselect = false;
                } else {
                    //单选数组
                    arrObj = arrObj.concat(identityArr([$span], parameters.cvNumber));
                    arrStr = arrStr.concat([templateStr.format([parameters.cvNumber, typeName, content, parameters.regid,0,0])]);
                }
            } else if (template == 3) {
                /*班级 类型*/
                var selectRight = $this.find("div.selecter-right"),//阶段和班级
                      selectLeft = $this.find("div.selecter-left");//年级

                /*阶段数据和班级数据*/
                var edu = selectRight.find("div.selecter-right-title").find('span.current'),
                       className = selectRight.find('div.selecter-right-list').find('span.on');

                if (className.length <= 0) {
                    app.alert('请选择' + $this.attr('data-typeName'));
                    isselect = false;
                } else {
                    var typeName = $this.attr('data-typeName'),
                        content = className.text();
                    /*年级数据*/
                    arrObj = arrObj.concat(identityArr([selectLeft.find('li.current')], parameters.cvNumber));
                    var zy = className.siblings('.zy'),
                           xs = className.siblings('.xs');
                    arrObj = arrObj.concat(identityArr([edu, className, zy, xs], parameters.cvNumber));

                    arrStr = arrStr.concat([templateStr.format([parameters.cvNumber, typeName, content, parameters.regid, 0,0])]);
                }
            }
        });
    }

    parameters.arrObj = '{"key":[' + arrObj + ']}';
    parameters.arrStr = '{"key":[' + arrStr + ']}';
    parameters.isLegalData = isselect && istext;//是否是合法数据
    log("是否是合法数据" + parameters.isLegalData)
    return parameters;

}
/*Des:获取所有图片，生成数组, $this_content:当前对象 */
function identityArr(arrObj, cvNumber) {
    var arr = [];
    var template = '{"cvnumber":"{0}","joinid":"{1}","flag":"{2}","groupid":"gid","pid":"pfid" }';
    $.each(arrObj, function (i, item) {
        arr.push(template.format([cvNumber, item.attr("data-joinid"), item.attr("data-flagid")]));
    });
    return arr;
}



function CombiTime(date, type) {
    if (!!date) {
        switch (type) {
            case 0: //年
                date = date + "-01" + "-01" + " 00" + ":00" + ":00.000"
                break;
            case 1: //月
                date = date + "-01" + " 00" + ":00" + ":00.000"
                break;
            case 2: //日
                date = date + " 00" + ":00" + ":00.000"
                break;
            case 4: //分
                date = date + ":00.000"
                break;
        }
    }
    return date;
}

//时间反转
function SevCombiTime(dateTime, type) {
    if (dateTime == "") {
        return false;
    }
    //2015-10-10 20:50

    var myDate = dateTime;
    var fullyaer = myDate.substr(0, 4);
    var month = myDate.substr(5, 2);
    var date = myDate.substr(8, 2);
    var hours = myDate.substr(11, 2);
    var minutes = myDate.substr(14, 2);

    var resDate = "";
    switch (type) {
        case 0:
            resDate = fullyaer;
            break;
        case 1:
            resDate = fullyaer + "-" + month;
            break;
        case 2:
            resDate = fullyaer + "-" + month + "-" + date;
            break;
        case 4:
            resDate = fullyaer + "-" + month + "-" + date + " " + hours + ":" + minutes;
            break;
    }

    return resDate;
}

//经历 添加 编辑 修改 评论 同行 只要是操作数据了 操作完成后 调用S
function ExperLocData() {
    localStorage.setItem("experischange_jy", "have");
    localStorage.setItem("experischange_our", "have");

}
//有事、活动 发布了 修改了 删除了 收藏 报名 有操作的地方 操作完成后 调用
function ThingLocData() {
    localStorage.setItem("thingchange_1", "have");
    localStorage.setItem("thingchange_2", "have");
    localStorage.setItem("thingchange_3", "have");

}


//判断是不是图片类型
function IsImageType(f) {
    return /(image\/gif|image\/jpg|image\/jpeg|image\/png|image\/GIF|image\/JPG|image\/PNG)$/.test(f);
}

//生产百分比方法
function Percentage(number1, number2) {
    if (number2 != 0) {
        return (Math.round(number1 / number2 * 10000) / 100.00 + "%");// 小数点后两位百分比
    } else {
        return "0%";
    }
}