/*!  2016-01-25 */
!function(a){}(jQuery);