module.exports = function (grunt) {
    // ��Ŀ����
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        //ѹ��js
        uglify: {
            options: {
                banner: '/*! <%= pkg.file %> <%= grunt.template.today("yyyy-mm-dd") %> */\n'
            },
            my_target: {
                files: [
                {//template �ļ��������js
                    expand: true,
                    cwd: 'src/template/',
                    src: '*/*.js',
                    dest: 'dest/src/template'

                },
				{//Scripts�ļ����µ�js
					expand: true,
                    cwd: 'src/Scripts/',
                    src: '*/*.js',
                    dest: 'dest/src/Scripts'
					
				} ]
            }
        },
        //ѹ��css
        cssmin: {
            options: {
                banner: '/*! <%= pkg.name %> <%= grunt.template.today("yyyy-mm-dd") %> */\n',
                //��������
                beautify: {
                    //����ascii�����ǳ����ã���ֹ���������������
                    ascii_only: true
                }
            },
            my_target: {
                files: [
                   {
                       expand: true,
                       //���·��
                       cwd: 'src/Style',
                       src: '*.css',
                       dest: 'dest/src/Style'
                   }
                ]
            }
        },
        //ѹ��html
        htmlmin: {
            options: {
                removeComments: true,
                removeCommentsFromCDATA: true,
                collapseWhitespace: true,
                collapseBooleanAttributes: true,
                removeAttributeQuotes: true,
                removeRedundantAttributes: true,
                useShortDoctype: true,
                removeEmptyAttributes: true,
                removeOptionalTags: true
            },
            html: {
                files: [
                  {
                      expand: true,
                      cwd: 'src/template/',
                      src: '*/*.html',
                      dest: 'dest/src/template'
                  },
                   {
                       expand: true,
                       cwd: 'src/Views/',
                       src: '*/*.cshtml',
                       dest: 'dest/src/Views'
                   }
                ]
            }
        }
    });
    // �����ṩ"uglify"����Ĳ��
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-htmlmin');
    // Ĭ������
    grunt.registerTask('default', ['uglify', 'cssmin', 'htmlmin']);
}