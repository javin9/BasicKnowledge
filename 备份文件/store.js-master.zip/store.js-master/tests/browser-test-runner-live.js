var store = require('../src/store+json2')
var browserTestRunner = require('./browser-test-runner')

browserTestRunner.run(store)